import csv
import hashlib
import json
import statistics as s
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parents[2]
base = ROOT / 'out/benchmarks'
cloud = json.loads((base / 'environment-cloud-20261116/summary.json').read_text())
atmo = json.loads((base / 'environment-atmosphere-20261116/summary.json').read_text())
out = ROOT / 'spec/benchmarks'
result = {'cloud': {}, 'atmosphere': {}, 'images': {}}

def combine(values):
    return dict(median=s.median(values), min=min(values), max=max(values), rounds=values)

for name in dict.fromkeys(r['name'] for r in cloud):
    rows = [r for r in cloud if r['name'] == name]
    modes = {}
    for mode in rows[0]['modes']:
        stats = {}
        for key in rows[0]['modes'][mode]['steady']:
            if key == 'passes':
                stats[key] = {p: combine([r['modes'][mode]['steady']['passes'][p]['p50'] for r in rows])
                              for p in rows[0]['modes'][mode]['steady']['passes']}
            else:
                stats[key] = {quantile: combine([r['modes'][mode]['steady'][key][quantile] for r in rows])
                              for quantile in ('p50', 'p95')}
        modes[mode] = stats
    result['cloud'][name] = {'modes': modes, 'runs': rows}
for preset in ('noon', 'sunset', 'high-altitude'):
    rows = [r for r in atmo['runs'] if r['preset'] == preset and r['timestamps']]
    result['atmosphere'][preset] = {
        mode: {key: {q: combine([r['modes'][mode][key][q] for r in rows]) for q in ('p50', 'p95')}
               for key in rows[0]['modes'][mode]} for mode in rows[0]['modes']}

baseline = np.asarray(Image.open(base / 'environment-cloud-20261116/r1-baseline-overcast.ppm')).astype(float)
for name in ('baseline-overcast', 'field-half', 'primary-48', 'sun-4', 'no-self-shadow'):
    paths = [base / f'environment-cloud-20261116/r{r}-{name}.ppm' for r in (1, 2, 3)]
    hashes = [hashlib.sha256(p.read_bytes()).hexdigest() for p in paths]
    assert len(set(hashes)) == 1, name
    image = np.asarray(Image.open(paths[0])).astype(float)
    error = np.abs(image - baseline) / 255
    result['images'][name] = dict(identical_rounds=True, sha256=hashes[0],
                                ldr_mae=float(error.mean()), ldr_p95=float(np.quantile(error, .95)))
for name in ('clear', 'sparse', 'sunset'):
    paths = [base / f'environment-cloud-20261116/r{r}-baseline-{name}.ppm' for r in (1, 2, 3)]
    assert len({hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}) == 1

fig, axes = plt.subplots(1, 2, figsize=(13, 5), layout='constrained')
names = ('baseline-clear', 'baseline-sparse', 'baseline-overcast', 'baseline-sunset')
values = [result['cloud'][n]['modes']['combined-static']['total_gpu_ms']['p50'] for n in names]
axes[0].bar(['Clear', 'Sparse', 'Overcast', 'Sunset'], [v['median'] for v in values], color=['#67b4a5', '#60a5fa', '#3b82f6', '#ed9357'])
axes[0].errorbar(range(4), [v['median'] for v in values],
                yerr=([v['median']-v['min'] for v in values], [v['max']-v['median'] for v in values]), fmt='none', ecolor='#222', capsize=4)
axes[0].axhline(16.667, ls='--', color='#777', label='16.67 ms frame budget')
for i,v in enumerate(values): axes[0].text(i,v['max']+1,f"{v['median']:.2f}", ha='center')
axes[0].set(title='1080p atmosphere + clouds', ylabel='GPU milliseconds (median of 3 round p50s)', ylim=(0,57))
axes[0].legend(loc='upper left', fontsize=9)
variants = ['baseline-overcast','720p','540p','field-half','primary-48','sun-4','no-self-shadow']
values = [result['cloud'][n]['modes']['combined-static']['total_gpu_ms']['p50']['median'] for n in variants]
axes[1].barh(['Default 1080p','1280 x 720','960 x 540','Noise dimensions / 2','Primary 96 -> 48','Sun 8 -> 4','No self-shadow'], values, color='#3b82f6')
axes[1].invert_yaxis()
for i,v in enumerate(values): axes[1].text(v+.3,i,f'{v:.2f}', va='center')
axes[1].set(title='Overcast single-factor diagnostics', xlabel='GPU milliseconds; quality may change', xlim=(0,36))
fig.suptitle('RTX 4070 Laptop | RelWithDebInfo | Validation OFF | 2026-11-16', fontsize=12)
fig.savefig(out / '2026-11-16-environment-performance.png', dpi=160)
plt.close(fig)

fig, axes = plt.subplots(1, 3, figsize=(15, 3.7), layout='constrained')
for ax, name, title in zip(axes, ['baseline-overcast', 'field-half', 'no-self-shadow'],
                         ['Default', 'Noise dimensions / 2', 'Self-shadow disabled']):
    ax.imshow(Image.open(base / f'environment-cloud-20261116/r1-{name}.ppm'))
    ax.set_title(title); ax.axis('off')
fig.suptitle('Diagnostic images only: exposure 8, 1080p; not a reference-quality acceptance', fontsize=11)
fig.savefig(out / '2026-11-16-environment-comparison.png', dpi=150)
plt.close(fig)

worker = base / 'environment-editor-20261116'
if worker.exists():
    result['editor'] = [json.loads(p.read_text()) for p in sorted(worker.glob('r*/report.json'))]
tracy = base / 'environment-tracy-20261116-connected'
if (tracy / 'summary.json').exists():
    result['tracy'] = json.loads((tracy / 'summary.json').read_text())
result['atmosphere_raw_summary'] = atmo
(out / '2026-11-16-environment-performance.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
print('Wrote figures and round-level evidence; all repeated baseline and quality-variant images deterministic.')
print(json.dumps(result['images'], indent=2))
