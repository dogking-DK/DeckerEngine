#include <dk/editor/Workbench.hpp>
#include <cstdio>
#include <stdexcept>
#include <string>
#ifdef _WIN32
int wmain(int argc,wchar_t** argv) {
#else
int main(int argc,char** argv) {
#endif
    try {
        dk::editor::WorkbenchOptions options;
        options.root=DK_EDITOR_DEFAULT_ROOT;
        for (int i=1;i<argc;++i) {
            const std::filesystem::path arg{argv[i]};
            const auto next=[&]() -> std::filesystem::path {
                if (++i>=argc) throw std::runtime_error("Missing option value");
                return argv[i];
            };
            if (arg=="--root") options.root=next();
            else if (arg=="--manifest") options.manifest=next();
#ifdef _WIN32
            else if (arg=="--pipe" && options.pipe.empty()) {
                const auto name=next().u8string();
                options.pipe.assign(reinterpret_cast<const char*>(name.data()),name.size());
                if (options.pipe.empty()) throw std::runtime_error("Missing pipe name");
            }
#endif
            else if (arg=="--validation") options.validation=true;
            else if (arg=="--no-validation") options.disable_validation=true;
            else if (arg=="--background") options.background=true;
            else if (arg=="--restir-pathtrace-smoke") { options.restir_pathtrace_smoke=true; options.media_pathtrace_smoke=true; options.pathtrace_smoke=true; }
            else if (arg=="--media-pathtrace-smoke") { options.media_pathtrace_smoke=true; options.pathtrace_smoke=true; }
            else if (arg=="--pathtrace-smoke") options.pathtrace_smoke=true;
            else if (arg=="--camera-command-smoke") options.camera_command_smoke=true;
            else if (arg=="--settings-help-smoke") options.settings_help_smoke=true;
            else if (arg=="--console-workflow-smoke") options.console_workflow_smoke=true;
            else if (arg=="--viewport-command-smoke") options.viewport_command_smoke=true;
            else if (arg=="--voxel-path-smoke") options.voxel_path_smoke=true;
            else if (arg=="--voxel-path-no-rt") { options.voxel_path_smoke=true; options.voxel_path_no_rt=true; }
            else if (arg=="--voxel-workflow-smoke") options.voxel_workflow_smoke=true;
            else if (arg=="--desktop-render-smoke") options.desktop_render_smoke=true;
            else if (arg=="--media-motion-probe") options.media_motion_probe=true;
            else if (arg=="--smoke") options.smoke=true;
            else if (arg=="--interaction-smoke") { options.smoke=true; options.interaction_smoke=true; }
            else if (arg=="--simulation-smoke") { options.smoke=true; options.simulation_smoke=true; }
            else if (arg=="--environment-consistency-smoke") options.environment_consistency_smoke=true;
            else if (arg=="--consistency-smoke") options.consistency_smoke=true;
            else if (arg=="--simulation-consistency-smoke") options.simulation_consistency_smoke=true;
            else if (arg=="--simulation-response-probe") options.simulation_response_probe=true;
            else if (arg=="--fixture-camera") options.fixture_camera=true;
            else if (arg=="--frames") {
                const auto text=next().string(); std::size_t used=0;
                const auto count=std::stoul(text,&used);
                if (used!=text.size() || count==0 || count>10000) throw std::runtime_error("frames must be 1..10000");
                options.frames=static_cast<unsigned>(count);
            }
            else if (arg=="--screenshot") options.screenshot=next();
            else if (arg=="--help") {
                std::puts("dk-editor [--root PROJECT_ROOT] [--manifest RELATIVE_MANIFEST] [--validation|--no-validation] [--pipe NAME] [--background]\n"
                    "Window: --background shows/restores behind other windows without activation (Windows); default: normal foreground startup\n"
                    "            --desktop-render-smoke --root DISPOSABLE_PROJECT --screenshot OUTPUT.ppm\n"
                    "            --media-motion-probe --root DISPOSABLE_PROJECT (requires .dk-media-motion.json)\n"
                    "Acceptance: --frames N --screenshot OUTPUT.ppm [--fixture-camera]\n"
                    "            --smoke/--interaction-smoke/--simulation-smoke --root DISPOSABLE_PROJECT --screenshot OUTPUT.ppm\n"
                    "            --settings-help-smoke --fixture-camera --root DISPOSABLE_PROJECT --screenshot OUTPUT.ppm\n"
                    "            --console-workflow-smoke --pipe NAME --fixture-camera --root DISPOSABLE_PROJECT --screenshot OUTPUT.ppm\n"
                    "            --environment-consistency-smoke --pipe NAME --fixture-camera --root DISPOSABLE_PROJECT --screenshot OUTPUT.ppm\n"
                    "            --consistency-smoke --pipe NAME --fixture-camera --root DISPOSABLE_PROJECT --screenshot OUTPUT.ppm\n"
                    "            --simulation-consistency-smoke --pipe NAME --fixture-camera --root DISPOSABLE_PROJECT --screenshot OUTPUT.ppm\n"
                    "            --camera-command-smoke --pipe NAME --fixture-camera --root DISPOSABLE_PROJECT\n"
                    "            --viewport-command-smoke --pipe NAME --fixture-camera --root DISPOSABLE_PROJECT\n"
                    "            --pathtrace-smoke/--media-pathtrace-smoke/--restir-pathtrace-smoke --pipe NAME --fixture-camera --root DISPOSABLE_PROJECT --screenshot OUTPUT.ppm\n"
                    "            --simulation-response-probe --pipe NAME --root DISPOSABLE_PROJECT");
                return 0;
            } else throw std::runtime_error("Unknown dk-editor option");
        }
        if(options.camera_command_smoke && (options.viewport_command_smoke || options.pathtrace_smoke || options.desktop_render_smoke || options.smoke || options.consistency_smoke || options.environment_consistency_smoke || options.simulation_consistency_smoke || options.simulation_response_probe || options.frames || options.pipe.empty() || !options.fixture_camera))
            throw std::runtime_error("--camera-command-smoke requires --pipe and --fixture-camera; incompatible with other acceptance modes");
        if(options.viewport_command_smoke && (options.pathtrace_smoke || options.desktop_render_smoke || options.smoke || options.consistency_smoke || options.environment_consistency_smoke || options.simulation_consistency_smoke || options.simulation_response_probe || options.frames || options.pipe.empty() || !options.fixture_camera))
            throw std::runtime_error("--viewport-command-smoke requires --pipe and --fixture-camera; incompatible with other acceptance modes");
        if(options.desktop_render_smoke && (options.pathtrace_smoke || options.smoke || options.consistency_smoke || options.environment_consistency_smoke || options.simulation_consistency_smoke || options.simulation_response_probe || options.frames || options.fixture_camera || options.screenshot.empty()))
            throw std::runtime_error("--desktop-render-smoke requires --screenshot and the normal camera; incompatible with other acceptance modes");
        if(options.pathtrace_smoke && (options.smoke || options.consistency_smoke || options.environment_consistency_smoke || options.simulation_consistency_smoke || options.simulation_response_probe || options.frames || options.pipe.empty() || !options.fixture_camera || options.screenshot.empty()))
            throw std::runtime_error("--pathtrace-smoke requires --pipe, --fixture-camera and --screenshot; incompatible with other acceptance modes");
        if(options.settings_help_smoke && (options.camera_command_smoke || options.viewport_command_smoke || options.pathtrace_smoke || options.desktop_render_smoke || options.smoke || options.consistency_smoke || options.environment_consistency_smoke || options.simulation_consistency_smoke || options.simulation_response_probe || options.frames || !options.fixture_camera || options.screenshot.empty()))
            throw std::runtime_error("--settings-help-smoke requires --fixture-camera and --screenshot; incompatible with other acceptance modes");
        if (options.validation && options.disable_validation) throw std::runtime_error("--validation and --no-validation are mutually exclusive");
        if(options.console_workflow_smoke && (options.settings_help_smoke || options.camera_command_smoke || options.viewport_command_smoke || options.pathtrace_smoke || options.desktop_render_smoke || options.smoke || options.consistency_smoke || options.environment_consistency_smoke || options.simulation_consistency_smoke || options.simulation_response_probe || options.frames || options.pipe.empty() || !options.fixture_camera || options.screenshot.empty()))
            throw std::runtime_error("--console-workflow-smoke requires --pipe, --fixture-camera and --screenshot; incompatible with other acceptance modes");
        if (options.environment_consistency_smoke && (options.smoke || options.consistency_smoke || options.simulation_consistency_smoke || options.simulation_response_probe || options.frames || options.pipe.empty() || !options.fixture_camera || options.screenshot.empty()))
            throw std::runtime_error("--environment-consistency-smoke requires --pipe, --fixture-camera and --screenshot; incompatible with other acceptance modes");
        if (options.simulation_smoke && (options.interaction_smoke || options.frames || options.screenshot.empty()))
            throw std::runtime_error("--simulation-smoke requires --screenshot and is incompatible with interaction/frames");
        if (!options.screenshot.empty() && options.screenshot.extension()!=".ppm")
            throw std::runtime_error("screenshot must have .ppm extension");
        if (options.consistency_smoke && (options.smoke || options.frames || options.pipe.empty() || !options.fixture_camera || options.screenshot.empty()))
            throw std::runtime_error("--consistency-smoke requires --pipe, --fixture-camera and --screenshot; incompatible with --frames and other smoke modes");
        if (options.simulation_consistency_smoke && (options.smoke || options.consistency_smoke || options.simulation_response_probe ||
            options.frames || options.pipe.empty() || !options.fixture_camera || options.screenshot.empty()))
            throw std::runtime_error("--simulation-consistency-smoke requires --pipe, --fixture-camera and --screenshot; incompatible with other acceptance modes");
        if (options.simulation_response_probe && (options.smoke || options.consistency_smoke || options.frames || options.pipe.empty()))
            throw std::runtime_error("--simulation-response-probe requires --pipe and is incompatible with smoke/frames");
        if(options.media_motion_probe && (options.voxel_path_smoke || options.voxel_workflow_smoke || options.camera_command_smoke ||
            options.viewport_command_smoke || options.pathtrace_smoke || options.desktop_render_smoke || options.settings_help_smoke ||
            options.console_workflow_smoke || options.smoke || options.consistency_smoke || options.environment_consistency_smoke ||
            options.simulation_consistency_smoke || options.simulation_response_probe || options.frames || options.fixture_camera || !options.pipe.empty()))
            throw std::runtime_error("--media-motion-probe requires a normal camera and no other acceptance mode");
        return dk::editor::run_workbench(options);
    } catch (const std::exception& error) { std::fprintf(stderr,"editor: %s\n",error.what()); return 1; }
}
