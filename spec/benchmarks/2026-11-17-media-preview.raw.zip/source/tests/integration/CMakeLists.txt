if(TARGET dk_asset_voxel_importers AND DK_BUILD_ASSET_RUNTIME AND DK_BUILD_ASSET_IMPORTERS AND TARGET dk_scene)
    find_package(nlohmann_json CONFIG REQUIRED)
    add_executable(dk_voxel_asset_process_probe VoxelAssetProcessProbe.cpp)
    target_link_libraries(dk_voxel_asset_process_probe PRIVATE dk::asset_runtime dk::asset_voxel_importers dk::scene OpenVDB::openvdb nlohmann_json::nlohmann_json)
    dk_target_defaults(dk_voxel_asset_process_probe)
    add_test(NAME dk.voxels.assets_process COMMAND "${CMAKE_COMMAND}"
        "-DPROBE=$<TARGET_FILE:dk_voxel_asset_process_probe>" "-DWORK_DIR=${CMAKE_CURRENT_BINARY_DIR}/test-artifacts/$<CONFIG>"
        -P "${CMAKE_CURRENT_SOURCE_DIR}/VoxelAssetProcessTest.cmake")
    set_tests_properties(dk.voxels.assets_process PROPERTIES TIMEOUT 120 LABELS "cpu")
    if(WIN32 AND TARGET dk_editor_app AND TARGET dk_render_voxels AND TARGET dk_render_services)
        find_package(Python3 3.11 COMPONENTS Interpreter REQUIRED)
        add_test(NAME dk.voxels.editor_capture_gpu_required
            COMMAND "${CMAKE_COMMAND}" -E env "PYTHONPATH=${PROJECT_SOURCE_DIR}/sdk/python" "PYTHONDONTWRITEBYTECODE=1"
                "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/VoxelWorkflowTest.py"
                --editor "$<TARGET_FILE:dk_editor_app>" --runner "$<TARGET_FILE:dk_run>" --client "$<TARGET_FILE:dk_ctl>"
                --fixture "$<TARGET_FILE:dk_voxel_asset_process_probe>" --example "${PROJECT_SOURCE_DIR}/examples/render/voxel_capture.py"
                --mesh-fixture "${PROJECT_SOURCE_DIR}/tests/fixtures/render-disk/assets"
                --work-dir "${PROJECT_BINARY_DIR}/test-artifacts/$<CONFIG>")
        set_tests_properties(dk.voxels.editor_capture_gpu_required PROPERTIES TIMEOUT 420 RUN_SERIAL TRUE LABELS "gpu"
            ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1;VK_VALIDATION_VALIDATE_SYNC=1;DISABLE_LAYER_AMD_SWITCHABLE_GRAPHICS_1=1")
        if(TARGET dk_render_pathtracing)
            foreach(mode IN ITEMS path_consumers path_no_rt)
                set(voxel_path_args)
                if(mode STREQUAL "path_no_rt")
                    list(APPEND voxel_path_args --no-rt)
                endif()
                add_test(NAME dk.voxels.${mode}_gpu_required
                    COMMAND "${CMAKE_COMMAND}" -E env "PYTHONPATH=${PROJECT_SOURCE_DIR}/sdk/python" "PYTHONDONTWRITEBYTECODE=1"
                        "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/VoxelPathWorkflowTest.py" ${voxel_path_args}
                        --editor "$<TARGET_FILE:dk_editor_app>" --runner "$<TARGET_FILE:dk_run>" --client "$<TARGET_FILE:dk_ctl>"
                        --fixture "$<TARGET_FILE:dk_voxel_asset_process_probe>" --example "${PROJECT_SOURCE_DIR}/examples/render/voxel_capture.py"
                        --mesh-fixture "${PROJECT_SOURCE_DIR}/tests/fixtures/render-disk/assets"
                        --work-dir "${PROJECT_BINARY_DIR}/test-artifacts/$<CONFIG>")
                set_tests_properties(dk.voxels.${mode}_gpu_required PROPERTIES TIMEOUT 900 RUN_SERIAL TRUE LABELS "gpu"
                    ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1;VK_VALIDATION_VALIDATE_SYNC=1;DISABLE_LAYER_AMD_SWITCHABLE_GRAPHICS_1=1")
            endforeach()
        endif()
    endif()
    if(TARGET dk_render_pipeline AND TARGET dk_render_voxels)
        add_executable(dk_voxel_asset_gpu_probe VoxelAssetGpuProbe.cpp)
        target_link_libraries(dk_voxel_asset_gpu_probe PRIVATE dk::asset_runtime dk::asset_voxel_importers dk::render_pipeline dk::render_voxels OpenVDB::openvdb nlohmann_json::nlohmann_json)
        target_include_directories(dk_voxel_asset_gpu_probe PRIVATE "${PROJECT_SOURCE_DIR}/engine/graphics/device/src")
        target_compile_definitions(dk_voxel_asset_gpu_probe PRIVATE DK_RENDER_SHADER_DIR="${PROJECT_SOURCE_DIR}/shaders/render"
            DK_VOXEL_ARTIFACT_DIR="${CMAKE_CURRENT_BINARY_DIR}/voxel-artifacts")
        dk_target_defaults(dk_voxel_asset_gpu_probe)
        dk_deploy_slang(dk_voxel_asset_gpu_probe)
        add_test(NAME dk.voxels.assets_gpu_required COMMAND dk_voxel_asset_gpu_probe)
        set_tests_properties(dk.voxels.assets_gpu_required PROPERTIES TIMEOUT 300 RUN_SERIAL TRUE LABELS "gpu"
            ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1;VK_VALIDATION_VALIDATE_SYNC=1;DISABLE_LAYER_AMD_SWITCHABLE_GRAPHICS_1=1")
    endif()
endif()
if(TARGET dk_render_pathtracing)
    if(TARGET dk_render_disk)
        find_package(nlohmann_json CONFIG REQUIRED)
        add_executable(dk_pathtracing_benchmark PathBenchmark.cpp)
        set_target_properties(dk_pathtracing_benchmark PROPERTIES OUTPUT_NAME dk-pathtracing-benchmark)
        target_link_libraries(dk_pathtracing_benchmark PRIVATE dk::render_pathtracing dk::render_disk dk::profiling nlohmann_json::nlohmann_json)
        target_compile_definitions(dk_pathtracing_benchmark PRIVATE
            DK_PATH_SHADER_DIR="${PROJECT_SOURCE_DIR}/engine/render/pathtracing/shaders"
            DK_PATH_DISK_DIR="${PROJECT_SOURCE_DIR}/tests/fixtures/render-disk"
            DK_BENCH_CONFIG="$<CONFIG>" DK_BENCH_COMPILER="${CMAKE_CXX_COMPILER_ID}-${CMAKE_CXX_COMPILER_VERSION}")
        dk_target_defaults(dk_pathtracing_benchmark)
        dk_deploy_slang(dk_pathtracing_benchmark)
        find_package(Python3 3.11 QUIET COMPONENTS Interpreter)
        if(Python3_Interpreter_FOUND)
            add_test(NAME dk.pathtracing.benchmark_quality_gpu_required COMMAND "${Python3_EXECUTABLE}"
                "${PROJECT_SOURCE_DIR}/scripts/benchmark-pathtracing.py" --executable "$<TARGET_FILE:dk_pathtracing_benchmark>"
                --output "${PROJECT_BINARY_DIR}/test-artifacts/$<CONFIG>/path-benchmark-quality" --quality-only)
            set_tests_properties(dk.pathtracing.benchmark_quality_gpu_required PROPERTIES TIMEOUT 1200 RUN_SERIAL TRUE LABELS "gpu"
                ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1;VK_VALIDATION_VALIDATE_SYNC=1")
            add_test(NAME dk.pathtracing.benchmark_aggregation COMMAND "${CMAKE_COMMAND}" -E env "PYTHONDONTWRITEBYTECODE=1"
                "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/PathBenchmarkTest.py")
        endif()
    endif()
    add_executable(dk_pathtracing_probe PathTraceProbe.cpp)
    target_link_libraries(dk_pathtracing_probe PRIVATE dk::render_pathtracing dk::graphics_shaders dk::graphics_graph)
    target_include_directories(dk_pathtracing_probe PRIVATE "${PROJECT_SOURCE_DIR}/engine/graphics/device/src")
    target_compile_definitions(dk_pathtracing_probe PRIVATE DK_PATH_SHADER_DIR="${PROJECT_SOURCE_DIR}/engine/render/pathtracing/shaders")
    dk_target_defaults(dk_pathtracing_probe)
    dk_deploy_slang(dk_pathtracing_probe)
    if(TARGET dk_asset_voxel_importers)
        target_link_libraries(dk_pathtracing_probe PRIVATE dk::asset_voxel_importers)
        target_compile_definitions(dk_pathtracing_probe PRIVATE DK_PATH_VOXEL_TESTS=1)
        foreach(case IN ITEMS voxel_numeric voxel_lighting voxel_state voxel_restir_numeric voxel_restir_reuse voxel_signals voxel_restir_state voxel_medium_numeric voxel_medium_schedule voxel_medium_state voxel_medium_reuse)
            add_test(NAME dk.pathtracing.${case}_gpu_required COMMAND dk_pathtracing_probe ${case})
            set_tests_properties(dk.pathtracing.${case}_gpu_required PROPERTIES TIMEOUT 240 RUN_SERIAL TRUE LABELS "gpu"
                ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1;VK_VALIDATION_VALIDATE_SYNC=1")
        endforeach()
    endif()
    if(TARGET dk_asset_runtime AND TARGET dk_asset_importers)
        target_link_libraries(dk_pathtracing_probe PRIVATE dk::asset_runtime dk::asset_importers)
        target_compile_definitions(dk_pathtracing_probe PRIVATE DK_PATH_ASSET_DIR="${PROJECT_SOURCE_DIR}/tests/fixtures/assets")
        add_test(NAME dk.pathtracing.texture_assets_gpu_required COMMAND dk_pathtracing_probe texture_assets)
        set_tests_properties(dk.pathtracing.texture_assets_gpu_required PROPERTIES TIMEOUT 240 RUN_SERIAL TRUE LABELS "gpu"
            ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1;VK_VALIDATION_VALIDATE_SYNC=1")
    endif()
    foreach(case IN ITEMS signal_numeric signal_geometry signal_textures signal_state tile_group_images tile_group_state restir_medium_numeric restir_medium_lights restir_medium_cloud restir_medium_reuse restir_medium_schedule restir_medium_state restir_medium_failure restir_medium_support restir_medium_support_initial restir_spatial_support restir_spatial_edges restir_spatial_budget restir_spatial_numeric restir_spatial_schedule restir_spatial_state restir_temporal_boundaries restir_temporal_support restir_temporal_numeric restir_temporal_materials restir_temporal_schedule restir_temporal_state restir_numeric restir_materials restir_textures restir_schedule restir_state orthographic orthographic_medium medium_acceleration medium_acceleration_state cloud_numeric cloud_statistics cloud_surface cloud_progressive cloud_failure air_numeric air_statistics air_progressive air_failure air_resources progressive_images progressive_state progressive_failure progressive_budget progressive_lost analytic statistics images lifetime allocations ggx_numeric ggx_statistics ggx_indirect ggx_lifetime texture_numeric texture_mask texture_lifetime texture_disabled texture_allocations)
        add_test(NAME dk.pathtracing.${case}_gpu_required COMMAND dk_pathtracing_probe ${case})
        set_tests_properties(dk.pathtracing.${case}_gpu_required PROPERTIES TIMEOUT 240 RUN_SERIAL TRUE LABELS "gpu"
            ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1;VK_VALIDATION_VALIDATE_SYNC=1")
    endforeach()
    # Eight independent medium chains include hero/visibility variance at mixed receivers.
    set_tests_properties(dk.pathtracing.restir_medium_support_gpu_required PROPERTIES TIMEOUT 1200)
    set_tests_properties(dk.pathtracing.medium_acceleration_gpu_required PROPERTIES TIMEOUT 1200)
    # Eight 4096-epoch chains plus a 65536-spp CPU oracle reach/exceed 240s in Debug.
    # Keep the statistical work and thresholds intact; this is not a performance test.
    set_tests_properties(dk.pathtracing.restir_spatial_support_gpu_required
        dk.pathtracing.restir_temporal_support_gpu_required PROPERTIES TIMEOUT 600)
    # Low-roughness GGX uses 8 x 65536 paths x 64 CPU RIS candidates, in addition to other materials.
    set_tests_properties(dk.pathtracing.restir_materials_gpu_required PROPERTIES TIMEOUT 1200)
endif()
if(TARGET dk_render_pathtracing_reference)
    find_package(nlohmann_json CONFIG REQUIRED)
    add_executable(dk_restir_reference_benchmark RestirReferenceBenchmark.cpp)
    target_link_libraries(dk_restir_reference_benchmark PRIVATE dk::render_pathtracing_reference nlohmann_json::nlohmann_json)
    target_compile_definitions(dk_restir_reference_benchmark PRIVATE
        DK_BENCH_CONFIG="$<CONFIG>" DK_BENCH_COMPILER="${CMAKE_CXX_COMPILER_ID}-${CMAKE_CXX_COMPILER_VERSION}")
    dk_target_defaults(dk_restir_reference_benchmark)
    add_test(NAME dk.pathtracing.restir_reference_benchmark_cpu COMMAND dk_restir_reference_benchmark --smoke)
    set_tests_properties(dk.pathtracing.restir_reference_benchmark_cpu PROPERTIES TIMEOUT 120 LABELS "cpu")
endif()
if(TARGET dk_pathtracing_reference_demo)
    find_package(Python3 3.11 QUIET COMPONENTS Interpreter)
    if(Python3_Interpreter_FOUND)
        add_test(NAME dk.pathtracing.demo_cpu COMMAND "${Python3_EXECUTABLE}"
            "${CMAKE_CURRENT_SOURCE_DIR}/PathTraceReferenceDemoTest.py" "$<TARGET_FILE:dk_pathtracing_reference_demo>"
            "${PROJECT_BINARY_DIR}/test-artifacts/$<CONFIG>/pathtracing-reference")
        set_tests_properties(dk.pathtracing.demo_cpu PROPERTIES TIMEOUT 240 LABELS "cpu")
    endif()
endif()
if(TARGET dk_render_atmosphere)
    add_executable(dk_atmosphere_probe AtmosphereProbe.cpp)
    set_target_properties(dk_atmosphere_probe PROPERTIES OUTPUT_NAME dk-atmosphere-probe)
    target_link_libraries(dk_atmosphere_probe PRIVATE dk::render_atmosphere)
    target_include_directories(dk_atmosphere_probe PRIVATE "${PROJECT_SOURCE_DIR}/engine/graphics/device/src")
    target_compile_definitions(dk_atmosphere_probe PRIVATE DK_ATMOSPHERE_SHADER_DIR="${PROJECT_SOURCE_DIR}/engine/render/atmosphere/shaders")
    dk_target_defaults(dk_atmosphere_probe)
    dk_deploy_slang(dk_atmosphere_probe)
    foreach(case IN ITEMS reference multiple cache vacuum continuity)
        add_test(NAME dk.atmosphere.${case}_gpu_validation COMMAND dk_atmosphere_probe ${case})
        set_tests_properties(dk.atmosphere.${case}_gpu_validation PROPERTIES TIMEOUT 1200 RUN_SERIAL TRUE LABELS "gpu"
            ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1;VK_VALIDATION_VALIDATE_SYNC=1")
    endforeach()
endif()

if(TARGET dk_render_atmosphere_reference)
    find_package(Python3 3.11 QUIET COMPONENTS Interpreter)
    if(Python3_Interpreter_FOUND)
        add_test(NAME dk.atmosphere.benchmark_aggregation COMMAND "${CMAKE_COMMAND}" -E env "PYTHONDONTWRITEBYTECODE=1"
            "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/AtmosphereBenchmarkTest.py")
    endif()
endif()

if(TARGET dk_physics_xpbd)
    find_package(nlohmann_json CONFIG REQUIRED)
    add_executable(dk_simulation_benchmark SimulationBenchmark.cpp)
    set_target_properties(dk_simulation_benchmark PROPERTIES OUTPUT_NAME dk-simulation-benchmark)
    target_link_libraries(dk_simulation_benchmark PRIVATE dk::physics_xpbd dk::profiling nlohmann_json::nlohmann_json)
    target_compile_definitions(dk_simulation_benchmark PRIVATE
        DK_BENCH_COMPILER="${CMAKE_CXX_COMPILER_ID}-${CMAKE_CXX_COMPILER_VERSION}" DK_BENCH_CONFIG="$<CONFIG>")
    dk_target_defaults(dk_simulation_benchmark)
    add_test(NAME dk.simulation.benchmark_cpu COMMAND dk_simulation_benchmark --size 32 --output "${PROJECT_BINARY_DIR}/test-artifacts/$<CONFIG>/benchmark-cpu.json")
    set_tests_properties(dk.simulation.benchmark_cpu PROPERTIES TIMEOUT 60)
    add_test(NAME dk.simulation.benchmark_invalid COMMAND dk_simulation_benchmark --size 33
        --output "${PROJECT_BINARY_DIR}/test-artifacts/$<CONFIG>/benchmark-invalid.json")
    set_tests_properties(dk.simulation.benchmark_invalid PROPERTIES WILL_FAIL TRUE)
    find_package(Python3 3.11 QUIET COMPONENTS Interpreter)
    if(Python3_Interpreter_FOUND)
        add_test(NAME dk.simulation.benchmark_aggregation COMMAND "${CMAKE_COMMAND}" -E env "PYTHONDONTWRITEBYTECODE=1"
            "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/SimulationBenchmarkTest.py")
    endif()
    if(TARGET dk_render_simulation)
        target_link_libraries(dk_simulation_benchmark PRIVATE dk::render_simulation)
        target_compile_definitions(dk_simulation_benchmark PRIVATE DK_BENCH_GPU=1
            DK_XPBD_SHADER="${PROJECT_SOURCE_DIR}/shaders/physics/xpbd.slang" DK_CLOTH_SHADER="${PROJECT_SOURCE_DIR}/shaders/render/cloth.slang")
        dk_deploy_slang(dk_simulation_benchmark)
        add_test(NAME dk.simulation.benchmark_gpu COMMAND dk_simulation_benchmark --gpu --timestamps --validation --size 32
            --output "${PROJECT_BINARY_DIR}/test-artifacts/$<CONFIG>/benchmark-gpu.json")
        set_tests_properties(dk.simulation.benchmark_gpu PROPERTIES TIMEOUT 240 LABELS "gpu" RUN_SERIAL TRUE
            ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1;VK_VALIDATION_VALIDATE_SYNC=1")
    endif()
endif()
if(TARGET dk_render_simulation)
    find_package(nlohmann_json CONFIG REQUIRED)
    add_executable(dk_gpu_profiling_probe GpuProfilingProbe.cpp)
    set_target_properties(dk_gpu_profiling_probe PROPERTIES OUTPUT_NAME dk-gpu-profiling-probe)
    target_link_libraries(dk_gpu_profiling_probe PRIVATE dk::render_simulation dk::profiling nlohmann_json::nlohmann_json)
    target_include_directories(dk_gpu_profiling_probe PRIVATE "${PROJECT_SOURCE_DIR}/engine/graphics/device/src")
    target_compile_definitions(dk_gpu_profiling_probe PRIVATE DK_XPBD_SHADER="${PROJECT_SOURCE_DIR}/shaders/physics/xpbd.slang"
        DK_CLOTH_SHADER="${PROJECT_SOURCE_DIR}/shaders/render/cloth.slang")
    dk_target_defaults(dk_gpu_profiling_probe)
    dk_deploy_slang(dk_gpu_profiling_probe)
    add_test(NAME dk.profiling.gpu_validation COMMAND dk_gpu_profiling_probe "${PROJECT_BINARY_DIR}/test-artifacts/$<CONFIG>/gpu-profiling.json")
    set_tests_properties(dk.profiling.gpu_validation PROPERTIES TIMEOUT 120 SKIP_RETURN_CODE 77 LABELS "gpu" RUN_SERIAL TRUE
        ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1;VK_VALIDATION_VALIDATE_SYNC=1")
    add_executable(dk_gpu_xpbd_probe GpuXpbdProbe.cpp)
    set_target_properties(dk_gpu_xpbd_probe PROPERTIES OUTPUT_NAME dk-gpu-xpbd-probe)
    target_link_libraries(dk_gpu_xpbd_probe PRIVATE dk::render_simulation)
    target_include_directories(dk_gpu_xpbd_probe PRIVATE "${PROJECT_SOURCE_DIR}/engine/graphics/device/src")
    target_compile_definitions(dk_gpu_xpbd_probe PRIVATE DK_XPBD_SHADER="${PROJECT_SOURCE_DIR}/shaders/physics/xpbd.slang"
        DK_CLOTH_SHADER="${PROJECT_SOURCE_DIR}/shaders/render/cloth.slang")
    dk_target_defaults(dk_gpu_xpbd_probe)
    dk_deploy_slang(dk_gpu_xpbd_probe)
    add_test(NAME dk.xpbd.gpu_validation COMMAND dk_gpu_xpbd_probe "${PROJECT_BINARY_DIR}/test-artifacts/$<CONFIG>/gpu-xpbd")
    set_tests_properties(dk.xpbd.gpu_validation PROPERTIES TIMEOUT 240 SKIP_RETURN_CODE 77 LABELS "gpu" RUN_SERIAL TRUE
        ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1;VK_VALIDATION_VALIDATE_SYNC=1")
endif()
if(DK_BUILD_RENDER_DISK AND DK_BUILD_RENDER_PIPELINE)
    add_executable(dk_render_disk_probe RenderDiskProbe.cpp)
    set_target_properties(dk_render_disk_probe PROPERTIES OUTPUT_NAME dk-render-disk-probe)
    target_compile_definitions(dk_render_disk_probe PRIVATE DK_DISK_FIXTURE_DIR="${PROJECT_SOURCE_DIR}/tests/fixtures/render-disk"
        DK_RENDER_SHADER_DIR="${PROJECT_SOURCE_DIR}/shaders/render")
    target_include_directories(dk_render_disk_probe PRIVATE "${PROJECT_SOURCE_DIR}/engine/graphics/device/src")
    target_link_libraries(dk_render_disk_probe PRIVATE dk::render_disk dk::render_pipeline dk::asset_runtime)
    dk_target_defaults(dk_render_disk_probe)
    dk_deploy_slang(dk_render_disk_probe)
    add_test(NAME dk.render.disk_gpu_validation COMMAND dk_render_disk_probe)
    set_tests_properties(dk.render.disk_gpu_validation PROPERTIES TIMEOUT 120 SKIP_RETURN_CODE 77 LABELS "gpu"
        WORKING_DIRECTORY "${CMAKE_CURRENT_BINARY_DIR}" ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1;VK_VALIDATION_VALIDATE_SYNC=1")
    if(TARGET dk_render_demo)
        add_test(NAME dk.render.sponza_validation COMMAND dk_render_demo)
        set_tests_properties(dk.render.sponza_validation PROPERTIES TIMEOUT 180 SKIP_RETURN_CODE 77 LABELS "gpu;local-assets"
            WORKING_DIRECTORY "${CMAKE_CURRENT_BINARY_DIR}" ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1;VK_VALIDATION_VALIDATE_SYNC=1")
    endif()
endif()
if(DK_BUILD_RENDER_PIPELINE)
    if(TARGET dk_render_atmosphere)
        find_package(nlohmann_json CONFIG REQUIRED)
        add_executable(dk_atmosphere_benchmark AtmosphereBenchmark.cpp)
        set_target_properties(dk_atmosphere_benchmark PROPERTIES OUTPUT_NAME dk-atmosphere-benchmark)
        target_link_libraries(dk_atmosphere_benchmark PRIVATE dk::render_pipeline dk::render_atmosphere dk::profiling nlohmann_json::nlohmann_json)
        target_compile_definitions(dk_atmosphere_benchmark PRIVATE DK_RENDER_SHADER_DIR="${PROJECT_SOURCE_DIR}/shaders/render"
            DK_ATMOSPHERE_SHADER_DIR="${PROJECT_SOURCE_DIR}/engine/render/atmosphere/shaders"
            DK_BENCH_COMPILER="${CMAKE_CXX_COMPILER_ID}-${CMAKE_CXX_COMPILER_VERSION}" DK_BENCH_CONFIG="$<CONFIG>")
        dk_target_defaults(dk_atmosphere_benchmark)
        dk_deploy_slang(dk_atmosphere_benchmark)
        add_test(NAME dk.atmosphere.benchmark_gpu_validation COMMAND dk_atmosphere_benchmark --smoke --validation --timestamps
            --output "${PROJECT_BINARY_DIR}/test-artifacts/$<CONFIG>/atmosphere-benchmark.json")
        set_tests_properties(dk.atmosphere.benchmark_gpu_validation PROPERTIES TIMEOUT 240 RUN_SERIAL TRUE LABELS "gpu"
            ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1;VK_VALIDATION_VALIDATE_SYNC=1")
        add_executable(dk_surface_sunlight_probe SurfaceSunlightProbe.cpp)
        set_target_properties(dk_surface_sunlight_probe PROPERTIES OUTPUT_NAME dk-surface-sunlight-probe)
        target_link_libraries(dk_surface_sunlight_probe PRIVATE dk::render_pipeline dk::render_atmosphere)
        target_include_directories(dk_surface_sunlight_probe PRIVATE "${PROJECT_SOURCE_DIR}/engine/graphics/device/src")
        target_compile_definitions(dk_surface_sunlight_probe PRIVATE DK_RENDER_SHADER_DIR="${PROJECT_SOURCE_DIR}/shaders/render"
            DK_ATMOSPHERE_SHADER_DIR="${PROJECT_SOURCE_DIR}/engine/render/atmosphere/shaders")
        dk_target_defaults(dk_surface_sunlight_probe)
        dk_deploy_slang(dk_surface_sunlight_probe)
        foreach(case IN ITEMS normals direct diffuse failures)
            add_test(NAME dk.render.sunlight_${case}_gpu_validation COMMAND dk_surface_sunlight_probe ${case})
            set_tests_properties(dk.render.sunlight_${case}_gpu_validation PROPERTIES TIMEOUT 240 LABELS "gpu" RUN_SERIAL TRUE
                WORKING_DIRECTORY "${CMAKE_CURRENT_BINARY_DIR}" ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1;VK_VALIDATION_VALIDATE_SYNC=1")
        endforeach()
        add_executable(dk_aerial_perspective_probe AerialPerspectiveProbe.cpp)
        set_target_properties(dk_aerial_perspective_probe PROPERTIES OUTPUT_NAME dk-aerial-perspective-probe)
        target_link_libraries(dk_aerial_perspective_probe PRIVATE dk::render_pipeline dk::render_atmosphere)
        target_include_directories(dk_aerial_perspective_probe PRIVATE "${PROJECT_SOURCE_DIR}/engine/graphics/device/src")
        target_compile_definitions(dk_aerial_perspective_probe PRIVATE DK_RENDER_SHADER_DIR="${PROJECT_SOURCE_DIR}/shaders/render"
            DK_ATMOSPHERE_SHADER_DIR="${PROJECT_SOURCE_DIR}/engine/render/atmosphere/shaders")
        dk_target_defaults(dk_aerial_perspective_probe)
        dk_deploy_slang(dk_aerial_perspective_probe)
        foreach(case IN ITEMS numeric composition failures orthographic)
            add_test(NAME dk.render.aerial_${case}_gpu_validation COMMAND dk_aerial_perspective_probe ${case})
            set_tests_properties(dk.render.aerial_${case}_gpu_validation PROPERTIES TIMEOUT 240 LABELS "gpu" RUN_SERIAL TRUE
                WORKING_DIRECTORY "${CMAKE_CURRENT_BINARY_DIR}" ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1;VK_VALIDATION_VALIDATE_SYNC=1")
        endforeach()
    endif()
    add_executable(dk_render_pipeline_probe RenderPipelineProbe.cpp)
    set_target_properties(dk_render_pipeline_probe PROPERTIES OUTPUT_NAME "dk-render-pipeline-probe")
    target_compile_definitions(dk_render_pipeline_probe PRIVATE DK_RENDER_SHADER_DIR="${PROJECT_SOURCE_DIR}/shaders/render")
    target_include_directories(dk_render_pipeline_probe PRIVATE "${PROJECT_SOURCE_DIR}/engine/graphics/device/src")
    target_link_libraries(dk_render_pipeline_probe PRIVATE dk::render_pipeline dk::graphics_graph)
    dk_target_defaults(dk_render_pipeline_probe)
    dk_deploy_slang(dk_render_pipeline_probe)
    add_test(NAME dk.render.pipeline_gpu_validation COMMAND dk_render_pipeline_probe)
    set_tests_properties(dk.render.pipeline_gpu_validation PROPERTIES TIMEOUT 120 SKIP_RETURN_CODE 77 LABELS "gpu"
        WORKING_DIRECTORY "${CMAKE_CURRENT_BINARY_DIR}" ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1;VK_VALIDATION_VALIDATE_SYNC=1")
endif()
if(DK_BUILD_RENDER_RESOURCES)
    add_executable(dk_render_resources_probe RenderResourcesProbe.cpp)
    set_target_properties(dk_render_resources_probe PROPERTIES OUTPUT_NAME "dk-render-resources-probe")
    target_include_directories(dk_render_resources_probe PRIVATE "${PROJECT_SOURCE_DIR}/engine/graphics/device/src")
    target_link_libraries(dk_render_resources_probe PRIVATE dk::render_resources)
    dk_target_defaults(dk_render_resources_probe)
    add_test(NAME dk.render.gpu_resources COMMAND dk_render_resources_probe)
    add_test(NAME dk.render.gpu_validation COMMAND dk_render_resources_probe --validation)
    set_tests_properties(dk.render.gpu_resources dk.render.gpu_validation PROPERTIES TIMEOUT 120 SKIP_RETURN_CODE 77 LABELS "gpu")
    set_tests_properties(dk.render.gpu_validation PROPERTIES ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1;VK_VALIDATION_VALIDATE_SYNC=1")
endif()
if(DK_BUILD_GRAPHICS_GRAPH AND DK_BUILD_GRAPHICS_SHADERS)
    add_executable(dk_volume_image_probe VolumeImageProbe.cpp)
    set_target_properties(dk_volume_image_probe PROPERTIES OUTPUT_NAME dk-volume-image-probe)
    target_link_libraries(dk_volume_image_probe PRIVATE dk::graphics_graph dk::graphics_shaders)
    target_include_directories(dk_volume_image_probe PRIVATE "${PROJECT_SOURCE_DIR}/engine/graphics/device/src")
    target_compile_definitions(dk_volume_image_probe PRIVATE DK_VOLUME_SHADER_DIR="${PROJECT_SOURCE_DIR}/tests/fixtures/shaders")
    dk_target_defaults(dk_volume_image_probe)
    dk_deploy_slang(dk_volume_image_probe)
    add_test(NAME dk.graphics.volume_validation COMMAND dk_volume_image_probe)
    set_tests_properties(dk.graphics.volume_validation PROPERTIES TIMEOUT 120 LABELS "gpu" RUN_SERIAL TRUE
        ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1;VK_VALIDATION_VALIDATE_SYNC=1")
endif()
if(DK_BUILD_GRAPHICS_GRAPH)
    add_executable(dk_graph_probe GraphProbe.cpp)
    set_target_properties(dk_graph_probe PROPERTIES OUTPUT_NAME "dk-graph-probe")
    target_include_directories(dk_graph_probe PRIVATE "${PROJECT_SOURCE_DIR}/engine/graphics/device/src")
    target_link_libraries(dk_graph_probe PRIVATE dk::graphics_graph)
    dk_target_defaults(dk_graph_probe)
    add_test(NAME dk.graph.gpu_execution COMMAND dk_graph_probe)
    add_test(NAME dk.graph.gpu_validation COMMAND dk_graph_probe --validation)
    set_tests_properties(dk.graph.gpu_execution dk.graph.gpu_validation PROPERTIES TIMEOUT 120 SKIP_RETURN_CODE 77 LABELS "gpu")
    set_tests_properties(dk.graph.gpu_validation PROPERTIES ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1;VK_VALIDATION_VALIDATE_SYNC=1")
endif()
if(DK_BUILD_GRAPHICS_DEVICE AND DK_BUILD_GRAPHICS_SHADERS)
    if(DK_BUILD_GRAPHICS_GRAPH)
        add_executable(dk_graph_raytracing_probe GraphRayTracingProbe.cpp)
        target_include_directories(dk_graph_raytracing_probe PRIVATE "${PROJECT_SOURCE_DIR}/engine/graphics/device/src")
        target_compile_definitions(dk_graph_raytracing_probe PRIVATE DK_RT_SHADER="${PROJECT_SOURCE_DIR}/tests/fixtures/shaders/raytracing.slang")
        target_link_libraries(dk_graph_raytracing_probe PRIVATE dk::graphics_graph dk::graphics_shaders)
        dk_target_defaults(dk_graph_raytracing_probe)
        dk_deploy_slang(dk_graph_raytracing_probe)
        add_test(NAME dk.graph.rt_required_validation COMMAND dk_graph_raytracing_probe)
        set_tests_properties(dk.graph.rt_required_validation PROPERTIES TIMEOUT 120 RUN_SERIAL TRUE LABELS "gpu"
            ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1;VK_VALIDATION_VALIDATE_SYNC=1")
    endif()
    add_executable(dk_raytracing_probe RayTracingProbe.cpp)
    target_include_directories(dk_raytracing_probe PRIVATE "${PROJECT_SOURCE_DIR}/engine/graphics/device/src")
    target_compile_definitions(dk_raytracing_probe PRIVATE DK_RT_SHADER="${PROJECT_SOURCE_DIR}/tests/fixtures/shaders/raytracing.slang")
    target_link_libraries(dk_raytracing_probe PRIVATE dk::graphics_device dk::graphics_shaders)
    dk_target_defaults(dk_raytracing_probe)
    dk_deploy_slang(dk_raytracing_probe)
    add_test(NAME dk.raytracing.required_validation COMMAND dk_raytracing_probe)
    set_tests_properties(dk.raytracing.required_validation PROPERTIES TIMEOUT 120 RUN_SERIAL TRUE LABELS "gpu"
        ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1;VK_VALIDATION_VALIDATE_SYNC=1")
endif()
if(TARGET dk_shaderc)
    add_test(NAME dk.shaderc.process COMMAND "${CMAKE_COMMAND}"
        "-DSHADERC=$<TARGET_FILE:dk_shaderc>"
        "-DFIXTURES=${PROJECT_SOURCE_DIR}/tests/fixtures/shaders"
        "-DWORK_DIR=${CMAKE_CURRENT_BINARY_DIR}/test-artifacts/$<CONFIG>"
        -P "${CMAKE_CURRENT_SOURCE_DIR}/ShadercProcessTests.cmake")
    set_tests_properties(dk.shaderc.process PROPERTIES TIMEOUT 120 LABELS "cpu")
    if(WIN32)
        add_test(NAME dk.shaderc.deployment COMMAND "${CMAKE_COMMAND}"
            "-DSHADERC=$<TARGET_FILE:dk_shaderc>"
            "-DSLANG=$<TARGET_FILE:slang::slang>"
            "-DOPTIMIZER=$<TARGET_FILE:slang::slang-glslang>"
            "-DSOURCE=${PROJECT_SOURCE_DIR}/shaders/common/transform.slang"
            "-DWORK_DIR=${CMAKE_CURRENT_BINARY_DIR}/test-artifacts/$<CONFIG>"
            -P "${CMAKE_CURRENT_SOURCE_DIR}/ShadercDeploymentTests.cmake")
        set_tests_properties(dk.shaderc.deployment PROPERTIES TIMEOUT 120 LABELS "cpu")
    endif()
endif()
if(TARGET dk_assetc)
    if(TARGET dk_asset_voxel_importers)
        add_test(NAME dk.assetc.voxelize_process COMMAND "${CMAKE_COMMAND}"
            "-DASSETC=$<TARGET_FILE:dk_assetc>" "-DFIXTURES=${PROJECT_SOURCE_DIR}/tests/fixtures/assets"
            "-DWORK_DIR=${PROJECT_BINARY_DIR}/test-artifacts/$<CONFIG>"
            -P "${CMAKE_CURRENT_SOURCE_DIR}/MeshVoxelizeProcessTest.cmake")
        set_tests_properties(dk.assetc.voxelize_process PROPERTIES TIMEOUT 120)
    endif()
    add_test(NAME dk.assetc.process COMMAND "${CMAKE_COMMAND}"
        "-DASSETC=$<TARGET_FILE:dk_assetc>"
        "-DFIXTURES=${PROJECT_SOURCE_DIR}/tests/fixtures/assets"
        "-DWORK_DIR=${CMAKE_CURRENT_BINARY_DIR}/test-artifacts/$<CONFIG>"
        -P "${CMAKE_CURRENT_SOURCE_DIR}/AssetcProcessTests.cmake")
    set_tests_properties(dk.assetc.process PROPERTIES TIMEOUT 120)
    add_test(NAME dk.assetc.cache_process COMMAND "${CMAKE_COMMAND}"
        "-DASSETC=$<TARGET_FILE:dk_assetc>"
        "-DFIXTURES=${PROJECT_SOURCE_DIR}/tests/fixtures/assets"
        "-DWORK_DIR=${CMAKE_CURRENT_BINARY_DIR}/test-artifacts/$<CONFIG>"
        -P "${CMAKE_CURRENT_SOURCE_DIR}/AssetCacheProcessTests.cmake")
    set_tests_properties(dk.assetc.cache_process PROPERTIES TIMEOUT 120)
endif()

if(DK_BUILD_PLATFORM)
    find_package(SDL3 CONFIG REQUIRED)
    find_package(SDL3 CONFIG REQUIRED)
    add_executable(dk_platform_probe PlatformProbe.cpp)
    target_include_directories(dk_platform_probe PRIVATE "${PROJECT_SOURCE_DIR}/engine/platform/src")
    target_link_libraries(dk_platform_probe PRIVATE dk::platform SDL3::SDL3)
    dk_target_defaults(dk_platform_probe)
    add_test(NAME dk.platform.windows COMMAND dk_platform_probe)
    set_tests_properties(dk.platform.windows PROPERTIES TIMEOUT 30 LABELS "desktop")
endif()
if(TARGET dk_presentation_demo)
    add_test(NAME dk.presentation.example_smoke COMMAND dk_presentation_demo --validation --frames 8)
    set_tests_properties(dk.presentation.example_smoke PROPERTIES TIMEOUT 60 SKIP_RETURN_CODE 77 LABELS "gpu;desktop"
        PASS_REGULAR_EXPRESSION "presented=8.*errors=0 warnings=0"
        ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1;VK_VALIDATION_VALIDATE_SYNC=1")
endif()
if(DK_BUILD_GRAPHICS_PRESENTATION)
    add_executable(dk_present_device_probe PresentDeviceProbe.cpp)
    target_link_libraries(dk_present_device_probe PRIVATE dk::graphics_presentation)
    dk_target_defaults(dk_present_device_probe)
    add_test(NAME dk.presentation.device_validation COMMAND dk_present_device_probe)
    set_tests_properties(dk.presentation.device_validation PROPERTIES TIMEOUT 60 SKIP_RETURN_CODE 77 LABELS "gpu;desktop")
    if(DK_BUILD_GRAPHICS_SHADERS)
        add_executable(dk_presentation_probe PresentationProbe.cpp)
        target_compile_definitions(dk_presentation_probe PRIVATE DK_COMMON_SHADER_DIR="${PROJECT_SOURCE_DIR}/shaders/common")
        target_include_directories(dk_presentation_probe PRIVATE "${PROJECT_SOURCE_DIR}/engine/graphics/presentation/src"
            "${PROJECT_SOURCE_DIR}/engine/graphics/device/src")
        target_link_libraries(dk_presentation_probe PRIVATE dk::graphics_presentation dk::graphics_shaders)
        dk_target_defaults(dk_presentation_probe)
        dk_deploy_slang(dk_presentation_probe)
        add_test(NAME dk.presentation.frames_validation COMMAND dk_presentation_probe)
        add_test(NAME dk.presentation.recovery_validation COMMAND dk_presentation_probe --recovery)
        set_tests_properties(dk.presentation.frames_validation dk.presentation.recovery_validation PROPERTIES TIMEOUT 120 SKIP_RETURN_CODE 77 LABELS "gpu;desktop"
            ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1;VK_VALIDATION_VALIDATE_SYNC=1")
    endif()
endif()
if(DK_BUILD_GRAPHICS_OFFSCREEN)
    add_executable(dk_offscreen_probe OffscreenProbe.cpp GraphPipeline.cpp)
    set_target_properties(dk_offscreen_probe PROPERTIES OUTPUT_NAME "dk-offscreen-probe")
    target_compile_definitions(dk_offscreen_probe PRIVATE DK_COMMON_SHADER_DIR="${PROJECT_SOURCE_DIR}/shaders/common")
    target_include_directories(dk_offscreen_probe PRIVATE "${PROJECT_SOURCE_DIR}/engine/graphics/offscreen/src"
        "${PROJECT_SOURCE_DIR}/engine/graphics/device/src")
    target_link_libraries(dk_offscreen_probe PRIVATE dk::graphics_offscreen dk::graphics_graph)
    dk_target_defaults(dk_offscreen_probe)
    dk_deploy_slang(dk_offscreen_probe)
    add_test(NAME dk.offscreen.gpu_execute COMMAND dk_offscreen_probe)
    add_test(NAME dk.offscreen.gpu_validation COMMAND dk_offscreen_probe --validation)
    set_tests_properties(dk.offscreen.gpu_execute dk.offscreen.gpu_validation PROPERTIES
        TIMEOUT 120 SKIP_RETURN_CODE 77 LABELS "gpu" WORKING_DIRECTORY "${CMAKE_CURRENT_BINARY_DIR}")
    set_tests_properties(dk.offscreen.gpu_validation PROPERTIES ENVIRONMENT
        "VK_LAYER_VALIDATE_SYNC=1;VK_VALIDATION_VALIDATE_SYNC=1")
endif()
if(DK_BUILD_GRAPHICS_DEVICE)
    add_executable(dk_acceleration_structure_probe AccelerationStructureProbe.cpp)
    target_include_directories(dk_acceleration_structure_probe PRIVATE "${PROJECT_SOURCE_DIR}/engine/graphics/device/src")
    target_link_libraries(dk_acceleration_structure_probe PRIVATE dk::graphics_device)
    dk_target_defaults(dk_acceleration_structure_probe)
    add_test(NAME dk.acceleration.required_validation COMMAND dk_acceleration_structure_probe)
    set_tests_properties(dk.acceleration.required_validation PROPERTIES TIMEOUT 90 LABELS "gpu" RUN_SERIAL TRUE
        ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1;VK_VALIDATION_VALIDATE_SYNC=1")
    add_executable(dk_raytracing_device_probe RayTracingDeviceProbe.cpp)
    target_link_libraries(dk_raytracing_device_probe PRIVATE dk::graphics_device)
    dk_target_defaults(dk_raytracing_device_probe)
    add_test(NAME dk.device.rt_required_validation COMMAND dk_raytracing_device_probe)
    set_tests_properties(dk.device.rt_required_validation PROPERTIES TIMEOUT 90 LABELS "gpu" RUN_SERIAL TRUE
        ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1;VK_VALIDATION_VALIDATE_SYNC=1")
    add_executable(dk_graphics_resource_probe GraphicsResourceProbe.cpp)
    add_executable(dk_image_transfer_probe ImageTransferProbe.cpp)
    target_link_libraries(dk_image_transfer_probe PRIVATE dk::graphics_device)
    target_include_directories(dk_image_transfer_probe PRIVATE "${PROJECT_SOURCE_DIR}/engine/graphics/device/src")
    dk_target_defaults(dk_image_transfer_probe)
    add_test(NAME dk.graphics.image_transfer_validation COMMAND dk_image_transfer_probe)
    set_tests_properties(dk.graphics.image_transfer_validation PROPERTIES TIMEOUT 60 SKIP_RETURN_CODE 77 LABELS "gpu" RUN_SERIAL TRUE
        ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1;VK_VALIDATION_VALIDATE_SYNC=1")
    set_target_properties(dk_graphics_resource_probe PROPERTIES OUTPUT_NAME "dk-graphics-resource-probe")
    target_include_directories(dk_graphics_resource_probe PRIVATE "${PROJECT_SOURCE_DIR}/engine/graphics/device/src")
    target_link_libraries(dk_graphics_resource_probe PRIVATE dk::graphics_device)
    dk_target_defaults(dk_graphics_resource_probe)
    add_test(NAME dk.graphics.gpu_resources COMMAND dk_graphics_resource_probe)
    add_test(NAME dk.graphics.gpu_resources_validation COMMAND dk_graphics_resource_probe --validation)
    set_tests_properties(dk.graphics.gpu_resources dk.graphics.gpu_resources_validation PROPERTIES TIMEOUT 120 SKIP_RETURN_CODE 77 LABELS "gpu")
    # SDK 1.4.321 uses VK_LAYER_; newer validation layers use VK_VALIDATION_.
    set_tests_properties(dk.graphics.gpu_resources_validation PROPERTIES ENVIRONMENT
        "VK_LAYER_VALIDATE_SYNC=1;VK_VALIDATION_VALIDATE_SYNC=1")
    add_executable(dk_device_probe DeviceProbe.cpp)
    set_target_properties(dk_device_probe PROPERTIES OUTPUT_NAME "dk-device-probe")
    target_link_libraries(dk_device_probe PRIVATE dk::graphics_device)
    dk_target_defaults(dk_device_probe)
    add_test(NAME dk.device.gpu_smoke COMMAND dk_device_probe)
    add_test(NAME dk.device.gpu_validation COMMAND dk_device_probe --validation)
    set_tests_properties(dk.device.gpu_smoke dk.device.gpu_validation PROPERTIES TIMEOUT 60 SKIP_RETURN_CODE 77 LABELS "gpu")
endif()

add_executable(dk_profiling_probe ProfilingProbe.cpp)
target_link_libraries(dk_profiling_probe PRIVATE dk::profiling)
find_package(Threads REQUIRED)
if(DK_BUILD_MEMORY)
    add_executable(dk_memory_benchmark MemoryBenchmark.cpp)
    target_link_libraries(dk_memory_benchmark PRIVATE dk::memory dk::profiling Threads::Threads)
    target_compile_definitions(dk_memory_benchmark PRIVATE DK_BENCH_CONFIGURATION="$<CONFIG>")
    dk_target_defaults(dk_memory_benchmark)
    add_test(NAME dk.memory.benchmark_smoke COMMAND dk_memory_benchmark)
    set_tests_properties(dk.memory.benchmark_smoke PROPERTIES
        TIMEOUT 60 PASS_REGULAR_EXPRESSION "\"status\":\"passed\",\"case_count\":40")
    add_test(NAME dk.memory.benchmark_invalid_argument COMMAND "${CMAKE_COMMAND}"
        "-DBENCHMARK=$<TARGET_FILE:dk_memory_benchmark>" -DARGUMENT=--rounds -DVALUE=0
        "-DEXPECTED=invalid bounded benchmark parameter" -P "${CMAKE_CURRENT_SOURCE_DIR}/MemoryBenchmarkFailure.cmake")
    add_test(NAME dk.memory.benchmark_partial_failure COMMAND "${CMAKE_COMMAND}"
        "-DBENCHMARK=$<TARGET_FILE:dk_memory_benchmark>" -DARGUMENT=--allocation-budget -DVALUE=64
        "-DEXPECTED=heap allocation" -P "${CMAKE_CURRENT_SOURCE_DIR}/MemoryBenchmarkFailure.cmake")
    set_tests_properties(dk.memory.benchmark_invalid_argument dk.memory.benchmark_partial_failure PROPERTIES TIMEOUT 15)
    add_executable(dk_context_probe ContextProbe.cpp)
    target_link_libraries(dk_context_probe PRIVATE dk::memory dk::profiling Threads::Threads)
    dk_target_defaults(dk_context_probe)
    add_test(NAME dk.memory.context_probe COMMAND dk_context_probe)
    set_tests_properties(dk.memory.context_probe PROPERTIES
        TIMEOUT 15 PASS_REGULAR_EXPRESSION "\"status\":\"passed\".*\"systems\":2,\"tasks\":3")
    add_executable(dk_pool_probe PoolProbe.cpp)
    target_link_libraries(dk_pool_probe PRIVATE dk::memory dk::profiling Threads::Threads)
    dk_target_defaults(dk_pool_probe)
    add_test(NAME dk.memory.pool_probe COMMAND dk_pool_probe)
    set_tests_properties(dk.memory.pool_probe PROPERTIES
        TIMEOUT 15 PASS_REGULAR_EXPRESSION "\"status\":\"passed\".*\"requests\":192")
    add_executable(dk_arena_probe ArenaProbe.cpp)
    target_link_libraries(dk_arena_probe PRIVATE dk::memory dk::profiling Threads::Threads)
    dk_target_defaults(dk_arena_probe)
    add_test(NAME dk.memory.arena_probe COMMAND dk_arena_probe)
    set_tests_properties(dk.memory.arena_probe PROPERTIES
        TIMEOUT 15 PASS_REGULAR_EXPRESSION "arena=(on|off);chunks=3;requests=102")
    add_executable(dk_memory_probe MemoryProbe.cpp)
    target_link_libraries(dk_memory_probe PRIVATE dk::memory dk::profiling Threads::Threads)
    dk_target_defaults(dk_memory_probe)
    add_test(NAME dk.memory.probe COMMAND dk_memory_probe)
    set_tests_properties(dk.memory.probe PROPERTIES
        TIMEOUT 15 PASS_REGULAR_EXPRESSION "memory=(on|off);allocations=36")
endif()
target_link_libraries(dk_profiling_probe PRIVATE Threads::Threads)
dk_target_defaults(dk_profiling_probe)
add_test(NAME dk.profiling.smoke COMMAND dk_profiling_probe)
set_tests_properties(dk.profiling.smoke PROPERTIES
    TIMEOUT 15 PASS_REGULAR_EXPRESSION "profiling=(on|off);checksum=8128")

# Compile in isolation even in the ON build: no Tracy include path or link usage.
add_executable(dk_profiling_disabled_test ProfilingDisabledTest.cpp)
target_include_directories(dk_profiling_disabled_test PRIVATE
    "${PROJECT_SOURCE_DIR}/engine/foundation/profiling/include")
target_compile_definitions(dk_profiling_disabled_test PRIVATE DK_ENABLE_PROFILING=0)
dk_target_defaults(dk_profiling_disabled_test)
add_test(NAME dk.profiling.disabled_no_side_effects COMMAND dk_profiling_disabled_test)

if(TARGET dk_run)
    add_test(NAME dk.bootstrap.version COMMAND dk_run --version)
    string(REPLACE "." "\\." _dk_version_regex "${PROJECT_VERSION}")
    set_tests_properties(dk.bootstrap.version PROPERTIES
        PASS_REGULAR_EXPRESSION "DeckerEngine ${_dk_version_regex}")
endif()
if(TARGET dk_asset_services AND WIN32)
    add_executable(dk_asset_recovery_probe AssetRecoveryProbe.cpp)
    target_include_directories(dk_asset_recovery_probe PRIVATE "${PROJECT_SOURCE_DIR}/engine/assets/runtime/src")
    target_link_libraries(dk_asset_recovery_probe PRIVATE dk::asset_services)
    dk_target_defaults(dk_asset_recovery_probe)
    foreach(kind IN ITEMS registration rename)
        foreach(point IN ITEMS source meta manifest finish)
            add_test(NAME dk.assets.restart_${kind}_${point}
                COMMAND "${CMAKE_COMMAND}" "-DPROBE=$<TARGET_FILE:dk_asset_recovery_probe>"
                    "-DWORK_DIR=${CMAKE_CURRENT_BINARY_DIR}/test-artifacts/$<CONFIG>/assets"
                    "-DKIND=${kind}" "-DPOINT=${point}" -P "${CMAKE_CURRENT_SOURCE_DIR}/AssetRecoveryTest.cmake")
            set_tests_properties(dk.assets.restart_${kind}_${point} PROPERTIES TIMEOUT 30)
        endforeach()
    endforeach()
endif()
if(TARGET dk_runtime AND TARGET dk_run AND WIN32)
    find_package(Python3 3.11 QUIET COMPONENTS Interpreter)
    if(Python3_Interpreter_FOUND)
        add_test(NAME dk.environment.process COMMAND "${CMAKE_COMMAND}" -E env "PYTHONDONTWRITEBYTECODE=1"
            "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/EnvironmentProcessTest.py"
            --runner "$<TARGET_FILE:dk_run>" --example "${PROJECT_SOURCE_DIR}/examples/automation/environment.jsonl"
            --work "${CMAKE_CURRENT_BINARY_DIR}/test-artifacts/$<CONFIG>/environment")
        set_tests_properties(dk.environment.process PROPERTIES TIMEOUT 60 LABELS "cpu")
    endif()
    if(TARGET dk_scripting_luau)
        add_test(NAME dk.luau.runner_roundtrip
            COMMAND "${CMAKE_COMMAND}"
                "-DRUNNER=$<TARGET_FILE:dk_run>"
                "-DEXAMPLE=${PROJECT_SOURCE_DIR}/examples/scripting/create-scene.luau"
                "-DWORK_DIR=${CMAKE_CURRENT_BINARY_DIR}/test-artifacts/$<CONFIG>/luau"
                -P "${CMAKE_CURRENT_SOURCE_DIR}/LuauRunnerTest.cmake")
        set_tests_properties(dk.luau.runner_roundtrip PROPERTIES TIMEOUT 60)
    endif()
    find_program(DK_POWERSHELL NAMES pwsh powershell REQUIRED)
    if(TARGET dk_ctl)
        find_package(Python3 3.11 QUIET COMPONENTS Interpreter)
        if(Python3_Interpreter_FOUND)
            add_test(NAME dk.simulation.response_aggregation
                COMMAND "${CMAKE_COMMAND}" -E env "PYTHONDONTWRITEBYTECODE=1" "${Python3_EXECUTABLE}"
                    "${CMAKE_CURRENT_SOURCE_DIR}/SimulationResponseTest.py")
            set_tests_properties(dk.simulation.response_aggregation PROPERTIES TIMEOUT 30 LABELS "cpu")
            if(TARGET dk_render_simulation)
                foreach(host IN ITEMS runner editor)
                    if(host STREQUAL "editor" AND NOT TARGET dk_editor_app)
                        continue()
                    endif()
                    set(_dk_response_editor)
                    if(host STREQUAL "editor")
                        set(_dk_response_editor --editor "$<TARGET_FILE:dk_editor_app>" --gui-validation required)
                    endif()
                    add_test(NAME dk.simulation.response_${host}_smoke
                        COMMAND "${CMAKE_COMMAND}" -E env "PYTHONDONTWRITEBYTECODE=1" "${Python3_EXECUTABLE}"
                            "${PROJECT_SOURCE_DIR}/scripts/benchmark-simulation-response.py"
                            --runner "$<TARGET_FILE:dk_run>" --ctl "$<TARGET_FILE:dk_ctl>" ${_dk_response_editor}
                            --smoke --hosts ${host} --sizes 8 --backends gpu)
                    set_tests_properties(dk.simulation.response_${host}_smoke PROPERTIES TIMEOUT 180 LABELS "gpu" RUN_SERIAL TRUE)
                endforeach()
            endif()
            foreach(kind IN ITEMS cpu gpu)
                if(kind STREQUAL "gpu" AND NOT TARGET dk_render_simulation)
                    continue()
                endif()
                set(_dk_task_extra)
                if(kind STREQUAL "gpu")
                    set(_dk_task_extra --gpu)
                endif()
                add_test(NAME dk.simulation.task_${kind}
                    COMMAND "${CMAKE_COMMAND}" -E env "PYTHONPATH=${PROJECT_SOURCE_DIR}/sdk/python"
                        "PYTHONDONTWRITEBYTECODE=1" "${Python3_EXECUTABLE}"
                        "${CMAKE_CURRENT_SOURCE_DIR}/SimulationTaskTest.py"
                        --runner "$<TARGET_FILE:dk_run>" --client "$<TARGET_FILE:dk_ctl>"
                        --work-dir "${PROJECT_BINARY_DIR}/test-artifacts/$<CONFIG>/simulation-tasks" ${_dk_task_extra})
                set_tests_properties(dk.simulation.task_${kind} PROPERTIES TIMEOUT 180 LABELS "${kind}")
                if(kind STREQUAL "gpu")
                    set_tests_properties(dk.simulation.task_gpu PROPERTIES RUN_SERIAL TRUE ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1")
                endif()
            endforeach()
            if(TARGET dk_editor_app AND TARGET dk_render_simulation)
                add_test(NAME dk.simulation.task_editor_gpu
                    COMMAND "${CMAKE_COMMAND}" -E env "PYTHONPATH=${PROJECT_SOURCE_DIR}/sdk/python"
                        "PYTHONDONTWRITEBYTECODE=1" "${Python3_EXECUTABLE}"
                        "${CMAKE_CURRENT_SOURCE_DIR}/SimulationEditorTaskTest.py"
                        --editor "$<TARGET_FILE:dk_editor_app>" --client "$<TARGET_FILE:dk_ctl>"
                        --work-dir "${PROJECT_BINARY_DIR}/test-artifacts/$<CONFIG>/simulation-tasks")
                set_tests_properties(dk.simulation.task_editor_gpu PROPERTIES TIMEOUT 180 SKIP_RETURN_CODE 77
                    LABELS "gpu" RUN_SERIAL TRUE ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1;VK_VALIDATION_VALIDATE_SYNC=1")
            endif()
            if(TARGET dk_render_simulation AND TARGET dk_scripting_luau)
                add_test(NAME dk.simulation.experiment_gpu
                    COMMAND "${CMAKE_COMMAND}" -E env "PYTHONPATH=${PROJECT_SOURCE_DIR}/sdk/python"
                        "PYTHONDONTWRITEBYTECODE=1" "${Python3_EXECUTABLE}"
                        "${CMAKE_CURRENT_SOURCE_DIR}/SimulationExperimentTest.py"
                        --runner "$<TARGET_FILE:dk_run>" --client "$<TARGET_FILE:dk_ctl>"
                        --example "${PROJECT_SOURCE_DIR}/examples/automation/cloth_experiment.py"
                        --luau "${PROJECT_SOURCE_DIR}/examples/scripting/gpu-experiment.luau"
                        --work-dir "${PROJECT_BINARY_DIR}/test-artifacts/$<CONFIG>/simulation-experiments")
                set_tests_properties(dk.simulation.experiment_gpu PROPERTIES TIMEOUT 300 SKIP_RETURN_CODE 77 LABELS "gpu" RUN_SERIAL TRUE
                    ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1")
            endif()
            foreach(mode IN ITEMS stdio pipe)
                add_test(NAME dk.simulation.${mode}
                    COMMAND "${CMAKE_COMMAND}" -E env "PYTHONPATH=${PROJECT_SOURCE_DIR}/sdk/python"
                        "PYTHONDONTWRITEBYTECODE=1" "${Python3_EXECUTABLE}"
                        "${CMAKE_CURRENT_SOURCE_DIR}/SimulationTest.py"
                        --runner "$<TARGET_FILE:dk_run>" --client "$<TARGET_FILE:dk_ctl>"
                        --work-dir "${PROJECT_BINARY_DIR}/test-artifacts/$<CONFIG>/simulation" --mode ${mode})
                set_tests_properties(dk.simulation.${mode} PROPERTIES TIMEOUT 45 LABELS "cpu")
            endforeach()
            add_test(NAME dk.python.unit
                COMMAND "${CMAKE_COMMAND}" -E env "PYTHONPATH=${PROJECT_SOURCE_DIR}/sdk/python"
                    "PYTHONDONTWRITEBYTECODE=1" "${Python3_EXECUTABLE}" -m unittest discover
                    -s "${PROJECT_SOURCE_DIR}/sdk/python/tests" -v)
            set_tests_properties(dk.python.unit PROPERTIES TIMEOUT 30)
            add_test(NAME dk.experiments.unit
                COMMAND "${CMAKE_COMMAND}" -E env "PYTHONPATH=${PROJECT_SOURCE_DIR}/sdk/python"
                    "PYTHONDONTWRITEBYTECODE=1" "${Python3_EXECUTABLE}" -m unittest discover
                    -s "${PROJECT_SOURCE_DIR}/sdk/python/tests" -p test_experiments.py -v)
            set_tests_properties(dk.experiments.unit PROPERTIES TIMEOUT 30)
            add_test(NAME dk.experiments.batch_unit
                COMMAND "${CMAKE_COMMAND}" -E env "PYTHONPATH=${PROJECT_SOURCE_DIR}/sdk/python"
                    "PYTHONDONTWRITEBYTECODE=1" "${Python3_EXECUTABLE}" -m unittest discover
                    -s "${PROJECT_SOURCE_DIR}/sdk/python/tests" -p test_experiment_batch.py -v)
            set_tests_properties(dk.experiments.batch_unit PROPERTIES TIMEOUT 45)
            add_test(NAME dk.experiments.recovery_unit
                COMMAND "${CMAKE_COMMAND}" -E env "PYTHONPATH=${PROJECT_SOURCE_DIR}/sdk/python"
                    "PYTHONDONTWRITEBYTECODE=1" "${Python3_EXECUTABLE}" -m unittest discover
                    -s "${PROJECT_SOURCE_DIR}/sdk/python/tests" -p test_experiment_recovery.py -v)
            set_tests_properties(dk.experiments.recovery_unit PROPERTIES TIMEOUT 60)
            add_test(NAME dk.experiments.report_unit
                COMMAND "${CMAKE_COMMAND}" -E env "PYTHONPATH=${PROJECT_SOURCE_DIR}/sdk/python"
                    "PYTHONDONTWRITEBYTECODE=1" "${Python3_EXECUTABLE}" -m unittest discover
                    -s "${PROJECT_SOURCE_DIR}/sdk/python/tests" -p test_experiment_report.py -v)
            set_tests_properties(dk.experiments.report_unit PROPERTIES TIMEOUT 60)
            foreach(kind IN ITEMS cpu gpu)
                if(kind STREQUAL "gpu" AND NOT TARGET dk_render_simulation)
                    continue()
                endif()
                set(_dk_experiment_extra)
                if(kind STREQUAL "gpu")
                    set(_dk_experiment_extra --gpu)
                endif()
                add_test(NAME dk.experiments.index_${kind}
                    COMMAND "${CMAKE_COMMAND}" -E env "PYTHONPATH=${PROJECT_SOURCE_DIR}/sdk/python"
                        "PYTHONDONTWRITEBYTECODE=1" "${Python3_EXECUTABLE}"
                        "${CMAKE_CURRENT_SOURCE_DIR}/ExperimentIndexTest.py"
                        --runner "$<TARGET_FILE:dk_run>" --client "$<TARGET_FILE:dk_ctl>"
                        --work-dir "${PROJECT_BINARY_DIR}/test-artifacts/$<CONFIG>/experiment-index"
                        ${_dk_experiment_extra})
                set_tests_properties(dk.experiments.index_${kind} PROPERTIES TIMEOUT 150)
                set(_dk_batch_extra ${_dk_experiment_extra})
                if(kind STREQUAL "cpu" AND NOT TARGET dk_render_simulation)
                    list(APPEND _dk_batch_extra --cpu-only)
                endif()
                add_test(NAME dk.experiments.batch_${kind}
                    COMMAND "${CMAKE_COMMAND}" -E env "PYTHONPATH=${PROJECT_SOURCE_DIR}/sdk/python"
                        "PYTHONDONTWRITEBYTECODE=1" "${Python3_EXECUTABLE}"
                        "${CMAKE_CURRENT_SOURCE_DIR}/ExperimentBatchTest.py"
                        --runner "$<TARGET_FILE:dk_run>" --client "$<TARGET_FILE:dk_ctl>"
                        --work-dir "${PROJECT_BINARY_DIR}/test-artifacts/$<CONFIG>/experiment-batch"
                        ${_dk_batch_extra})
                set_tests_properties(dk.experiments.batch_${kind} PROPERTIES TIMEOUT 240)
                add_test(NAME dk.experiments.recovery_${kind}
                    COMMAND "${CMAKE_COMMAND}" -E env "PYTHONPATH=${PROJECT_SOURCE_DIR}/sdk/python"
                        "PYTHONDONTWRITEBYTECODE=1" "${Python3_EXECUTABLE}"
                        "${CMAKE_CURRENT_SOURCE_DIR}/ExperimentRecoveryTest.py"
                        --runner "$<TARGET_FILE:dk_run>" --client "$<TARGET_FILE:dk_ctl>"
                        --work-dir "${PROJECT_BINARY_DIR}/test-artifacts/$<CONFIG>/experiment-recovery"
                        ${_dk_experiment_extra})
                set_tests_properties(dk.experiments.recovery_${kind} PROPERTIES TIMEOUT 300)
                add_test(NAME dk.experiments.report_${kind}
                    COMMAND "${CMAKE_COMMAND}" -E env "PYTHONPATH=${PROJECT_SOURCE_DIR}/sdk/python"
                        "PYTHONDONTWRITEBYTECODE=1" "${Python3_EXECUTABLE}"
                        "${CMAKE_CURRENT_SOURCE_DIR}/ExperimentReportTest.py"
                        --runner "$<TARGET_FILE:dk_run>" --client "$<TARGET_FILE:dk_ctl>"
                        --work-dir "${PROJECT_BINARY_DIR}/test-artifacts/$<CONFIG>/experiment-report"
                        ${_dk_batch_extra})
                set_tests_properties(dk.experiments.report_${kind} PROPERTIES TIMEOUT 540)
            endforeach()
            if(TARGET dk_render_simulation)
                set_tests_properties(dk.experiments.index_gpu PROPERTIES LABELS "gpu" RUN_SERIAL TRUE
                    SKIP_RETURN_CODE 77 ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1")
                set_tests_properties(dk.experiments.batch_gpu PROPERTIES LABELS "gpu" RUN_SERIAL TRUE
                    ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1")
                set_tests_properties(dk.experiments.recovery_gpu PROPERTIES LABELS "gpu" RUN_SERIAL TRUE
                    ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1")
                set_tests_properties(dk.experiments.report_gpu PROPERTIES LABELS "gpu" RUN_SERIAL TRUE
                    ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1")
            endif()
            foreach(kind IN ITEMS cpu capture_gpu)
                if(kind STREQUAL "capture_gpu" AND NOT TARGET dk_render_services)
                    continue()
                endif()
                set(_dk_python_extra)
                if(kind STREQUAL "capture_gpu")
                    set(_dk_python_extra --gpu)
                endif()
                add_test(NAME dk.python.${kind}
                    COMMAND "${CMAKE_COMMAND}" -E env "PYTHONPATH=${PROJECT_SOURCE_DIR}/sdk/python"
                        "PYTHONDONTWRITEBYTECODE=1" "${Python3_EXECUTABLE}"
                        "${CMAKE_CURRENT_SOURCE_DIR}/PythonClientTest.py"
                        --runner "$<TARGET_FILE:dk_run>" --client "$<TARGET_FILE:dk_ctl>"
                        --fixtures "${PROJECT_SOURCE_DIR}/tests/fixtures/render-disk"
                        --work-dir "${PROJECT_BINARY_DIR}/test-artifacts/$<CONFIG>/python"
                        ${_dk_python_extra})
                set_tests_properties(dk.python.${kind} PROPERTIES TIMEOUT 150)
            endforeach()
            if(TARGET dk_render_services)
                set_tests_properties(dk.python.capture_gpu PROPERTIES LABELS "gpu" RUN_SERIAL TRUE)
            endif()
            foreach(kind IN ITEMS cpu gpu)
                if(kind STREQUAL "gpu" AND NOT TARGET dk_render_services)
                    continue()
                endif()
                set(_dk_replay_extra)
                if(kind STREQUAL "gpu")
                    set(_dk_replay_extra --gpu)
                elseif(TARGET dk_scripting_luau)
                    set(_dk_replay_extra --script-runner "$<TARGET_FILE:dk_run>"
                        --script "${PROJECT_SOURCE_DIR}/examples/scripting/create-scene.luau")
                endif()
                add_test(NAME dk.replay.${kind}
                    COMMAND "${CMAKE_COMMAND}" -E env "PYTHONPATH=${PROJECT_SOURCE_DIR}/sdk/python"
                        "PYTHONDONTWRITEBYTECODE=1" "${Python3_EXECUTABLE}"
                        "${PROJECT_SOURCE_DIR}/tests/replay/ReplayTest.py"
                        --runner "$<TARGET_FILE:dk_run>" --client "$<TARGET_FILE:dk_ctl>"
                        --fixtures "${PROJECT_SOURCE_DIR}/tests/fixtures/render-disk"
                        --work-dir "${PROJECT_BINARY_DIR}/test-artifacts/$<CONFIG>/replay" ${_dk_replay_extra})
                set_tests_properties(dk.replay.${kind} PROPERTIES TIMEOUT 180)
            endforeach()
            if(TARGET dk_render_services)
                set_tests_properties(dk.replay.gpu PROPERTIES LABELS "gpu" RUN_SERIAL TRUE)
            endif()
        else()
            message(STATUS "Python 3.11+ not found: dk.python tests are not registered")
        endif()
        add_test(NAME dk.ipc.runner_client
            COMMAND "${DK_POWERSHELL}" -NoProfile -ExecutionPolicy Bypass
                -File "${CMAKE_CURRENT_SOURCE_DIR}/IpcClientTest.ps1"
                -Runner "$<TARGET_FILE:dk_run>" -Client "$<TARGET_FILE:dk_ctl>"
                -WorkDir "${CMAKE_CURRENT_BINARY_DIR}/test-artifacts/$<CONFIG>/ipc")
        set_tests_properties(dk.ipc.runner_client PROPERTIES TIMEOUT 90)
        if(TARGET dk_editor_app)
            add_test(NAME dk.ipc.editor_gpu_validation
                COMMAND "${DK_POWERSHELL}" -NoProfile -ExecutionPolicy Bypass
                    -File "${CMAKE_CURRENT_SOURCE_DIR}/IpcClientTest.ps1"
                    -Runner "$<TARGET_FILE:dk_run>" -Client "$<TARGET_FILE:dk_ctl>" -Editor "$<TARGET_FILE:dk_editor_app>"
                    -Fixtures "${PROJECT_SOURCE_DIR}/tests/fixtures/render-disk"
                    -WorkDir "${CMAKE_CURRENT_BINARY_DIR}/test-artifacts/$<CONFIG>/ipc-editor")
            set_tests_properties(dk.ipc.editor_gpu_validation PROPERTIES TIMEOUT 150 LABELS "gpu" RUN_SERIAL TRUE)
        endif()
    endif()
    if(TARGET dk_asset_operations)
        add_test(NAME dk.runtime.assets_stdio
            COMMAND "${DK_POWERSHELL}" -NoProfile -ExecutionPolicy Bypass
                -File "${CMAKE_CURRENT_SOURCE_DIR}/RuntimeAssetsTest.ps1"
                -Runner "$<TARGET_FILE:dk_run>" -Fixtures "${PROJECT_SOURCE_DIR}/tests/fixtures/assets"
                -WorkDir "${PROJECT_BINARY_DIR}/test-artifacts/$<CONFIG>")
        set_tests_properties(dk.runtime.assets_stdio PROPERTIES TIMEOUT 90)
    endif()
    add_test(NAME dk.runtime.stdio_interactive
        COMMAND "${DK_POWERSHELL}" -NoProfile -ExecutionPolicy Bypass
            -File "${CMAKE_CURRENT_SOURCE_DIR}/RuntimeStdioTest.ps1"
            -Runner "$<TARGET_FILE:dk_run>"
            -WorkDir "${CMAKE_CURRENT_BINARY_DIR}/test-artifacts/$<CONFIG>/runtime/stdio")
    set_tests_properties(dk.runtime.stdio_interactive PROPERTIES TIMEOUT 60)
    foreach(case IN ITEMS roundtrip errors)
        add_test(NAME dk.runtime.batch_${case}
            COMMAND "${CMAKE_COMMAND}"
                "-DRUNNER=$<TARGET_FILE:dk_run>"
                "-DWORK_DIR=${CMAKE_CURRENT_BINARY_DIR}/test-artifacts/$<CONFIG>/runtime/${case}"
                "-DCASE=${case}"
                -P "${CMAKE_CURRENT_SOURCE_DIR}/RuntimeBatchTest.cmake")
    endforeach()
endif()

if(TARGET dk_ctl)
    add_test(NAME dk.ipc.client_help COMMAND dk_ctl --help)
    set_tests_properties(dk.ipc.client_help PROPERTIES PASS_REGULAR_EXPRESSION "No automatic retry" TIMEOUT 10)
endif()

if(TARGET dk_foundation_demo AND WIN32)
    foreach(case IN ITEMS roundtrip overwrite invalid_id nil_id bad_version truncated
            nonfinite projective singular trailing oversized missing_file outside_root missing_parent usage)
        add_test(NAME dk.foundation.${case}
            COMMAND "${CMAKE_COMMAND}"
                "-DDEMO=$<TARGET_FILE:dk_foundation_demo>"
                "-DWORK_DIR=${CMAKE_CURRENT_BINARY_DIR}/test-artifacts/$<CONFIG>/foundation/${case}"
                "-DCASE=${case}"
                -P "${CMAKE_CURRENT_SOURCE_DIR}/FoundationDemoTest.cmake")
    endforeach()
endif()

if(TARGET dk_scene_demo AND WIN32)
    add_test(NAME dk.scene_demo.roundtrip
        COMMAND "${CMAKE_COMMAND}"
            "-DDEMO=$<TARGET_FILE:dk_scene_demo>"
            "-DWORK_DIR=${CMAKE_CURRENT_BINARY_DIR}/test-artifacts/$<CONFIG>/scene"
            -P "${CMAKE_CURRENT_SOURCE_DIR}/SceneDemoTest.cmake")
endif()

if(TARGET dk_render_services AND TARGET dk_run AND WIN32)
    add_test(NAME dk.runtime.capture_gpu_validation
        COMMAND "${DK_POWERSHELL}" -NoProfile -ExecutionPolicy Bypass
            -File "${CMAKE_CURRENT_SOURCE_DIR}/RuntimeCaptureTest.ps1"
            -Runner "$<TARGET_FILE:dk_run>" -Fixtures "${PROJECT_SOURCE_DIR}/tests/fixtures/render-disk"
            -WorkDir "${PROJECT_BINARY_DIR}/test-artifacts/$<CONFIG>")
    set_tests_properties(dk.runtime.capture_gpu_validation PROPERTIES TIMEOUT 180 SKIP_RETURN_CODE 77 LABELS "gpu")
endif()

if(TARGET dk_editor_app AND WIN32)
    find_program(DK_POWERSHELL NAMES pwsh powershell REQUIRED)
    if(TARGET dk_ctl AND TARGET dk_render_simulation)
        find_package(Python3 3.11 QUIET COMPONENTS Interpreter)
        if(Python3_Interpreter_FOUND)
            add_test(NAME dk.editor.simulation_consistency_gpu_validation
                COMMAND "${CMAKE_COMMAND}" -E env "PYTHONPATH=${PROJECT_SOURCE_DIR}/sdk/python" "PYTHONDONTWRITEBYTECODE=1"
                    "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/EditorSimulationConsistencyTest.py"
                    --editor "$<TARGET_FILE:dk_editor_app>" --client "$<TARGET_FILE:dk_ctl>"
                    --fixtures "${PROJECT_SOURCE_DIR}/tests/fixtures/render-disk"
                    --example "${PROJECT_SOURCE_DIR}/examples/automation/cloth_experiment.py"
                    --work-dir "${PROJECT_BINARY_DIR}/test-artifacts/$<CONFIG>")
            set_tests_properties(dk.editor.simulation_consistency_gpu_validation PROPERTIES TIMEOUT 240 SKIP_RETURN_CODE 77 LABELS "gpu" RUN_SERIAL TRUE
                ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1;VK_VALIDATION_VALIDATE_SYNC=1")
        endif()
    endif()
    add_test(NAME dk.editor.simulation_gpu_validation
        COMMAND "${DK_POWERSHELL}" -NoProfile -ExecutionPolicy Bypass
            -File "${CMAKE_CURRENT_SOURCE_DIR}/EditorSimulationTest.ps1"
            -Editor "$<TARGET_FILE:dk_editor_app>" -Fixtures "${PROJECT_SOURCE_DIR}/tests/fixtures/render-disk"
            -WorkDir "${PROJECT_BINARY_DIR}/test-artifacts/$<CONFIG>")
    set_tests_properties(dk.editor.simulation_gpu_validation PROPERTIES TIMEOUT 150 SKIP_RETURN_CODE 77 LABELS "gpu" RUN_SERIAL TRUE
        ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1;VK_VALIDATION_VALIDATE_SYNC=1")
    add_test(NAME dk.editor.workbench_gpu_validation
        COMMAND "${DK_POWERSHELL}" -NoProfile -ExecutionPolicy Bypass
            -File "${CMAKE_CURRENT_SOURCE_DIR}/EditorSmokeTest.ps1"
            -Editor "$<TARGET_FILE:dk_editor_app>" -Fixtures "${PROJECT_SOURCE_DIR}/tests/fixtures/render-disk"
            -WorkDir "${PROJECT_BINARY_DIR}/test-artifacts/$<CONFIG>")
    set_tests_properties(dk.editor.workbench_gpu_validation PROPERTIES TIMEOUT 150 SKIP_RETURN_CODE 77 LABELS "gpu")
    add_test(NAME dk.editor.settings_help_gpu_validation
        COMMAND "${DK_POWERSHELL}" -NoProfile -ExecutionPolicy Bypass
            -File "${CMAKE_CURRENT_SOURCE_DIR}/EditorSettingsHelpTest.ps1"
            -Editor "$<TARGET_FILE:dk_editor_app>" -Fixtures "${PROJECT_SOURCE_DIR}/tests/fixtures/render-disk"
            -WorkDir "${PROJECT_BINARY_DIR}/test-artifacts/$<CONFIG>")
    set_tests_properties(dk.editor.settings_help_gpu_validation PROPERTIES TIMEOUT 150 LABELS "gpu" RUN_SERIAL TRUE
        ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1;VK_VALIDATION_VALIDATE_SYNC=1")
    if(TARGET dk_run)
        add_test(NAME dk.editor.interaction_gpu_validation
            COMMAND "${DK_POWERSHELL}" -NoProfile -ExecutionPolicy Bypass
                -File "${CMAKE_CURRENT_SOURCE_DIR}/EditorInteractionTest.ps1"
                -Editor "$<TARGET_FILE:dk_editor_app>" -Runner "$<TARGET_FILE:dk_run>"
                -Fixtures "${PROJECT_SOURCE_DIR}/tests/fixtures/render-disk"
                -WorkDir "${PROJECT_BINARY_DIR}/test-artifacts/$<CONFIG>")
        set_tests_properties(dk.editor.interaction_gpu_validation PROPERTIES TIMEOUT 180 SKIP_RETURN_CODE 77 LABELS "gpu" RUN_SERIAL TRUE)
        if(TARGET dk_ctl AND TARGET dk_render_services)
            add_test(NAME dk.editor.consistency_gpu_validation
                COMMAND "${DK_POWERSHELL}" -NoProfile -ExecutionPolicy Bypass
                    -File "${CMAKE_CURRENT_SOURCE_DIR}/EditorConsistencyTest.ps1"
                    -Editor "$<TARGET_FILE:dk_editor_app>" -Runner "$<TARGET_FILE:dk_run>" -Client "$<TARGET_FILE:dk_ctl>"
                    -Fixtures "${PROJECT_SOURCE_DIR}/tests/fixtures/render-disk"
                    -WorkDir "${PROJECT_BINARY_DIR}/test-artifacts/$<CONFIG>")
            set_tests_properties(dk.editor.consistency_gpu_validation PROPERTIES TIMEOUT 240 LABELS "gpu" RUN_SERIAL TRUE)
        endif()
    endif()
endif()

if(TARGET dk_atmosphere_demo)
    add_test(NAME dk.atmosphere.demo_gpu_validation COMMAND dk_atmosphere_demo "${PROJECT_BINARY_DIR}/test-artifacts/$<CONFIG>/atmosphere")
    set_tests_properties(dk.atmosphere.demo_gpu_validation PROPERTIES TIMEOUT 120 RUN_SERIAL TRUE LABELS "gpu"
        ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1;VK_VALIDATION_VALIDATE_SYNC=1")
endif()
if(TARGET dk_sunlight_demo)
    add_test(NAME dk.render.sunlight_demo_gpu_validation COMMAND dk_sunlight_demo "${PROJECT_BINARY_DIR}/test-artifacts/$<CONFIG>/sunlight")
    set_tests_properties(dk.render.sunlight_demo_gpu_validation PROPERTIES TIMEOUT 120 RUN_SERIAL TRUE LABELS "gpu"
        ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1;VK_VALIDATION_VALIDATE_SYNC=1")
endif()

if(TARGET dk_editor_app AND TARGET dk_render_atmosphere AND TARGET dk_scripting_luau AND TARGET dk_ctl AND TARGET dk_run AND WIN32)
    find_package(Python3 3.11 QUIET COMPONENTS Interpreter)
    if(Python3_Interpreter_FOUND)
        add_test(NAME dk.editor.environment_consistency_gpu_validation
            COMMAND "${CMAKE_COMMAND}" -E env "PYTHONPATH=${PROJECT_SOURCE_DIR}/sdk/python" "PYTHONDONTWRITEBYTECODE=1"
                "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/EditorEnvironmentTest.py"
                --editor "$<TARGET_FILE:dk_editor_app>" --client "$<TARGET_FILE:dk_ctl>" --runner "$<TARGET_FILE:dk_run>"
                --fixtures "${PROJECT_SOURCE_DIR}/tests/fixtures/render-disk"
                --python-example "${PROJECT_SOURCE_DIR}/examples/automation/environment_capture.py"
                --luau-example "${PROJECT_SOURCE_DIR}/examples/scripting/environment-capture.luau"
                --work-dir "${PROJECT_BINARY_DIR}/test-artifacts/$<CONFIG>")
        set_tests_properties(dk.editor.environment_consistency_gpu_validation PROPERTIES TIMEOUT 420 RUN_SERIAL TRUE LABELS "gpu"
            ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1;VK_VALIDATION_VALIDATE_SYNC=1")
    endif()
endif()

if(TARGET dk_render_voxels AND TARGET dk_asset_voxel_importers)
    if(WIN32 AND TARGET dk_render_pipeline)
        find_package(nlohmann_json CONFIG REQUIRED)
        add_executable(dk_voxel_benchmark VoxelBenchmark.cpp)
        set_target_properties(dk_voxel_benchmark PROPERTIES OUTPUT_NAME dk-voxel-benchmark)
        target_link_libraries(dk_voxel_benchmark PRIVATE dk::render_pipeline dk::render_voxels dk::asset_voxel_importers dk::profiling OpenVDB::openvdb nlohmann_json::nlohmann_json Psapi)
        target_include_directories(dk_voxel_benchmark PRIVATE "${PROJECT_SOURCE_DIR}/engine/graphics/device/src" "${PROJECT_SOURCE_DIR}/engine/assets/importers/voxels/src")
        target_compile_definitions(dk_voxel_benchmark PRIVATE DK_RENDER_SHADER_DIR="${PROJECT_SOURCE_DIR}/shaders/render"
            DK_VOXEL_SHADER_DIR="${PROJECT_SOURCE_DIR}/engine/render/voxels/shaders"
            DK_BENCH_CONFIG="$<CONFIG>" DK_BENCH_COMPILER="${CMAKE_CXX_COMPILER_ID}-${CMAKE_CXX_COMPILER_VERSION}")
        dk_target_defaults(dk_voxel_benchmark)
        dk_deploy_slang(dk_voxel_benchmark)
        add_test(NAME dk.voxels.benchmark_gpu_required COMMAND dk_voxel_benchmark --smoke --validation
            --output "${PROJECT_BINARY_DIR}/test-artifacts/$<CONFIG>/voxel-benchmark/smoke.json")
        set_tests_properties(dk.voxels.benchmark_gpu_required PROPERTIES TIMEOUT 600 RUN_SERIAL TRUE LABELS "gpu"
            ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1;VK_VALIDATION_VALIDATE_SYNC=1;DISABLE_LAYER_AMD_SWITCHABLE_GRAPHICS_1=1")
        find_package(Python3 3.11 COMPONENTS Interpreter REQUIRED)
        add_test(NAME dk.voxels.benchmark_aggregation COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/VoxelBenchmarkTest.py")
        set_tests_properties(dk.voxels.benchmark_aggregation PROPERTIES TIMEOUT 30 LABELS "cpu")
        if(TARGET dk_render_pathtracing)
            add_executable(dk_voxel_joint_benchmark VoxelJointBenchmark.cpp)
            set_target_properties(dk_voxel_joint_benchmark PROPERTIES OUTPUT_NAME dk-voxel-joint-benchmark)
            target_link_libraries(dk_voxel_joint_benchmark PRIVATE dk::render_pathtracing dk::render_pipeline dk::render_voxels dk::asset_voxel_importers dk::profiling dk::rtxdi_shaders OpenVDB::openvdb nlohmann_json::nlohmann_json Psapi)
            target_include_directories(dk_voxel_joint_benchmark PRIVATE "${PROJECT_SOURCE_DIR}/engine/graphics/device/src" "${PROJECT_SOURCE_DIR}/engine/assets/importers/voxels/src")
            target_compile_definitions(dk_voxel_joint_benchmark PRIVATE DK_RENDER_SHADER_DIR="${PROJECT_SOURCE_DIR}/shaders/render"
                DK_VOXEL_SHADER_DIR="${PROJECT_SOURCE_DIR}/engine/render/voxels/shaders" DK_PATH_SHADER_DIR="${PROJECT_SOURCE_DIR}/engine/render/pathtracing/shaders"
                DK_JOINT_NANO_INCLUDE_DIR="${DK_NANOVDB_INCLUDE_DIR}" DK_BENCH_CONFIG="$<CONFIG>" DK_BENCH_COMPILER="${CMAKE_CXX_COMPILER_ID}-${CMAKE_CXX_COMPILER_VERSION}")
            dk_target_defaults(dk_voxel_joint_benchmark)
            dk_deploy_slang(dk_voxel_joint_benchmark)
            add_test(NAME dk.voxels.joint_gpu_required COMMAND dk_voxel_joint_benchmark --smoke --validation
                --output "${PROJECT_BINARY_DIR}/test-artifacts/$<CONFIG>/voxel-joint/smoke.json")
            set_tests_properties(dk.voxels.joint_gpu_required PROPERTIES TIMEOUT 1800 RUN_SERIAL TRUE LABELS "gpu"
                ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1;VK_VALIDATION_VALIDATE_SYNC=1;DISABLE_LAYER_AMD_SWITCHABLE_GRAPHICS_1=1")
            add_test(NAME dk.voxels.joint_aggregation COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/VoxelJointBenchmarkTest.py")
            set_tests_properties(dk.voxels.joint_aggregation PROPERTIES TIMEOUT 30 LABELS "cpu")
        endif()
    endif()
    if(TARGET dk_render_pipeline)
        add_executable(dk_voxel_raster_probe VoxelRasterProbe.cpp)
        target_link_libraries(dk_voxel_raster_probe PRIVATE dk::render_pipeline dk::render_voxels dk::asset_voxel_importers)
        target_include_directories(dk_voxel_raster_probe PRIVATE "${PROJECT_SOURCE_DIR}/engine/graphics/device/src")
        target_compile_definitions(dk_voxel_raster_probe PRIVATE DK_RENDER_SHADER_DIR="${PROJECT_SOURCE_DIR}/shaders/render"
            DK_VOXEL_ARTIFACT_DIR="${CMAKE_CURRENT_BINARY_DIR}/voxel-artifacts")
        dk_target_defaults(dk_voxel_raster_probe)
        dk_deploy_slang(dk_voxel_raster_probe)
        foreach(mode composition lifetime)
            add_test(NAME dk.voxels.raster_${mode}_required COMMAND dk_voxel_raster_probe ${mode})
            set_tests_properties(dk.voxels.raster_${mode}_required PROPERTIES TIMEOUT 300 RUN_SERIAL TRUE LABELS "gpu"
                ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1;VK_VALIDATION_VALIDATE_SYNC=1")
        endforeach()
    endif()
    add_executable(dk_voxel_gpu_probe VoxelGpuProbe.cpp)
    add_executable(dk_voxel_intersection_probe VoxelIntersectionProbe.cpp)
    target_link_libraries(dk_voxel_intersection_probe PRIVATE dk::graphics_graph dk::graphics_shaders dk::asset_voxel_importers)
    target_include_directories(dk_voxel_intersection_probe PRIVATE "${PROJECT_SOURCE_DIR}/engine/graphics/device/src")
    target_compile_definitions(dk_voxel_intersection_probe PRIVATE
        DK_RT_SHADER="${PROJECT_SOURCE_DIR}/tests/fixtures/shaders/procedural.slang"
        DK_VOXEL_SHADER_DIR="${PROJECT_SOURCE_DIR}/engine/render/voxels/shaders"
        DK_VOXEL_NANO_INCLUDE_DIR="${DK_NANOVDB_INCLUDE_DIR}"
        DK_VOXEL_ARTIFACT_DIR="${CMAKE_CURRENT_BINARY_DIR}/voxel-artifacts")
    dk_target_defaults(dk_voxel_intersection_probe)
    dk_deploy_slang(dk_voxel_intersection_probe)
    add_test(NAME dk.voxels.slang_intersection COMMAND dk_voxel_intersection_probe compile)
    set_tests_properties(dk.voxels.slang_intersection PROPERTIES TIMEOUT 120 LABELS "cpu" FIXTURES_SETUP voxel_intersection_spirv)
    add_test(NAME dk.voxels.intersection_gpu_required COMMAND dk_voxel_intersection_probe)
    set_tests_properties(dk.voxels.intersection_gpu_required PROPERTIES TIMEOUT 300 RUN_SERIAL TRUE LABELS "gpu"
        ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1;VK_VALIDATION_VALIDATE_SYNC=1")
    target_link_libraries(dk_voxel_gpu_probe PRIVATE dk::render_voxels dk::asset_voxel_importers dk::graphics_shaders)
    target_include_directories(dk_voxel_gpu_probe PRIVATE "${PROJECT_SOURCE_DIR}/engine/graphics/device/src" "${PROJECT_SOURCE_DIR}/tests/unit")
    target_compile_definitions(dk_voxel_gpu_probe PRIVATE
        DK_VOXEL_SHADER_DIR="${PROJECT_SOURCE_DIR}/engine/render/voxels/shaders"
        DK_VOXEL_NANO_INCLUDE_DIR="${DK_NANOVDB_INCLUDE_DIR}"
        DK_VOXEL_FIXTURE_DIR="${PROJECT_SOURCE_DIR}/tests/fixtures/shaders"
        DK_VOXEL_ARTIFACT_DIR="${CMAKE_CURRENT_BINARY_DIR}/voxel-artifacts")
    dk_target_defaults(dk_voxel_gpu_probe)
    dk_deploy_slang(dk_voxel_gpu_probe)
    add_test(NAME dk.voxels.slang_compute COMMAND dk_voxel_gpu_probe compile)
    set_tests_properties(dk.voxels.slang_compute PROPERTIES TIMEOUT 120 LABELS "cpu" FIXTURES_SETUP voxel_spirv)
    find_program(DK_VOXEL_SPIRV_VALIDATOR NAMES spirv-val REQUIRED)
    add_test(NAME dk.voxels.intersection_spirv_validation COMMAND "${DK_VOXEL_SPIRV_VALIDATOR}" --target-env vulkan1.3 "${CMAKE_CURRENT_BINARY_DIR}/voxel-artifacts/voxel-intersection.spv")
    set_tests_properties(dk.voxels.intersection_spirv_validation PROPERTIES TIMEOUT 60 LABELS "cpu" FIXTURES_REQUIRED voxel_intersection_spirv)
    add_test(NAME dk.voxels.spirv_validation COMMAND "${DK_VOXEL_SPIRV_VALIDATOR}" --target-env vulkan1.3 "${CMAKE_CURRENT_BINARY_DIR}/voxel-artifacts/voxel-query.spv")
    set_tests_properties(dk.voxels.spirv_validation PROPERTIES TIMEOUT 60 LABELS "cpu" FIXTURES_REQUIRED voxel_spirv)
    foreach(mode numeric offscreen lifetime)
        add_test(NAME dk.voxels.gpu_${mode}_required COMMAND dk_voxel_gpu_probe ${mode})
        set_tests_properties(dk.voxels.gpu_${mode}_required PROPERTIES TIMEOUT 300 RUN_SERIAL TRUE LABELS "gpu"
            ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1;VK_VALIDATION_VALIDATE_SYNC=1")
    endforeach()
endif()

if(TARGET dk_render_clouds AND TARGET dk_graphics_shaders)
    add_executable(dk_cloud_field_probe CloudFieldProbe.cpp)
    target_link_libraries(dk_cloud_field_probe PRIVATE dk::render_clouds dk::graphics_shaders)
    target_include_directories(dk_cloud_field_probe PRIVATE "${PROJECT_SOURCE_DIR}/engine/graphics/device/src")
    target_compile_definitions(dk_cloud_field_probe PRIVATE DK_CLOUD_SHADER_DIR="${PROJECT_SOURCE_DIR}/tests/fixtures/shaders")
    dk_target_defaults(dk_cloud_field_probe)
    dk_deploy_slang(dk_cloud_field_probe)
    add_test(NAME dk.clouds.fields_gpu_validation COMMAND dk_cloud_field_probe)
    set_tests_properties(dk.clouds.fields_gpu_validation PROPERTIES TIMEOUT 240 RUN_SERIAL TRUE LABELS "gpu"
        ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1;VK_VALIDATION_VALIDATE_SYNC=1")
endif()
if(TARGET dk_render_clouds)
    add_executable(dk_cloud_reference_probe CloudReferenceProbe.cpp)
    target_link_libraries(dk_cloud_reference_probe PRIVATE dk::render_clouds)
    target_include_directories(dk_cloud_reference_probe PRIVATE "${PROJECT_SOURCE_DIR}/engine/graphics/device/src")
    target_compile_definitions(dk_cloud_reference_probe PRIVATE DK_CLOUD_REFERENCE_SHADER_DIR="${PROJECT_SOURCE_DIR}/engine/render/clouds/shaders")
    dk_target_defaults(dk_cloud_reference_probe)
    dk_deploy_slang(dk_cloud_reference_probe)
    add_test(NAME dk.clouds.reference_gpu_validation COMMAND dk_cloud_reference_probe)
    set_tests_properties(dk.clouds.reference_gpu_validation PROPERTIES TIMEOUT 240 RUN_SERIAL TRUE LABELS "gpu"
        ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1;VK_VALIDATION_VALIDATE_SYNC=1")
endif()
if(TARGET dk_render_clouds AND TARGET dk_render_pipeline AND TARGET dk_render_atmosphere)
    add_executable(dk_cloud_benchmark CloudBenchmark.cpp)
    set_target_properties(dk_cloud_benchmark PROPERTIES OUTPUT_NAME dk-cloud-benchmark)
    target_link_libraries(dk_cloud_benchmark PRIVATE dk::render_pipeline dk::render_clouds dk::render_atmosphere dk::profiling nlohmann_json::nlohmann_json)
    target_compile_definitions(dk_cloud_benchmark PRIVATE DK_RENDER_SHADER_DIR="${PROJECT_SOURCE_DIR}/shaders/render"
        DK_ATMOSPHERE_SHADER_DIR="${PROJECT_SOURCE_DIR}/engine/render/atmosphere/shaders"
        DK_CLOUD_SHADER_DIR="${PROJECT_SOURCE_DIR}/engine/render/clouds/shaders"
        DK_BENCH_COMPILER="${CMAKE_CXX_COMPILER_ID}-${CMAKE_CXX_COMPILER_VERSION}" DK_BENCH_CONFIG="$<CONFIG>")
    dk_target_defaults(dk_cloud_benchmark)
    dk_deploy_slang(dk_cloud_benchmark)
    find_package(Python3 3.11 QUIET COMPONENTS Interpreter)
    if(Python3_Interpreter_FOUND)
        add_test(NAME dk.clouds.benchmark_aggregation COMMAND "${CMAKE_COMMAND}" -E env "PYTHONDONTWRITEBYTECODE=1"
            "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/CloudBenchmarkTest.py")
        set_tests_properties(dk.clouds.benchmark_aggregation PROPERTIES TIMEOUT 30)
    endif()
    add_test(NAME dk.clouds.benchmark_gpu_validation COMMAND dk_cloud_benchmark --smoke --validation --timestamps
        --output "${PROJECT_BINARY_DIR}/test-artifacts/$<CONFIG>/cloud-benchmark.json")
    set_tests_properties(dk.clouds.benchmark_gpu_validation PROPERTIES TIMEOUT 480 RUN_SERIAL TRUE LABELS "gpu"
        ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1;VK_VALIDATION_VALIDATE_SYNC=1")
    foreach(preset IN ITEMS clear sparse overcast sunset)
        add_test(NAME dk.clouds.quality_${preset}_gpu_validation COMMAND dk_cloud_benchmark --quality --validation --preset ${preset}
            --output "${PROJECT_BINARY_DIR}/test-artifacts/$<CONFIG>/cloud-quality-${preset}.json")
        set_tests_properties(dk.clouds.quality_${preset}_gpu_validation PROPERTIES TIMEOUT 1200 RUN_SERIAL TRUE LABELS "gpu"
            ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1;VK_VALIDATION_VALIDATE_SYNC=1")
    endforeach()
    foreach(divisor IN ITEMS 2 4)
        add_test(NAME dk.clouds.quality_sunset_detail_${divisor}_gpu_validation COMMAND dk_cloud_benchmark --sunset-quality --validation
            --preset sunset --resolution-divisor ${divisor} --output "${PROJECT_BINARY_DIR}/test-artifacts/$<CONFIG>/cloud-quality-sunset-detail-${divisor}.json")
        set_tests_properties(dk.clouds.quality_sunset_detail_${divisor}_gpu_validation PROPERTIES TIMEOUT 1200 RUN_SERIAL TRUE LABELS "gpu"
            ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1;VK_VALIDATION_VALIDATE_SYNC=1")
    endforeach()
    add_executable(dk_cloud_composition_probe CloudCompositionProbe.cpp)
    target_link_libraries(dk_cloud_composition_probe PRIVATE dk::render_pipeline dk::render_clouds dk::render_atmosphere)
    target_include_directories(dk_cloud_composition_probe PRIVATE "${PROJECT_SOURCE_DIR}/engine/graphics/device/src")
    target_compile_definitions(dk_cloud_composition_probe PRIVATE DK_RENDER_SHADER_DIR="${PROJECT_SOURCE_DIR}/shaders/render"
        DK_ATMOSPHERE_SHADER_DIR="${PROJECT_SOURCE_DIR}/engine/render/atmosphere/shaders")
    dk_target_defaults(dk_cloud_composition_probe)
    dk_deploy_slang(dk_cloud_composition_probe)
    foreach(case IN ITEMS numeric composition failures orthographic orthographic_shadow resolution sunset_optimization optimization optimization_switches optimization_boundaries temporal history shadow_numeric shadow_surface shadow_failures)
        add_test(NAME dk.clouds.${case}_gpu_composition COMMAND dk_cloud_composition_probe ${case})
        set_tests_properties(dk.clouds.${case}_gpu_composition PROPERTIES TIMEOUT 240 RUN_SERIAL TRUE LABELS "gpu"
            ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1;VK_VALIDATION_VALIDATE_SYNC=1")
    endforeach()
endif()
if(TARGET dk_render_clouds AND TARGET dk_render_services AND TARGET dk_run AND WIN32)
    find_package(Python3 3.11 QUIET COMPONENTS Interpreter)
    if(Python3_Interpreter_FOUND)
        add_test(NAME dk.clouds.capture_gpu_composition
            COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/CloudCaptureTest.py"
                --runner "$<TARGET_FILE:dk_run>" --fixtures "${PROJECT_SOURCE_DIR}/tests/fixtures/render-disk"
                --work-dir "${PROJECT_BINARY_DIR}/test-artifacts/$<CONFIG>")
        set_tests_properties(dk.clouds.capture_gpu_composition PROPERTIES TIMEOUT 240 RUN_SERIAL TRUE LABELS "gpu"
            ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1;VK_VALIDATION_VALIDATE_SYNC=1")
    endif()
endif()

if(TARGET dk_render_clouds AND TARGET dk_scripting_luau AND TARGET dk_run AND TARGET dk_ctl AND WIN32)
    find_package(Python3 3.11 QUIET COMPONENTS Interpreter)
    if(Python3_Interpreter_FOUND)
        add_test(NAME dk.clouds.cases_unit
            COMMAND "${CMAKE_COMMAND}" -E env "PYTHONPATH=${PROJECT_SOURCE_DIR}/sdk/python" "PYTHONDONTWRITEBYTECODE=1"
                "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/RenderCasesUnitTest.py")
        set_tests_properties(dk.clouds.cases_unit PROPERTIES LABELS "cpu" TIMEOUT 30)
        add_test(NAME dk.clouds.sequence_gpu_validation
            COMMAND "${CMAKE_COMMAND}" -E env "PYTHONPATH=${PROJECT_SOURCE_DIR}/sdk/python" "PYTHONDONTWRITEBYTECODE=1"
                "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/CloudSequenceTest.py"
                --runner "$<TARGET_FILE:dk_run>" --client "$<TARGET_FILE:dk_ctl>" --fixtures "${PROJECT_SOURCE_DIR}/tests/fixtures/render-disk"
                --python-example "${PROJECT_SOURCE_DIR}/examples/automation/cloud_sequence.py"
                --luau-example "${PROJECT_SOURCE_DIR}/examples/scripting/cloud-sequence.luau"
                --work-dir "${PROJECT_BINARY_DIR}/test-artifacts/$<CONFIG>")
        set_tests_properties(dk.clouds.sequence_gpu_validation PROPERTIES TIMEOUT 480 RUN_SERIAL TRUE LABELS "gpu"
            ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1;VK_VALIDATION_VALIDATE_SYNC=1")
        if(TARGET dk_editor_app)
            add_test(NAME dk.editor.cloud_consistency_gpu_validation
                COMMAND "${CMAKE_COMMAND}" -E env "PYTHONPATH=${PROJECT_SOURCE_DIR}/sdk/python" "PYTHONDONTWRITEBYTECODE=1"
                    "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/EditorEnvironmentTest.py" --clouds
                    --editor "$<TARGET_FILE:dk_editor_app>" --client "$<TARGET_FILE:dk_ctl>" --runner "$<TARGET_FILE:dk_run>"
                    --fixtures "${PROJECT_SOURCE_DIR}/tests/fixtures/render-disk"
                    --python-example "${PROJECT_SOURCE_DIR}/examples/automation/cloud_sequence.py"
                    --luau-example "${PROJECT_SOURCE_DIR}/examples/scripting/cloud-sequence.luau"
                    --work-dir "${PROJECT_BINARY_DIR}/test-artifacts/$<CONFIG>")
            set_tests_properties(dk.editor.cloud_consistency_gpu_validation PROPERTIES TIMEOUT 480 RUN_SERIAL TRUE LABELS "gpu"
                ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1;VK_VALIDATION_VALIDATE_SYNC=1")
        endif()
    endif()
endif()

if(TARGET dk_render_services AND TARGET dk_render_pathtracing AND TARGET dk_run AND TARGET dk_ctl AND WIN32)
    find_package(Python3 3.11 QUIET COMPONENTS Interpreter)
    if(Python3_Interpreter_FOUND)
        set(_dk_path_capture_script_args)
        if(NOT DK_BUILD_SCRIPTING_LUAU)
            list(APPEND _dk_path_capture_script_args --skip-luau)
        endif()
        add_test(NAME dk.pathtracing.capture_gpu_required
            COMMAND "${CMAKE_COMMAND}" -E env "PYTHONPATH=${PROJECT_SOURCE_DIR}/sdk/python" "PYTHONDONTWRITEBYTECODE=1"
                "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/PathCaptureTest.py"
                --runner "$<TARGET_FILE:dk_run>" --client "$<TARGET_FILE:dk_ctl>"
                --fixtures "${PROJECT_SOURCE_DIR}/tests/fixtures/render-disk"
                --python-example "${PROJECT_SOURCE_DIR}/examples/automation/pathtrace_capture.py"
                --luau-example "${PROJECT_SOURCE_DIR}/examples/scripting/pathtrace-capture.luau"
                --work-dir "${PROJECT_BINARY_DIR}/test-artifacts/$<CONFIG>" ${_dk_path_capture_script_args})
        add_test(NAME dk.pathtracing.media_capture_gpu_required
            COMMAND "${CMAKE_COMMAND}" -E env "PYTHONPATH=${PROJECT_SOURCE_DIR}/sdk/python" "PYTHONDONTWRITEBYTECODE=1"
                "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/PathCaptureTest.py" --media
                --runner "$<TARGET_FILE:dk_run>" --client "$<TARGET_FILE:dk_ctl>"
                --fixtures "${PROJECT_SOURCE_DIR}/tests/fixtures/render-disk"
                --python-example "${PROJECT_SOURCE_DIR}/examples/automation/pathtrace_capture.py"
                --luau-example "${PROJECT_SOURCE_DIR}/examples/scripting/pathtrace-media-capture.luau"
                --work-dir "${PROJECT_BINARY_DIR}/test-artifacts/$<CONFIG>" ${_dk_path_capture_script_args})
        add_test(NAME dk.pathtracing.restir_capture_gpu_required
            COMMAND "${CMAKE_COMMAND}" -E env "PYTHONPATH=${PROJECT_SOURCE_DIR}/sdk/python" "PYTHONDONTWRITEBYTECODE=1"
                "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/RestirCaptureTest.py"
                --runner "$<TARGET_FILE:dk_run>" --client "$<TARGET_FILE:dk_ctl>"
                --fixtures "${PROJECT_SOURCE_DIR}/tests/fixtures/render-disk"
                --python-example "${PROJECT_SOURCE_DIR}/examples/automation/pathtrace_capture.py"
                --luau-example "${PROJECT_SOURCE_DIR}/examples/scripting/pathtrace-restir-capture.luau"
                --work-dir "${PROJECT_BINARY_DIR}/test-artifacts/$<CONFIG>" ${_dk_path_capture_script_args})
        set_tests_properties(dk.pathtracing.restir_capture_gpu_required PROPERTIES TIMEOUT 600 RUN_SERIAL TRUE LABELS "gpu"
            ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1;VK_VALIDATION_VALIDATE_SYNC=1")
        set_tests_properties(dk.pathtracing.media_capture_gpu_required PROPERTIES TIMEOUT 480 RUN_SERIAL TRUE LABELS "gpu"
            ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1;VK_VALIDATION_VALIDATE_SYNC=1")
        set_tests_properties(dk.pathtracing.capture_gpu_required PROPERTIES TIMEOUT 480 RUN_SERIAL TRUE LABELS "gpu"
            ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1;VK_VALIDATION_VALIDATE_SYNC=1")
    endif()
endif()
if(TARGET dk_editor_app AND TARGET dk_render_pathtracing AND TARGET dk_ctl AND WIN32)
    if(TARGET dk_render_atmosphere AND TARGET dk_render_clouds)
        add_executable(dk_editor_render_benchmark EditorRenderBenchmark.cpp)
        set_target_properties(dk_editor_render_benchmark PROPERTIES OUTPUT_NAME dk-editor-render-benchmark)
        target_include_directories(dk_editor_render_benchmark PRIVATE "${PROJECT_SOURCE_DIR}/engine/editor/src")
        target_link_libraries(dk_editor_render_benchmark PRIVATE dk::editor dk::editor_model dk::render_pathtracing dk::render_pipeline)
        dk_target_defaults(dk_editor_render_benchmark)
        dk_deploy_slang(dk_editor_render_benchmark)
        add_test(NAME dk.editor.render_worker_gpu_validation COMMAND dk_editor_render_benchmark
            "${PROJECT_SOURCE_DIR}/projects/demo" "${PROJECT_BINARY_DIR}/test-artifacts/$<CONFIG>/render-worker" --validation)
        set_tests_properties(dk.editor.render_worker_gpu_validation PROPERTIES TIMEOUT 300 RUN_SERIAL TRUE LABELS "gpu"
            ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1;VK_VALIDATION_VALIDATE_SYNC=1")
        add_test(NAME dk.editor.media_worker_gpu_validation COMMAND dk_editor_render_benchmark
            "${PROJECT_SOURCE_DIR}/projects/demo" "${PROJECT_BINARY_DIR}/test-artifacts/$<CONFIG>/media-worker" --media --validation)
        add_test(NAME dk.editor.restir_worker_gpu_validation COMMAND dk_editor_render_benchmark
            "${PROJECT_SOURCE_DIR}/tests/fixtures/render-disk" "${PROJECT_BINARY_DIR}/test-artifacts/$<CONFIG>/restir-worker" --restir --validation)
        add_test(NAME dk.editor.restir_desktop_gpu_validation COMMAND dk_editor_render_benchmark
            "${PROJECT_SOURCE_DIR}/projects/demo" "${PROJECT_BINARY_DIR}/test-artifacts/$<CONFIG>/restir-desktop" --desktop-path --validation)
        add_test(NAME dk.editor.media_desktop_gpu_validation COMMAND dk_editor_render_benchmark
            "${PROJECT_SOURCE_DIR}/projects/demo" "${PROJECT_BINARY_DIR}/test-artifacts/$<CONFIG>/media-desktop" --desktop-media --validation)
        set_tests_properties(dk.editor.media_desktop_gpu_validation dk.editor.restir_desktop_gpu_validation PROPERTIES TIMEOUT 600 RUN_SERIAL TRUE LABELS "gpu"
            ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1;VK_VALIDATION_VALIDATE_SYNC=1")
        set_tests_properties(dk.editor.restir_worker_gpu_validation PROPERTIES TIMEOUT 300 RUN_SERIAL TRUE LABELS "gpu"
            ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1;VK_VALIDATION_VALIDATE_SYNC=1")
        set_tests_properties(dk.editor.media_worker_gpu_validation PROPERTIES TIMEOUT 300 RUN_SERIAL TRUE LABELS "gpu"
            ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1;VK_VALIDATION_VALIDATE_SYNC=1")
    endif()
    find_package(Python3 3.11 QUIET COMPONENTS Interpreter)
    if(Python3_Interpreter_FOUND)
        add_test(NAME dk.editor.pathtracing_gpu_validation
            COMMAND "${CMAKE_COMMAND}" -E env "PYTHONPATH=${PROJECT_SOURCE_DIR}/sdk/python" "PYTHONDONTWRITEBYTECODE=1"
                "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/EditorPathTraceTest.py"
                --editor "$<TARGET_FILE:dk_editor_app>" --client "$<TARGET_FILE:dk_ctl>"
                --fixtures "${PROJECT_SOURCE_DIR}/tests/fixtures/render-disk"
                --work-dir "${PROJECT_BINARY_DIR}/test-artifacts/$<CONFIG>")
        add_test(NAME dk.editor.media_pathtracing_gpu_validation
            COMMAND "${CMAKE_COMMAND}" -E env "PYTHONPATH=${PROJECT_SOURCE_DIR}/sdk/python" "PYTHONDONTWRITEBYTECODE=1"
                "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/EditorPathTraceTest.py" --media
                --editor "$<TARGET_FILE:dk_editor_app>" --client "$<TARGET_FILE:dk_ctl>"
                --fixtures "${PROJECT_SOURCE_DIR}/tests/fixtures/render-disk"
                --work-dir "${PROJECT_BINARY_DIR}/test-artifacts/$<CONFIG>")
        add_test(NAME dk.editor.viewport_commands_gpu_validation
            COMMAND "${CMAKE_COMMAND}" -E env "PYTHONPATH=${PROJECT_SOURCE_DIR}/sdk/python" "PYTHONDONTWRITEBYTECODE=1"
                "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/EditorViewportCommandTest.py"
                --editor "$<TARGET_FILE:dk_editor_app>" --client "$<TARGET_FILE:dk_ctl>" --runner "$<TARGET_FILE:dk_run>"
                --fixtures "${PROJECT_SOURCE_DIR}/tests/fixtures/render-disk"
                --work-dir "${PROJECT_BINARY_DIR}/test-artifacts/$<CONFIG>")
        set_tests_properties(dk.editor.viewport_commands_gpu_validation PROPERTIES TIMEOUT 300 RUN_SERIAL TRUE LABELS "gpu"
            ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1;VK_VALIDATION_VALIDATE_SYNC=1")
        add_test(NAME dk.editor.camera_commands_gpu_validation
            COMMAND "${CMAKE_COMMAND}" -E env "PYTHONPATH=${PROJECT_SOURCE_DIR}/sdk/python" "PYTHONDONTWRITEBYTECODE=1"
                "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/EditorCameraCommandTest.py"
                --editor "$<TARGET_FILE:dk_editor_app>" --client "$<TARGET_FILE:dk_ctl>" --runner "$<TARGET_FILE:dk_run>"
                --fixtures "${PROJECT_SOURCE_DIR}/tests/fixtures/render-disk"
                --work-dir "${PROJECT_BINARY_DIR}/test-artifacts/$<CONFIG>")
        set_tests_properties(dk.editor.camera_commands_gpu_validation PROPERTIES TIMEOUT 300 RUN_SERIAL TRUE LABELS "gpu"
            ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1;VK_VALIDATION_VALIDATE_SYNC=1")
        add_test(NAME dk.editor.console_workflow_gpu_validation
            COMMAND "${CMAKE_COMMAND}" -E env "PYTHONPATH=${PROJECT_SOURCE_DIR}/sdk/python" "PYTHONDONTWRITEBYTECODE=1"
                "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/EditorConsoleWorkflowTest.py"
                --editor "$<TARGET_FILE:dk_editor_app>" --client "$<TARGET_FILE:dk_ctl>" --runner "$<TARGET_FILE:dk_run>"
                --fixtures "${PROJECT_SOURCE_DIR}/tests/fixtures/render-disk"
                --example "${PROJECT_SOURCE_DIR}/examples/automation/editor_settings.py"
                --work-dir "${PROJECT_BINARY_DIR}/test-artifacts/$<CONFIG>")
        set_tests_properties(dk.editor.console_workflow_gpu_validation PROPERTIES TIMEOUT 300 RUN_SERIAL TRUE LABELS "gpu"
            ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1;VK_VALIDATION_VALIDATE_SYNC=1")
        add_test(NAME dk.editor.settings_example_unit
            COMMAND "${CMAKE_COMMAND}" -E env "PYTHONPATH=${PROJECT_SOURCE_DIR}/sdk/python" "PYTHONDONTWRITEBYTECODE=1"
                "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/EditorSettingsExampleTest.py")
        set_tests_properties(dk.editor.settings_example_unit PROPERTIES TIMEOUT 20 LABELS "cpu")
        add_test(NAME dk.editor.restir_pathtracing_gpu_validation
            COMMAND "${CMAKE_COMMAND}" -E env "PYTHONPATH=${PROJECT_SOURCE_DIR}/sdk/python" "PYTHONDONTWRITEBYTECODE=1"
                "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/EditorPathTraceTest.py" --restir
                --editor "$<TARGET_FILE:dk_editor_app>" --client "$<TARGET_FILE:dk_ctl>"
                --fixtures "${PROJECT_SOURCE_DIR}/tests/fixtures/render-disk"
                --work-dir "${PROJECT_BINARY_DIR}/test-artifacts/$<CONFIG>")
        set_tests_properties(dk.editor.restir_pathtracing_gpu_validation PROPERTIES TIMEOUT 480 RUN_SERIAL TRUE LABELS "gpu"
            ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1;VK_VALIDATION_VALIDATE_SYNC=1")
        set_tests_properties(dk.editor.media_pathtracing_gpu_validation PROPERTIES TIMEOUT 300 RUN_SERIAL TRUE LABELS "gpu"
            ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1;VK_VALIDATION_VALIDATE_SYNC=1")
        set_tests_properties(dk.editor.pathtracing_gpu_validation PROPERTIES TIMEOUT 300 RUN_SERIAL TRUE LABELS "gpu"
            ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1;VK_VALIDATION_VALIDATE_SYNC=1")
        if(TARGET dk_render_atmosphere AND TARGET dk_render_clouds)
            add_test(NAME dk.editor.media_motion_gpu_validation
                COMMAND "${Python3_EXECUTABLE}" "${PROJECT_SOURCE_DIR}/scripts/benchmark-media-preview.py"
                    --editor "$<TARGET_FILE:dk_editor_app>" --project "${PROJECT_SOURCE_DIR}/projects/demo"
                    --output "${PROJECT_BINARY_DIR}/test-artifacts/$<CONFIG>/media-motion-$<CONFIG>" --mode validate)
            set_tests_properties(dk.editor.media_motion_gpu_validation PROPERTIES TIMEOUT 300 RUN_SERIAL TRUE LABELS "gpu"
                ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1;VK_VALIDATION_VALIDATE_SYNC=1")
            add_test(NAME dk.editor.desktop_render_gpu_validation
                COMMAND "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/EditorDesktopRenderTest.py"
                    --editor "$<TARGET_FILE:dk_editor_app>" --project "${PROJECT_SOURCE_DIR}/projects/demo"
                    --client "$<TARGET_FILE:dk_ctl>"
                    --work-dir "${PROJECT_BINARY_DIR}/test-artifacts/$<CONFIG>")
            set_tests_properties(dk.editor.desktop_render_gpu_validation PROPERTIES TIMEOUT 300 RUN_SERIAL TRUE LABELS "gpu"
                ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1;VK_VALIDATION_VALIDATE_SYNC=1")
        endif()
    endif()
endif()

if(TARGET dk_editor_model AND TARGET dk_render_pathtracing AND TARGET dk_render_disk)
    add_executable(dk_pathmedia_benchmark PathMediaBenchmark.cpp)
    set_target_properties(dk_pathmedia_benchmark PROPERTIES OUTPUT_NAME dk-pathmedia-benchmark)
    target_include_directories(dk_pathmedia_benchmark PRIVATE "${PROJECT_SOURCE_DIR}/engine/editor/src")
    target_link_libraries(dk_pathmedia_benchmark PRIVATE dk::editor_model dk::render_pathtracing dk::render_disk dk::profiling nlohmann_json::nlohmann_json)
    target_compile_definitions(dk_pathmedia_benchmark PRIVATE DK_PATH_SHADER_DIR="${PROJECT_SOURCE_DIR}/engine/render/pathtracing/shaders"
        DK_PATH_DISK_DIR="${PROJECT_SOURCE_DIR}/tests/fixtures/render-disk" DK_BENCH_CONFIG="$<CONFIG>")
    dk_target_defaults(dk_pathmedia_benchmark)
    dk_deploy_slang(dk_pathmedia_benchmark)
    foreach(mode IN ITEMS initial temporal spatial)
        add_test(NAME dk.pathtracing.restir_sponza_${mode}_gpu_validation COMMAND dk_pathmedia_benchmark --smoke
            --algorithm ${mode} --case courtyard-sparse --full-preview --root "${PROJECT_SOURCE_DIR}/projects/demo"
            --output "${PROJECT_BINARY_DIR}/test-artifacts/$<CONFIG>/restir-sponza/${mode}-smoke.json")
        set_tests_properties(dk.pathtracing.restir_sponza_${mode}_gpu_validation PROPERTIES TIMEOUT 300 RUN_SERIAL TRUE LABELS "gpu"
            ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1;VK_VALIDATION_VALIDATE_SYNC=1")
    endforeach()
    add_test(NAME dk.pathtracing.restir_sponza_quality_gpu_validation COMMAND dk_pathmedia_benchmark --quality
        --algorithm spatial --case courtyard-sparse --quality-limit 64 --skip-reference
        --root "${PROJECT_SOURCE_DIR}/projects/demo"
        --output "${PROJECT_BINARY_DIR}/test-artifacts/$<CONFIG>/restir-sponza/quality-smoke.json")
    set_tests_properties(dk.pathtracing.restir_sponza_quality_gpu_validation PROPERTIES TIMEOUT 300 RUN_SERIAL TRUE LABELS "gpu"
        ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1;VK_VALIDATION_VALIDATE_SYNC=1")
    add_test(NAME dk.pathtracing.media_benchmark_gpu_validation COMMAND dk_pathmedia_benchmark --smoke
        --root "${PROJECT_SOURCE_DIR}/projects/demo" --output "${PROJECT_BINARY_DIR}/test-artifacts/$<CONFIG>/media-benchmark/smoke.json")
    set_tests_properties(dk.pathtracing.media_benchmark_gpu_validation PROPERTIES TIMEOUT 300 RUN_SERIAL TRUE LABELS "gpu"
        ENVIRONMENT "VK_LAYER_VALIDATE_SYNC=1;VK_VALIDATION_VALIDATE_SYNC=1")
    if(Python3_Interpreter_FOUND)
        add_test(NAME dk.pathtracing.restir_sponza_aggregation COMMAND "${CMAKE_COMMAND}" -E env "PYTHONDONTWRITEBYTECODE=1"
            "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/RestirSponzaBenchmarkTest.py")
        add_test(NAME dk.pathtracing.media_benchmark_aggregation COMMAND "${CMAKE_COMMAND}" -E env "PYTHONDONTWRITEBYTECODE=1"
            "${Python3_EXECUTABLE}" "${CMAKE_CURRENT_SOURCE_DIR}/PathMediaBenchmarkTest.py")
    endif()
endif()
