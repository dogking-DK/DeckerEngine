set(CMAKE_FOLDER "Engine/Assets/Importers")
# The internal conversion tests live in a sibling directory and also consume the SDK.
find_package(OpenVDB CONFIG REQUIRED GLOBAL)
add_library(dk_asset_voxel_importers STATIC src/VoxelBuilder.cpp)
add_library(dk::asset_voxel_importers ALIAS dk_asset_voxel_importers)
target_sources(dk_asset_voxel_importers PUBLIC FILE_SET HEADERS BASE_DIRS include FILES include/dk/assets/VoxelBuilder.hpp)
target_include_directories(dk_asset_voxel_importers PRIVATE "${PROJECT_SOURCE_DIR}/engine/geometry/voxels/src")
target_compile_definitions(dk_asset_voxel_importers PRIVATE NANOVDB_USE_OPENVDB)
if(MSVC)
    # OpenVDB meshToVolume instantiates a large tree/adapter graph in Debug.
    target_compile_options(dk_asset_voxel_importers PRIVATE /bigobj)
endif()
target_link_libraries(dk_asset_voxel_importers PUBLIC dk::geometry_voxels_sparse PRIVATE OpenVDB::openvdb dk::nanovdb_headers)
dk_target_defaults(dk_asset_voxel_importers)
if(TARGET dk::asset_data AND TARGET dk::io)
    find_package(nlohmann_json CONFIG REQUIRED)
    file(SHA256 "${DK_NANOVDB_INCLUDE_DIR}/nanovdb/NanoVDB.h" DK_VOXEL_NANO_HASH)
    file(SHA256 "${DK_NANOVDB_INCLUDE_DIR}/nanovdb/PNanoVDB.h" DK_VOXEL_PNANO_HASH)
    target_sources(dk_asset_voxel_importers PRIVATE src/VoxelImporter.cpp src/MeshVoxelizer.cpp
        PUBLIC FILE_SET HEADERS BASE_DIRS include FILES include/dk/assets/VoxelImporter.hpp include/dk/assets/MeshVoxelizer.hpp)
    target_link_libraries(dk_asset_voxel_importers PUBLIC dk::asset_data dk::io PRIVATE nlohmann_json::nlohmann_json)
    target_compile_definitions(dk_asset_voxel_importers PRIVATE
        DK_VOXEL_BUILDER_SIGNATURE="voxel-vdb-v1:openvdb-12.0.1:nanovdb-32.7.0:${DK_VOXEL_NANO_HASH}:${DK_VOXEL_PNANO_HASH}")
endif()
