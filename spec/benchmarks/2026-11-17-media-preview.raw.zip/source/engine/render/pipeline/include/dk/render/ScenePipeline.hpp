#pragma once
#include <dk/render/RenderScene.hpp>
#include <dk/render/GpuAssets.hpp>
#include <filesystem>
#include <array>

namespace dk::render {
class AtmosphereSky;
class CloudTextures;
class CloudShadowMap;
class VoxelGpuGrid;
class VoxelAssets;
using VoxelMaterial = VoxelMaterialData;
// Palette is borrowed only for the render call; the frame owns its uploaded copy.
struct VoxelInstance {
    EntityId entity;
    std::shared_ptr<const VoxelGpuGrid> grid;
    Transformd world;
    std::span<const VoxelMaterial> palette;
    AssetId asset; // Required when satisfying a Scene voxel reference; nil for procedural instances.
};
enum class VoxelShading { unlit, directional };
struct VoxelRenderSettings {
    VoxelShading shading=VoxelShading::unlit;
    Vec3f light_direction{0,0,1}; // Unit direction towards the source, in world space.
    Vec3f irradiance=Vec3f::Ones();
    std::uint64_t payload_bytes=256ull*1024*1024;
    std::uint32_t maximum_regions=1024*1024;
};
struct CloudCompositionSettings;
struct CloudOptimizedSettings;
enum class CloudHistoryReset { none, new_view, disabled, resize, projection, camera, scene, content, quality, time, failure };
struct CloudFrameInfo {
    std::uint64_t view_id=0, source_sequence=0, candidate_sequence=0;
    std::uint32_t width=0,height=0; // Integration extent, not output extent.
    bool history_available=false;
    CloudHistoryReset reset=CloudHistoryReset::none;
};
struct CloudHistoryStatus { std::uint64_t completed=0,pending=0; bool reusable=false; };
struct CloudTraceStatistics {
    std::uint32_t primary_steps=0,cloud_lighting_steps=0,empty_steps=0,terminated_steps=0;
    std::uint32_t reconstructed_pixels=0,fallback_pixels=0,history_accepted=0,history_rejected=0;
    std::uint64_t density_samples=0;
    std::uint64_t sun_density_samples=0, sun_weather_samples=0, sun_base_samples=0, sun_detail_samples=0;
};
namespace detail { struct PipelineState; struct FrameState; }
struct RenderSettings {
    Vec3f clear_rgb = Vec3f::Zero(); // Linear HDR color.
    float exposure = 1;
    bool capture_plan = false;
    bool sky_diffuse = true; // Used by atmosphere lit paths; anchor-local sky irradiance.
    bool linear_readback = false; // Diagnostic: <= 65536 pixels, before exposure.
    bool depth_readback = false; // Diagnostic: final D32, <= 65536 pixels.
};
enum class CloudRenderMode { reference, temporal };
struct EnvironmentRenderSettings {
    CloudRenderMode mode=CloudRenderMode::reference;
    double time_seconds=0;
    std::uint64_t view_id=1,camera_revision=0;
    bool cloud_shadows=true;
    Vec3d shadow_center_m=Vec3d::Zero();
    double shadow_extent_m=8192;
    std::uint32_t shadow_resolution=256;
    std::uint32_t cloud_resolution_divisor=2; // Temporal medium grid only; reference remains full-size.
    bool operator==(const EnvironmentRenderSettings&) const = default;
};
[[nodiscard]] Result<void> validate_environment_render_settings(const EnvironmentRenderSettings&);
[[nodiscard]] const char* cloud_history_reset_name(CloudHistoryReset) noexcept;
struct AtmosphereSettings {
    bool surface_lighting = true;
    bool sun_disk = true;
    bool reference = false; // Expensive direct integration; <= 4096 pixels.
};
// Shared by the editor viewport and Runtime capture for reproducible unlit previews.
[[nodiscard]] inline RenderSettings unlit_preview_settings() { return {{0.04f,0.08f,0.16f},1,false}; }
// Diagnostic source fingerprint; includes the shader include closure.
[[nodiscard]] Result<std::string> shader_fingerprint(const std::filesystem::path&, bool environment, bool voxels=false);
[[nodiscard]] Result<void> validate_render_settings(const RenderView&, const RenderSettings&);
struct FrameInfo {
    SceneId scene;
    std::uint64_t revision = 0, frame = 0;
    std::uint32_t width = 0, height = 0;
    std::size_t draw_count = 0;
    std::size_t voxel_count = 0;
};
// Shared immutable result metadata; GPU completion is explicit. Views borrow this owner.
class RenderFrame final {
public:
    RenderFrame() = default;
    [[nodiscard]] explicit operator bool() const noexcept { return bool(state_); }
    [[nodiscard]] FrameInfo info() const noexcept;
    [[nodiscard]] graphics::Submission submission() const noexcept;
    [[nodiscard]] Result<bool> wait(graphics::SubmissionQueue&, std::uint64_t timeout_ns = std::numeric_limits<std::uint64_t>::max()) const;
    [[nodiscard]] Result<void> read_rgba8(std::span<std::byte> destination) const;
    [[nodiscard]] Result<void> read_linear_rgba32f(std::span<std::array<float,4>> destination) const;
    [[nodiscard]] Result<void> read_depth32f(std::span<float> destination) const;
    // Only nonzero cloud frames with diagnostics enabled: cloud L.rgb / Tc.a,
    // or mixed T.rgb / extinction-weighted cloud distance in metres in alpha.
    [[nodiscard]] Result<void> read_cloud_rgba32f(std::span<std::array<float,4>> destination) const;
    [[nodiscard]] Result<void> read_medium_rgba32f(std::span<std::array<float,4>> destination) const;
    [[nodiscard]] CloudFrameInfo cloud_optimization() const noexcept;
    [[nodiscard]] std::uint64_t cloud_shadow_generation() const noexcept;
    [[nodiscard]] Result<CloudTraceStatistics> read_cloud_statistics() const;
    [[nodiscard]] Result<const graphics::Image*> color() const;
    [[nodiscard]] std::string_view plan_text() const noexcept;
private:
    friend class ScenePipeline;
    explicit RenderFrame(std::shared_ptr<const detail::FrameState> state) : state_(std::move(state)) {}
    std::shared_ptr<const detail::FrameState> state_;
};
// Single queue, externally serialized. Does not own or store a raw queue pointer.
class ScenePipeline final {
public:
    ScenePipeline() = default;
    ScenePipeline(ScenePipeline&&) noexcept = default;
    ScenePipeline& operator=(ScenePipeline&&) noexcept = default;
    ScenePipeline(const ScenePipeline&) = delete;
    ScenePipeline& operator=(const ScenePipeline&) = delete;
    [[nodiscard]] static Result<ScenePipeline> create(memory::ResourceHandle, graphics::SubmissionQueue&,
        const std::filesystem::path& shader_directory);
    [[nodiscard]] Result<RenderFrame> render(graphics::SubmissionQueue&, const RenderView&, const GpuAssets&,
        const RenderSettings& = {});
    // Explicit programmatic mesh/voxel composition; no atmosphere/cloud combination.
    [[nodiscard]] Result<RenderFrame> render_voxels(graphics::SubmissionQueue&, const RenderView&, const GpuAssets&,
        std::span<const VoxelInstance>, const VoxelRenderSettings& = {}, const RenderSettings& = {});
    [[nodiscard]] Result<RenderFrame> render_voxel_assets(graphics::SubmissionQueue&, const RenderView&, const GpuAssets&,
        const VoxelAssets&, const VoxelRenderSettings& = {}, const RenderSettings& = {});
    // Explicit Lambert path. Snapshot environment must match the RenderScene exactly.
    // A disabled scene uses unlit; requires DK_BUILD_RENDER_ATMOSPHERE when enabled.
    [[nodiscard]] Result<RenderFrame> render_sunlight(graphics::SubmissionQueue&, const RenderView&, const GpuAssets&,
        const AtmosphereSky&, const RenderSettings& = {}, const CloudShadowMap* = nullptr);
    // Synchronous LUT preparation followed by asynchronous frame submission; call from a worker.
    [[nodiscard]] Result<RenderFrame> render_environment(graphics::SubmissionQueue&, const RenderView&, const GpuAssets&,
        const RenderSettings& = {}, const EnvironmentRenderSettings& = {});
    // Finite forward-Z perspective; the sky anchor must equal camera position.
    [[nodiscard]] Result<RenderFrame> render_atmosphere(graphics::SubmissionQueue&, const RenderView&, const GpuAssets&,
        const AtmosphereSky&, const RenderSettings& = {}, const AtmosphereSettings& = {}, const CloudShadowMap* = nullptr);
    // Explicit full-sample composition, <=4096 pixels, no history. Sky and textures
    // must match the view's environment. Zero clouds use the original M14 path.
    [[nodiscard]] Result<RenderFrame> render_clouds(graphics::SubmissionQueue&, const RenderView&, const GpuAssets&,
        const AtmosphereSky&, const CloudTextures&, const CloudCompositionSettings&, const RenderSettings& = {}, const CloudShadowMap* = nullptr);
    // Explicit half/quarter-resolution path, <=1920*1080 output pixels. Caller owns stable
    // view_id/camera_revision. Poll publishes completed candidates; at most four views.
    [[nodiscard]] Result<RenderFrame> render_clouds_optimized(graphics::SubmissionQueue&, const RenderView&, const GpuAssets&,
        const AtmosphereSky&, const CloudTextures&, const CloudOptimizedSettings&, const RenderSettings& = {}, const CloudShadowMap* = nullptr);
    [[nodiscard]] Result<void> poll_cloud_history(graphics::SubmissionQueue&);
    [[nodiscard]] Result<CloudHistoryStatus> cloud_history(std::uint64_t view_id) const;
    [[nodiscard]] Result<void> release_cloud_history(graphics::SubmissionQueue&, std::uint64_t view_id);
private:
    [[nodiscard]] Result<RenderFrame> render_impl(graphics::SubmissionQueue&, const RenderView&, const GpuAssets&,
        const RenderSettings&, const AtmosphereSky*, const AtmosphereSettings* = nullptr,
        const CloudTextures* = nullptr, const CloudCompositionSettings* = nullptr, const CloudOptimizedSettings* = nullptr, const CloudShadowMap* = nullptr,
        std::span<const VoxelInstance> = {}, const VoxelRenderSettings* = nullptr);
    explicit ScenePipeline(std::shared_ptr<detail::PipelineState> state) : state_(std::move(state)) {}
    std::shared_ptr<detail::PipelineState> state_;
};
} // namespace dk::render
