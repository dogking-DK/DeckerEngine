#pragma once
#include <dk/graphics/Device.hpp>
#include <dk/graphics/GpuProfiling.hpp>
#include <cstddef>
#include <limits>

namespace dk::graphics {
enum class BufferMemory { device, upload, readback };
struct BufferDesc {
    vk::DeviceSize size = 0;
    vk::BufferUsageFlags usage = vk::BufferUsageFlagBits::eTransferSrc | vk::BufferUsageFlagBits::eTransferDst;
    BufferMemory memory = BufferMemory::device;
};
struct ImageDesc {
    std::uint32_t width = 0, height = 0;
    vk::Format format = vk::Format::eR8G8B8A8Unorm;
    vk::ImageUsageFlags usage = vk::ImageUsageFlagBits::eTransferSrc | vk::ImageUsageFlagBits::eTransferDst | vk::ImageUsageFlagBits::eSampled;
    std::uint32_t mip_levels = 1, array_layers = 1;
    std::uint32_t depth = 1;
    vk::ImageType type = vk::ImageType::e2D;
    bool require_linear_filter = false; // Request sampled-image linear filtering capability.
};
struct AccessState {
    vk::PipelineStageFlags2 stages{};
    vk::AccessFlags2 access{};
    vk::ImageLayout layout = vk::ImageLayout::eUndefined;
    bool initialized = false;
    bool operator==(const AccessState&) const = default;
};
namespace detail { struct ResourceState; struct QueueState; struct BatchState; struct SubmissionAccess; struct ObjectAccess; struct PresentationAccess; struct ImageTransferState; }
struct AllocationBudgetStats {
    std::uint64_t limit = 0, current = 0, peak = 0;
    std::uint64_t host_visible = 0, device_local = 0, allocations = 0;
};
// Thread-safe accounting shared by factories and actual allocation owners.
class AllocationBudget final {
public:
    explicit AllocationBudget(std::uint64_t limit) { stats_.limit=limit; }
    AllocationBudget(const AllocationBudget&) = delete;
    AllocationBudget& operator=(const AllocationBudget&) = delete;
    [[nodiscard]] AllocationBudgetStats stats() const noexcept { std::lock_guard lock(mutex_); return stats_; }
private:
    friend struct detail::ResourceState;
    mutable std::mutex mutex_;
    AllocationBudgetStats stats_;
};
class CommandBatch;
class SubmissionQueue;
class ResourceFactory;
class RenderEncoder;
class ComputeEncoder;
class ImageView;
class Sampler;
class ShaderModule;
class PipelineLayout;
class ComputePipeline;
class GraphicsPipeline;
class BindingSet;
class AccelerationStructure;
class RayTracingPipeline;
class ShaderBindingTable;
class RayTracingEncoder;
class ReadbackRequest;
struct ResourceUse;
struct ResourceBarrier;
struct RenderingDesc;
struct ImageCopyRegion;

// Buffer owns VMA memory; Image owns VMA memory or a presentation generation.
// Native handles are borrowed; submitted batches retain the corresponding owner.
// All accesses to a queue and its resources must be externally serialized.
class Buffer final {
public:
    Buffer() = default;
    Buffer(Buffer&&) noexcept = default;
    Buffer& operator=(Buffer&&) noexcept = default;
    Buffer(const Buffer&) = delete;
    Buffer& operator=(const Buffer&) = delete;
    [[nodiscard]] explicit operator bool() const noexcept { return bool(state_); }
    [[nodiscard]] vk::Buffer handle() const noexcept;
    [[nodiscard]] vk::DeviceSize size() const noexcept;
    [[nodiscard]] BufferDesc description() const noexcept;
    // Borrowed address; keep the Buffer owner alive through every GPU use.
    [[nodiscard]] Result<vk::DeviceAddress> device_address() const;
    [[nodiscard]] Buffer share() const noexcept { return Buffer{state_}; }
    [[nodiscard]] Result<AccessState> state() const;
    [[nodiscard]] Result<void> write(vk::DeviceSize offset, std::span<const std::byte> bytes);
    [[nodiscard]] Result<void> read(vk::DeviceSize offset, std::span<std::byte> bytes) const;
private:
    friend class SubmissionQueue;
    friend class CommandBatch;
    friend class ResourceFactory;
    friend struct detail::ObjectAccess;
    explicit Buffer(std::shared_ptr<detail::ResourceState> state) : state_(std::move(state)) {}
    std::shared_ptr<detail::ResourceState> state_;
};
class Image final {
public:
    Image() = default;
    Image(Image&&) noexcept = default;
    Image& operator=(Image&&) noexcept = default;
    Image(const Image&) = delete;
    Image& operator=(const Image&) = delete;
    [[nodiscard]] explicit operator bool() const noexcept { return bool(state_); }
    [[nodiscard]] vk::Image handle() const noexcept;
    [[nodiscard]] ImageDesc description() const noexcept;
    [[nodiscard]] Image share() const noexcept { return Image{state_}; }
    // Last successfully submitted states, ordered by layer then mip; not completion.
    [[nodiscard]] Result<AccessState> state(std::uint32_t mip = 0, std::uint32_t layer = 0) const;
private:
    friend class SubmissionQueue;
    friend class CommandBatch;
    friend class ResourceFactory;
    friend struct detail::ObjectAccess;
    friend struct detail::PresentationAccess;
    explicit Image(std::shared_ptr<detail::ResourceState> state) : state_(std::move(state)) {}
    std::shared_ptr<detail::ResourceState> state_;
};
// Single-consumer transfer of a completed, sealed image between queues of one device/family.
class ImageTransfer final {
public:
    ImageTransfer() = default;
    ImageTransfer(ImageTransfer&&) noexcept = default;
    ImageTransfer& operator=(ImageTransfer&&) noexcept = default;
    ImageTransfer(const ImageTransfer&) = delete;
    ImageTransfer& operator=(const ImageTransfer&) = delete;
    [[nodiscard]] explicit operator bool() const noexcept { return bool(state_); }
private:
    friend class SubmissionQueue;
    explicit ImageTransfer(std::shared_ptr<detail::ImageTransferState> state) : state_(std::move(state)) {}
    std::shared_ptr<detail::ImageTransferState> state_;
};
class Submission final {
public:
    Submission() = default;
    [[nodiscard]] std::uint64_t value() const noexcept { return value_; }
    [[nodiscard]] GpuProfile gpu_profile() const noexcept { return profile_; }
private:
    friend class SubmissionQueue;
    std::weak_ptr<detail::QueueState> owner_;
    std::uint64_t value_ = 0;
    GpuProfile profile_;
};
class CommandBatch final {
public:
    CommandBatch();
    ~CommandBatch(); // Abandons unsubmitted work and releases recording reservations.
    CommandBatch(CommandBatch&&) noexcept;
    CommandBatch& operator=(CommandBatch&&) noexcept;
    CommandBatch(const CommandBatch&) = delete;
    CommandBatch& operator=(const CommandBatch&) = delete;
    [[nodiscard]] Result<void> retain(const Buffer& buffer);
    [[nodiscard]] Result<void> retain(const Image& image);
    [[nodiscard]] Result<void> retain(const ImageView& view);
    [[nodiscard]] Result<void> retain(const Sampler& sampler);
    [[nodiscard]] Result<void> retain(const ShaderModule& shader);
    [[nodiscard]] Result<void> retain(const PipelineLayout& layout);
    [[nodiscard]] Result<void> retain(const ComputePipeline& pipeline);
    [[nodiscard]] Result<void> retain(const GraphicsPipeline& pipeline);
    [[nodiscard]] Result<void> retain(const BindingSet& bindings);
    // One immutable candidate BUILD. Handles input/scratch/BLAS dependencies and retention.
    [[nodiscard]] Result<void> build(const AccelerationStructure& candidate);
    [[nodiscard]] Result<void> prepare_build(const AccelerationStructure& candidate);
    [[nodiscard]] Result<void> build_prepared(const AccelerationStructure& candidate);
    [[nodiscard]] Result<void> retain(const AccelerationStructure& structure);
    [[nodiscard]] Result<void> retain(const ShaderBindingTable& table);
    [[nodiscard]] Result<AccessState> state(const AccelerationStructure& structure) const;
    [[nodiscard]] Result<AccessState> state(const ShaderBindingTable& table) const;
    [[nodiscard]] Result<void> prepare_acceleration_read(const AccelerationStructure& structure, bool trace);
    [[nodiscard]] Result<void> prepare_trace(const ShaderBindingTable& table, std::span<const AccelerationStructure* const> structures);
    [[nodiscard]] Result<RayTracingEncoder> ray_tracing();
    [[nodiscard]] Result<void> copy(const Buffer& source, const Buffer& destination,
        vk::DeviceSize size, vk::DeviceSize source_offset = 0, vk::DeviceSize destination_offset = 0);
    [[nodiscard]] Result<void> copy_to_image(const Buffer& source, const Image& destination);
    [[nodiscard]] Result<void> copy_to_buffer(const Image& source, const Buffer& destination);
    [[nodiscard]] Result<void> transition(const Image& image, vk::ImageLayout layout);
    [[nodiscard]] Result<void> prepare(std::span<const ResourceUse> uses);
    // Local recording state; never publishes or changes the resource ledger.
    [[nodiscard]] Result<AccessState> state(const Buffer& buffer) const;
    [[nodiscard]] Result<AccessState> state(const Image& image, std::uint32_t mip = 0, std::uint32_t layer = 0) const;
    // End a typed pass: all declared writes must have executed, rendering must have ended.
    // Clears preparations and invalidates borrowed encoders on success.
    [[nodiscard]] Result<void> finish_pass();
    // One non-nested pass interval inside the automatic submission interval.
    [[nodiscard]] Result<void> begin_gpu_zone(std::string_view name, GpuZoneKind kind = GpuZoneKind::other);
    [[nodiscard]] Result<void> end_gpu_zone();
    [[nodiscard]] Result<void> barrier(std::span<const ResourceBarrier> barriers);
    [[nodiscard]] Result<RenderEncoder> begin_rendering(const RenderingDesc& description);
    [[nodiscard]] Result<ComputeEncoder> compute();
    [[nodiscard]] Result<void> dispatch(const ComputePipeline& pipeline, std::span<const BindingSet* const> sets,
        std::span<const std::byte> push_constants, std::array<std::uint32_t,3> groups);
    [[nodiscard]] Result<void> copy_buffer(const Buffer& source, const Buffer& destination,
        vk::DeviceSize size, vk::DeviceSize source_offset = 0, vk::DeviceSize destination_offset = 0);
    [[nodiscard]] Result<void> copy_to_image(const Buffer& source, const Image& destination, const ImageCopyRegion& region);
    [[nodiscard]] Result<void> copy_to_buffer(const Image& source, const Buffer& destination, const ImageCopyRegion& region);
    [[nodiscard]] Result<void> fill(const Buffer& buffer, std::uint32_t value = 0);
    [[nodiscard]] Result<void> clear(const Image& image, const vk::ClearColorValue& color, const vk::ImageSubresourceRange& range);
    [[nodiscard]] Result<void> clear_depth(const Image& image, float depth, const vk::ImageSubresourceRange& range);
    [[nodiscard]] Result<void> upload(const Buffer& destination, std::span<const std::byte> bytes, vk::DeviceSize offset = 0);
    [[nodiscard]] Result<void> upload(const Image& destination, std::span<const std::byte> bytes, const ImageCopyRegion& region);
    [[nodiscard]] Result<ReadbackRequest> readback(const Buffer& source, vk::DeviceSize offset = 0, vk::DeviceSize size = VK_WHOLE_SIZE);
    [[nodiscard]] Result<ReadbackRequest> readback(const Image& source, const ImageCopyRegion& region);
    using NativeRecorder = void (*)(const vk::raii::CommandBuffer&, void*);
    [[nodiscard]] Result<void> unsafe_record(std::span<const ResourceUse> before, std::span<const ResourceUse> after,
        NativeRecorder recorder, void* user_data = nullptr);
    // Valid only during this batch. Retain every manually referenced resource.
    // Do not end/submit/reset the command buffer or bypass tracked image layouts.
    [[deprecated("Use typed encoders or unsafe_record with explicit resource declarations")]]
    [[nodiscard]] const vk::raii::CommandBuffer& command_buffer() const;
private:
    friend class SubmissionQueue;
    friend struct detail::ObjectAccess;
    friend struct detail::PresentationAccess;
    explicit CommandBatch(std::shared_ptr<detail::BatchState> state);
    std::shared_ptr<detail::BatchState> state_;
};
struct SubmissionStats {
    std::uint64_t submitted = 0, completed = 0;
    std::uint32_t free_slots = 0, recording_slots = 0, pending_slots = 0;
    std::size_t retained_resources = 0; // References retained by pending slots.
    bool closed = false, device_lost = false;
};
class SubmissionQueue final {
public:
    // Consumes Device. Buffer/Image keep the device alive beyond this queue.
    [[nodiscard]] static Result<SubmissionQueue> create(memory::ResourceHandle resource, Device&& device, std::uint32_t slots = 3);
    ~SubmissionQueue(); // Drains submitted work before destroying pools/semaphore.
    // Moved-from queues may only be destroyed or assigned to.
    SubmissionQueue(SubmissionQueue&&) noexcept;
    SubmissionQueue& operator=(SubmissionQueue&&) noexcept;
    SubmissionQueue(const SubmissionQueue&) = delete;
    SubmissionQueue& operator=(const SubmissionQueue&) = delete;
    [[nodiscard]] const Device& device() const noexcept;
    [[nodiscard]] ResourceFactory resources() const noexcept;
    // Requires all slots free. Enabling performs one bounded-resource clock alignment submission.
    [[nodiscard]] Result<void> configure_gpu_profiling(GpuProfilingOptions options);
    [[nodiscard]] Result<Buffer> create_buffer(const BufferDesc& description);
    [[nodiscard]] Result<Image> create_image(const ImageDesc& description);
    // Export seals all source aliases. Import consumes only on success; no pixel copy/readback.
    [[nodiscard]] Result<ImageTransfer> export_image(const Image&);
    [[nodiscard]] Result<Image> import_image(ImageTransfer&&);
    [[nodiscard]] Result<CommandBatch> begin();
    // Consumes a valid local batch on success or driver failure, never publishes on failure.
    [[nodiscard]] Result<Submission> submit(CommandBatch&& batch);
    [[nodiscard]] Result<void> poll();
    [[nodiscard]] Result<bool> wait(const Submission& submission, std::uint64_t timeout_ns = std::numeric_limits<std::uint64_t>::max());
    [[nodiscard]] Result<void> close();
    [[nodiscard]] SubmissionStats stats() const noexcept;
private:
    friend struct detail::PresentationAccess;
    [[nodiscard]] Result<Submission> submit_impl(CommandBatch&& batch, vk::Semaphore wait, vk::Semaphore signal);
    friend struct detail::SubmissionAccess;
    friend class ResourceFactory;
    [[nodiscard]] Result<Buffer> create_buffer(const BufferDesc&, const std::shared_ptr<AllocationBudget>&);
    [[nodiscard]] Result<Image> create_image(const ImageDesc&, const std::shared_ptr<AllocationBudget>&);
    explicit SubmissionQueue(std::shared_ptr<detail::QueueState> state) : state_(std::move(state)) {}
    std::shared_ptr<detail::QueueState> state_;
};
} // namespace dk::graphics
