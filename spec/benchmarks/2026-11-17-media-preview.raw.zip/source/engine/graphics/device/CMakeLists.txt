if(NOT DK_BUILD_MEMORY)
    message(FATAL_ERROR "DK_BUILD_GRAPHICS_DEVICE requires DK_BUILD_MEMORY")
endif()
find_package(VulkanHeaders 1.4 CONFIG REQUIRED)
find_package(volk CONFIG REQUIRED)
find_package(vk-bootstrap CONFIG REQUIRED)
find_package(VulkanMemoryAllocator CONFIG REQUIRED)
# Isolate third-party implementation warnings from /W4 /WX on engine sources.
add_library(dk_graphics_vma STATIC src/Vma.cpp)
target_compile_features(dk_graphics_vma PRIVATE cxx_std_23)
target_compile_definitions(dk_graphics_vma PRIVATE VK_NO_PROTOTYPES)
target_link_libraries(dk_graphics_vma PRIVATE Vulkan::Headers GPUOpen::VulkanMemoryAllocator)
if(MSVC)
    target_compile_options(dk_graphics_vma PRIVATE /W0 /utf-8)
else()
    target_compile_options(dk_graphics_vma PRIVATE -w)
endif()
add_library(dk_graphics_device STATIC src/Device.cpp src/Selection.cpp src/Bootstrap.cpp src/Resources.cpp
    src/GpuObjects.cpp src/Pipeline.cpp src/Bindings.cpp src/ResourceSync.cpp src/ResourceValidation.cpp src/CommandTransfer.cpp src/CommandEncoder.cpp src/Transfer.cpp src/GpuProfiling.cpp src/AccelerationStructure.cpp src/RayTracing.cpp src/CommandRayTracing.cpp)
add_library(dk::graphics_device ALIAS dk_graphics_device)
target_sources(dk_graphics_device PUBLIC FILE_SET HEADERS BASE_DIRS include FILES
    include/dk/graphics/Device.hpp include/dk/graphics/Resources.hpp include/dk/graphics/GpuObjects.hpp
    include/dk/graphics/Pipeline.hpp include/dk/graphics/Bindings.hpp include/dk/graphics/CommandEncoder.hpp include/dk/graphics/Transfer.hpp
    include/dk/graphics/ResourceValidation.hpp include/dk/graphics/GpuProfiling.hpp include/dk/graphics/AccelerationStructure.hpp include/dk/graphics/RayTracing.hpp)
target_compile_definitions(dk_graphics_device PUBLIC VK_NO_PROTOTYPES
    VULKAN_HPP_ENABLE_DYNAMIC_LOADER_TOOL=0 VULKAN_HPP_NO_DEFAULT_DISPATCHER)
target_link_libraries(dk_graphics_device PUBLIC dk::core dk::memory dk::graphics_shader_types Vulkan::Headers GPUOpen::VulkanMemoryAllocator
    PRIVATE dk::profiling volk::volk vk-bootstrap::vk-bootstrap dk_graphics_vma ${CMAKE_DL_LIBS})
dk_target_defaults(dk_graphics_device)
