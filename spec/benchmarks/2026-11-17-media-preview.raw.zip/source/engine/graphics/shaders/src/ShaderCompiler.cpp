#include <dk/graphics/ShaderCompiler.hpp>
#include <dk/io/File.hpp>
#include <dk/io/Path.hpp>
#include <dk/profiling/Profiler.hpp>
#include <slang.h>
#include <slang-com-ptr.h>
#include <nlohmann/json.hpp>
#include <algorithm>
#include <cstring>
#include <limits>
#include <tuple>

namespace dk::graphics {
namespace {
using Slang::ComPtr;
using Category = slang::ParameterCategory;
using Kind = slang::TypeReflection::Kind;

bool identifier(std::string_view text)
{
    const auto alpha = [](char c) { return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == '_'; };
    return !text.empty() && alpha(text.front()) && std::ranges::all_of(text, [alpha](char c) {
        return alpha(c) || (c >= '0' && c <= '9');
    });
}
bool has_nul(std::string_view text) { return text.find('\0') != std::string_view::npos; }
SlangStage slang_stage(ShaderStage stage)
{
    switch (stage) {
    case ShaderStage::vertex: return SLANG_STAGE_VERTEX;
    case ShaderStage::fragment: return SLANG_STAGE_FRAGMENT;
    case ShaderStage::compute: return SLANG_STAGE_COMPUTE;
    case ShaderStage::raygeneration: return SLANG_STAGE_RAY_GENERATION;
    case ShaderStage::miss: return SLANG_STAGE_MISS;
    case ShaderStage::closesthit: return SLANG_STAGE_CLOSEST_HIT;
    case ShaderStage::anyhit: return SLANG_STAGE_ANY_HIT;
    case ShaderStage::intersection: return SLANG_STAGE_INTERSECTION;
    }
    return SLANG_STAGE_NONE;
}
void append_diagnostics(String& text, const ComPtr<slang::IBlob>& blob)
{
    if (!blob || blob->getBufferSize() == 0) { return; }
    auto size = blob->getBufferSize();
    const auto* bytes = static_cast<const char*>(blob->getBufferPointer());
    if (bytes[size - 1] == '\0') { --size; }
    text.append(bytes, size);
}
bool bounded(std::size_t value) { return value > 0 && value <= std::numeric_limits<std::uint32_t>::max(); }

Result<void> reflect(slang::ProgramLayout* layout, CompiledShader& output)
{
    const auto fail = [](std::string detail) -> Result<void> {
        return std::unexpected(Error{ErrorCode::not_supported, "Unsupported shader layout: " + detail});
    };
    auto* entry = layout->getEntryPointByIndex(0);
    if (!entry || entry->getStage() != slang_stage(output.stage)) {
        return std::unexpected(Error{ErrorCode::invalid_argument, "Shader stage does not match the entry point attribute"});
    }
    // Entry parameters are stage IO only; resources/uniforms must be global.
    auto* entry_type = entry->getVarLayout()->getTypeLayout();
    for (unsigned i = 0; i < entry_type->getCategoryCount(); ++i) {
        const auto category = entry_type->getCategoryByIndex(i);
        if (category != Category::VaryingInput && category != Category::VaryingOutput &&
            !(is_ray_tracing_stage(output.stage) && (category == Category::RayPayload || category == Category::HitAttributes))) {
            return fail("entry-point uniform or resource parameters");
        }
    }
    if (output.stage == ShaderStage::compute) {
        SlangUInt threads[3]{};
        entry->getComputeThreadGroupSize(3, threads);
        for (std::size_t i = 0; i < 3; ++i) {
            if (!bounded(threads[i])) { return fail("unresolved compute thread group size"); }
            output.thread_group_size[i] = static_cast<std::uint32_t>(threads[i]);
        }
    }
    const auto resource = output.spirv.get_allocator().resource();
    for (unsigned i = 0; i < layout->getParameterCount(); ++i) {
        auto* parameter = layout->getParameterByIndex(i);
        auto* type = parameter->getTypeLayout();
        const std::string name = parameter->getName() ? parameter->getName() : "<unnamed>";
        if (type->getKind() == Kind::ConstantBuffer && type->getSize(Category::PushConstantBuffer) != 0) {
            auto* element = type->getElementTypeLayout();
            const auto size = element->getSize(Category::Uniform);
            if (!output.push_constants.empty() || !bounded(size) || size % 4 != 0
                || element->getBindingRangeCount() != 0) {
                return fail(name + ": only one plain, sized push constant block is supported");
            }
            output.push_constants.push_back({0, static_cast<std::uint32_t>(size)});
            continue;
        }
        auto* leaf = type;
        while (leaf->getKind() == Kind::Array) { leaf = leaf->getElementTypeLayout(); }
        if (leaf->getKind() != Kind::ConstantBuffer && leaf->getKind() != Kind::Resource
            && leaf->getKind() != Kind::SamplerState && leaf->getKind() != Kind::ShaderStorageBuffer) {
            return fail(name + ": global parameters must be resource bindings or a push constant block");
        }
        if (type->getBindingRangeCount() != 1 || type->isBindingRangeSpecializable(0)
            || type->getSize(Category::DescriptorTableSlot) == 0) {
            return fail(name + ": nested or specialized resource layout");
        }
        const auto count = type->getBindingRangeBindingCount(0);
        const auto binding = parameter->getOffset(Category::DescriptorTableSlot);
        const auto set = parameter->getBindingSpace(Category::DescriptorTableSlot);
        if (count <= 0 || !bounded(static_cast<std::size_t>(count))
            || binding >= std::numeric_limits<std::uint32_t>::max() || set >= std::numeric_limits<std::uint32_t>::max()) {
            return fail(name + ": unbounded or unresolved descriptor range");
        }
        ShaderBinding result{String{name, memory::Allocator<char>{resource}}, static_cast<std::uint32_t>(set),
            static_cast<std::uint32_t>(binding), ShaderDescriptorType::storage_buffer, static_cast<std::uint32_t>(count), 0};
        switch (type->getBindingRangeType(0)) {
        case slang::BindingType::ConstantBuffer: {
            const auto size = leaf->getElementTypeLayout()->getSize(Category::Uniform);
            if (!bounded(size) || leaf->getElementTypeLayout()->getBindingRangeCount() != 0) {
                return fail(name + ": constant buffer must contain only sized plain data");
            }
            result.type = ShaderDescriptorType::uniform_buffer;
            result.block_size = static_cast<std::uint32_t>(size);
            break;
        }
        case slang::BindingType::RawBuffer:
        case slang::BindingType::MutableRawBuffer: result.type = ShaderDescriptorType::storage_buffer; break;
        case slang::BindingType::Texture: result.type = ShaderDescriptorType::sampled_image; break;
        case slang::BindingType::MutableTexture: result.type = ShaderDescriptorType::storage_image; break;
        case slang::BindingType::Sampler: result.type = ShaderDescriptorType::sampler; break;
        case slang::BindingType::RayTracingAccelerationStructure: result.type = ShaderDescriptorType::acceleration_structure; break;
        default: return fail(name + ": unsupported descriptor type");
        }
        if (result.type == ShaderDescriptorType::sampled_image || result.type == ShaderDescriptorType::storage_image) {
            switch (leaf->getResourceShape()) {
            case SLANG_TEXTURE_2D: result.image_shape = ShaderImageShape::image_2d; break;
            case SLANG_TEXTURE_2D_ARRAY: result.image_shape = ShaderImageShape::image_2d_array; break;
            case SLANG_TEXTURE_3D: result.image_shape = ShaderImageShape::image_3d; break;
            default: return fail(name + ": unsupported image shape (expected 2D, 2D array or 3D)");
            }
        }
        output.bindings.push_back(std::move(result));
    }
    std::ranges::sort(output.bindings, [](const ShaderBinding& a, const ShaderBinding& b) {
        return std::tie(a.set, a.binding) < std::tie(b.set, b.binding);
    });
    for (std::size_t i = 1; i < output.bindings.size(); ++i) {
        if (output.bindings[i - 1].set == output.bindings[i].set
            && output.bindings[i - 1].binding == output.bindings[i].binding) {
            return fail("duplicate descriptor set/binding");
        }
    }
    return {};
}
} // namespace

namespace {
Result<CompiledShader> compile_shader_impl(const ShaderCompileRequest& request, memory::ResourceHandle resource,
    ComPtr<slang::IGlobalSession>& global,std::stop_token cancel)
{
    DK_PROFILE_ZONE("Shader.compile");
    const auto cancelled=[] { return std::unexpected(Error{ErrorCode::invalid_state,
        "Shader compilation cancelled",{"graphics.shader.compile.cancelled"}}); };
    if (!resource || resource.state() != memory::ResourceState::open) {
        return std::unexpected(Error{ErrorCode::invalid_state, "Shader compilation requires an open Memory resource"});
    }
    if (request.source.empty() || !identifier(request.entry) || slang_stage(request.stage) == SLANG_STAGE_NONE) {
        return std::unexpected(Error{ErrorCode::invalid_argument, "Shader source, identifier entry and supported stage are required"});
    }
    if (cancel.stop_requested()) return cancelled();
    std::error_code ec;
    const auto absolute = std::filesystem::absolute(request.source, ec);
    if (ec) { return std::unexpected(Error{ErrorCode::io_error, "Cannot resolve shader source: " + ec.message()}); }
    const auto path = path_to_utf8(absolute);
    if (!path) { return std::unexpected(path.error()); }
    if (has_nul(*path)) { return std::unexpected(Error{ErrorCode::invalid_argument, "NUL in shader path"}); }
    auto bytes = read_file_bytes(absolute);
    if (!bytes) { return std::unexpected(bytes.error()); }
    std::string source(bytes->size(), '\0');
    if (!bytes->empty()) { std::memcpy(source.data(), bytes->data(), bytes->size()); }
    if (has_nul(source)) { return std::unexpected(Error{ErrorCode::invalid_argument, "NUL in shader source"}); }
    CompiledShader output{resource};
    output.entry.assign(request.entry);
    output.stage = request.stage;
    output.requires_ray_tracing = is_ray_tracing_stage(request.stage);
    const auto fail = [&](std::string operation, ErrorCode code = ErrorCode::invalid_argument) -> Result<CompiledShader> {
        if (!output.diagnostics.empty()) { operation += "\n" + std::string{output.diagnostics}; }
        return std::unexpected(Error{code, std::move(operation), {*path, "entry=" + std::string{request.entry},
            "stage=" + std::string{shader_stage_name(request.stage)}}});
    };
    std::vector<std::string> search_storage;
    for (const auto& include : request.include_paths) {
        auto text = path_to_utf8(include);
        if (!text) { return std::unexpected(text.error()); }
        if (text->empty() || has_nul(*text)) { return fail("Invalid include path"); }
        search_storage.push_back(std::move(*text));
    }
    std::vector<const char*> search_paths;
    for (const auto& text : search_storage) { search_paths.push_back(text.c_str()); }
    std::vector<std::pair<std::string, std::string>> define_storage;
    for (const auto& define : request.defines) {
        if (!identifier(define.name) || has_nul(define.value)) { return fail("Invalid preprocessor definition"); }
        for (const auto& previous : define_storage) {
            if (previous.first == define.name) { return fail("Duplicate preprocessor definition: " + previous.first); }
        }
        define_storage.emplace_back(define.name, define.value);
    }
    std::vector<slang::PreprocessorMacroDesc> defines;
    for (const auto& [name, value] : define_storage) { defines.push_back({name.c_str(), value.c_str()}); }
    if (cancel.stop_requested()) return cancelled();
    if (!global && SLANG_FAILED(slang::createGlobalSession(global.writeRef()))) { return fail("Cannot create Slang global session", ErrorCode::internal_error); }
    if (cancel.stop_requested()) return cancelled();
    output.compiler = global->getBuildTagString();
    // Slang may still return code after a missing optimizer diagnostic. Require the
    // selected backend up front so a broken deployment cannot silently change policy.
    if (SLANG_FAILED(global->checkPassThroughSupport(SLANG_PASS_THROUGH_SPIRV_OPT))) {
        return fail("Slang spirv-opt backend unavailable; deploy the matching slang-glslang runtime library", ErrorCode::not_supported);
    }
    if (cancel.stop_requested()) return cancelled();
    slang::TargetDesc target{};
    target.format = SLANG_SPIRV;
    target.profile = global->findProfile("spirv_1_5");
    slang::CompilerOptionEntry options[5]{};
    options[0].name = slang::CompilerOptionName::EmitSpirvDirectly;
    options[0].value.intValue0 = 1;
    options[1].name = slang::CompilerOptionName::VulkanUseEntryPointName;
    options[1].value.intValue0 = 1;
    options[2].name = slang::CompilerOptionName::Optimization;
    options[2].value.intValue0 = SLANG_OPTIMIZATION_LEVEL_DEFAULT;
    options[3].name = slang::CompilerOptionName::DebugInformation;
    options[3].value.intValue0 = SLANG_DEBUG_INFO_LEVEL_NONE;
    options[4].name = slang::CompilerOptionName::FloatingPointMode;
    options[4].value.intValue0 = SLANG_FLOATING_POINT_MODE_PRECISE;
    target.compilerOptionEntries = &options[4];
    target.compilerOptionEntryCount = request.precise_floating_point ? 1 : 0;
    slang::SessionDesc session_desc{};
    session_desc.targets = &target;
    session_desc.targetCount = 1;
    session_desc.defaultMatrixLayoutMode = SLANG_MATRIX_LAYOUT_ROW_MAJOR;
    session_desc.searchPaths = search_paths.data();
    session_desc.searchPathCount = static_cast<SlangInt>(search_paths.size());
    session_desc.preprocessorMacros = defines.data();
    session_desc.preprocessorMacroCount = static_cast<SlangInt>(defines.size());
    session_desc.compilerOptionEntries = options;
    session_desc.compilerOptionEntryCount = 4;
    ComPtr<slang::ISession> session;
    if (SLANG_FAILED(global->createSession(session_desc, session.writeRef()))) { return fail("Cannot create Slang session", ErrorCode::internal_error); }
    if (cancel.stop_requested()) return cancelled();
    ComPtr<slang::IBlob> diagnostics;
    auto* module = session->loadModuleFromSourceString("dk_shader", path->c_str(), source.c_str(), diagnostics.writeRef());
    append_diagnostics(output.diagnostics, diagnostics);
    if (!module) { return fail("Slang source compilation failed"); }
    if (cancel.stop_requested()) return cancelled();
    ComPtr<slang::IEntryPoint> entry;
    if (SLANG_FAILED(module->findEntryPointByName(output.entry.c_str(), entry.writeRef()))) {
        return fail("Entry point not found; declare a stage using [shader(...)] or a Slang-recognized stage attribute", ErrorCode::not_found);
    }
    slang::IComponentType* parts[] = {module, entry.get()};
    ComPtr<slang::IComponentType> program;
    auto status = session->createCompositeComponentType(parts, 2, program.writeRef(), diagnostics.writeRef());
    append_diagnostics(output.diagnostics, diagnostics);
    if (SLANG_FAILED(status)) { return fail("Slang composition failed"); }
    if (cancel.stop_requested()) return cancelled();
    ComPtr<slang::IComponentType> linked;
    status = program->link(linked.writeRef(), diagnostics.writeRef());
    append_diagnostics(output.diagnostics, diagnostics);
    if (SLANG_FAILED(status)) { return fail("Slang linking failed"); }
    if (cancel.stop_requested()) return cancelled();
    auto* layout = linked->getLayout(0, diagnostics.writeRef());
    append_diagnostics(output.diagnostics, diagnostics);
    if (!layout) { return fail("Slang layout failed"); }
    if (auto result = reflect(layout, output); !result) { return fail(result.error().message, result.error().code); }
    if (cancel.stop_requested()) return cancelled();
    ComPtr<slang::IBlob> code;
    status = linked->getEntryPointCode(0, 0, code.writeRef(), diagnostics.writeRef());
    append_diagnostics(output.diagnostics, diagnostics);
    if (SLANG_FAILED(status)) { return fail("Slang SPIR-V generation failed"); }
    if (cancel.stop_requested()) return cancelled();
    if (!code || code->getBufferSize() < 20 || code->getBufferSize() % sizeof(std::uint32_t) != 0) {
        return fail("Invalid SPIR-V artifact from Slang", ErrorCode::internal_error);
    }
    output.spirv.resize(code->getBufferSize() / sizeof(std::uint32_t));
    std::memcpy(output.spirv.data(), code->getBufferPointer(), code->getBufferSize());
    for (std::size_t i=5;i<output.spirv.size();) {
        const auto count=output.spirv[i]>>16, opcode=output.spirv[i]&0xffffu;
        if (!count || count>output.spirv.size()-i) return fail("Malformed SPIR-V instruction");
        if (opcode==17 && count==2 && (output.spirv[i+1]==5301 || output.spirv[i+1]==5307))
            output.requires_sampled_image_indexing=true;
        i+=count;
    }
    if (output.spirv[0] != 0x07230203U || output.spirv[1] != 0x00010500U) {
        return fail("Unexpected SPIR-V magic/version", ErrorCode::internal_error);
    }
    output.dependencies.emplace_back(*path, memory::Allocator<char>{resource});
    for (SlangInt32 i = 0; i < session->getLoadedModuleCount(); ++i) {
        auto* loaded = session->getLoadedModule(i);
        for (SlangInt32 j = 0; j < loaded->getDependencyFileCount(); ++j) {
            if (const auto* dependency = loaded->getDependencyFilePath(j)) {
                output.dependencies.emplace_back(dependency, memory::Allocator<char>{resource});
            }
        }
    }
    std::ranges::sort(output.dependencies);
    output.dependencies.erase(std::unique(output.dependencies.begin(), output.dependencies.end()), output.dependencies.end());
    auto ray_interface = reflect_ray_interface(output);
    if (!ray_interface) return fail(ray_interface.error().message, ray_interface.error().code);
    output.ray_interface = std::move(*ray_interface);
    output.source_fingerprint = 14695981039346656037ULL;
    const auto hash = [&](std::span<const std::byte> bytes_to_hash) {
        for (const auto byte : bytes_to_hash) { output.source_fingerprint ^= std::to_integer<unsigned char>(byte); output.source_fingerprint *= 1099511628211ULL; }
    };
    const auto hash_text = [&](std::string_view text) { hash(std::as_bytes(std::span{text})); const std::array delimiter{std::byte{0}}; hash(delimiter); };
    hash_text(output.compiler); hash_text("spirv_1_5/row_major"); hash_text(output.entry); hash_text(shader_stage_name(output.stage));
    for (const auto& define : request.defines) { hash_text(define.name); hash_text(define.value); }
    if (request.precise_floating_point) hash_text("fp-mode=precise");
    for (const auto& dependency : output.dependencies) {
        auto dependency_path = path_from_utf8(dependency);
        if (!dependency_path) return fail(dependency_path.error().message);
        auto content = read_file_bytes(*dependency_path);
        if (!content) return fail(content.error().message);
        hash_text(dependency); hash(*content);
    }
    return output;
}
} // namespace

Result<CompiledShader> compile_shader(const ShaderCompileRequest& request,memory::ResourceHandle resource,std::stop_token cancel)
{
    ComPtr<slang::IGlobalSession> global;
    return compile_shader_impl(request,std::move(resource),global,cancel);
}
Result<Vector<CompiledShader>> compile_shaders(std::span<const ShaderCompileRequest> requests,
    memory::ResourceHandle resource,std::stop_token cancel)
{
    if (!resource || resource.state()!=memory::ResourceState::open)
        return std::unexpected(Error{ErrorCode::invalid_state,"Shader compilation requires an open Memory resource"});
    if (requests.empty()) return std::unexpected(Error{ErrorCode::invalid_argument,"Shader batch must not be empty"});
    Vector<CompiledShader> outputs{memory::Allocator<CompiledShader>{resource}};
    ComPtr<slang::IGlobalSession> global;
    for (const auto& request:requests) {
        auto compiled=compile_shader_impl(request,resource,global,cancel);
        if (!compiled) return std::unexpected(compiled.error());
        outputs.push_back(std::move(*compiled));
    }
    return outputs;
}

String shader_reflection_json(const CompiledShader& shader)
{
    nlohmann::ordered_json json{{"schema_version", 4}, {"compiler", std::string_view{shader.compiler}},
        {"target", "spirv_1_5"}, {"matrix_layout", "row_major"}, {"entry", std::string_view{shader.entry}},
        {"stage", shader_stage_name(shader.stage)}, {"spirv_bytes", shader.spirv.size() * sizeof(std::uint32_t)},
        {"thread_group_size", shader.thread_group_size}, {"bindings", nlohmann::ordered_json::array()},
        {"push_constants", nlohmann::ordered_json::array()}, {"requires_ray_tracing", shader.requires_ray_tracing},
        {"requires_sampled_image_indexing", shader.requires_sampled_image_indexing},
        {"source_fingerprint", shader.source_fingerprint}, {"ray_payloads", nlohmann::ordered_json::array()}, {"ray_traces", nlohmann::ordered_json::array()}};
    for (const auto& payload : shader.ray_interface.payloads)
        json["ray_payloads"].push_back({{"kind", payload.kind == RayInterfaceKind::outgoing_payload ? "outgoing" : payload.kind == RayInterfaceKind::incoming_payload ? "incoming" : "hit_attribute"},
            {"location",payload.location},{"bytes",payload.bytes},{"signature",std::string_view{payload.signature}}});
    for (const auto& trace : shader.ray_interface.traces)
        json["ray_traces"].push_back({{"offset",trace.offset},{"stride",trace.stride},{"miss",trace.miss},{"payload_location",trace.payload_location}});
    for (const auto& binding : shader.bindings) {
        json["bindings"].push_back({{"name", std::string_view{binding.name}}, {"set", binding.set},
            {"binding", binding.binding}, {"type", shader_descriptor_name(binding.type)}, {"count", binding.count},
            {"block_size", binding.block_size}, {"image_shape", shader_image_shape_name(binding.image_shape)}});
    }
    for (const auto& range : shader.push_constants) {
        json["push_constants"].push_back({{"offset", range.offset}, {"size", range.size}});
    }
    return String{json.dump(2) + '\n', memory::Allocator<char>{shader.spirv.get_allocator().resource()}};
}
} // namespace dk::graphics
