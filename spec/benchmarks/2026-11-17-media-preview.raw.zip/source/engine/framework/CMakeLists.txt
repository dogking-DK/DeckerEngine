set(CMAKE_FOLDER "${CMAKE_FOLDER}/Framework")

add_subdirectory(commands)
if(DK_BUILD_SCENE)
    add_subdirectory(services)
    add_subdirectory(operations)
    add_subdirectory(runtime)
endif()
