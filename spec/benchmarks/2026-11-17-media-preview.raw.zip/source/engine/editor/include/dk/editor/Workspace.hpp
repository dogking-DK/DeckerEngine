#pragma once
#include <dk/runtime/Runtime.hpp>
#include <dk/editor/TransformEdit.hpp>
#ifdef _WIN32
#include <dk/automation/IpcServer.hpp>
#endif

namespace dk::editor {
// UI state only; all durable mutations go through Runtime commands on its owner thread.
struct InspectorDraft {
    EditGuard guard;
    EntityData entity;
    bool modified = false;
};
struct EnvironmentDraft { EditGuard guard; Json value; bool modified=false; };
struct SimulationDraft {
    ClothConfig cloth;
    bool gpu = false;
    int target_steps = 1000000, batch_steps = 8;
    std::int64_t fixed_dt_ns = 10000000;
};
enum class SimulationControl { pause, resume, step, cancel, stop };
struct SimulationExportReceipt {
    SimulationId run_id;
    std::uint64_t steps = 0;
    std::int64_t simulated_time_ns = 0;
    std::string output;
};
struct ConsoleReferenceVersion {
    DocumentId document_id;
    std::uint64_t revision = 0;
    AssetCatalogReadVersion assets;
    std::uint64_t publication = 0;
    bool operator==(const ConsoleReferenceVersion&) const = default;
};
struct ConsoleReferenceRecord { std::string id, name, kind; };
struct ConsoleReferencePage {
    ConsoleReferenceVersion version;
    std::vector<ConsoleReferenceRecord> records;
    std::size_t offset = 0, total = 0;
    bool has_more = false;
};
class Workspace final {
public:
    ~Workspace();
    [[nodiscard]] static Result<std::unique_ptr<Workspace>> create(const std::filesystem::path& root);
    [[nodiscard]] Result<void> attach_editor_viewport(EditorViewportCapabilities,bool fixture=false);
    void detach_editor_viewport();
    [[nodiscard]] const std::shared_ptr<EditorViewportService>& editor_viewport() const { return editor_viewport_; }
    void viewport_interacting(bool value,bool gizmo=false) { viewport_interacting_=value; viewport_gizmo_=gizmo; }
    void camera_draft(bool value) { camera_draft_=value; camera_draft_document_=snapshot_ ? snapshot_->state.document_id : DocumentId{}; }
    [[nodiscard]] Result<void> open(const std::filesystem::path& manifest, bool discard = false);
    [[nodiscard]] Result<void> refresh();
    // method key=value or JSON {method,params}; explicit guards and shared registry.
    [[nodiscard]] Result<Json> execute_console(std::string_view);
    // Owning metadata snapshot; does not execute commands, refresh or edit drafts.
    [[nodiscard]] CommandCatalogVersion command_catalog_version() const { return runtime_->command_catalog_version(); }
    [[nodiscard]] CommandCatalogSnapshot command_catalog() const { return runtime_->command_catalog(); }
    [[nodiscard]] ConsoleReferenceVersion console_reference_version() const;
    [[nodiscard]] Result<ConsoleReferencePage> read_console_references(std::string_view provider,
        const ConsoleReferenceVersion&, std::size_t offset, std::size_t limit = 128) const;
    [[nodiscard]] Result<void> select(std::optional<EntityId> id);
    [[nodiscard]] Result<void> apply();
    [[nodiscard]] Result<void> revert();
    [[nodiscard]] Result<void> preset_environment(std::string_view name);
    [[nodiscard]] Result<void> apply_environment();
    [[nodiscard]] Result<void> revert_environment();
    [[nodiscard]] EnvironmentDraft* environment_draft() { return environment_ ? &*environment_ : nullptr; }
    [[nodiscard]] const EnvironmentDraft* environment_draft() const { return environment_ ? &*environment_ : nullptr; }
    [[nodiscard]] Result<void> save();
    [[nodiscard]] Result<void> undo();
    [[nodiscard]] Result<void> redo();
    [[nodiscard]] Result<TransformEdit> begin_transform() const;
    [[nodiscard]] Result<void> commit_transform(const TransformEdit&);
    void pump();
    [[nodiscard]] Result<void> set_simulation_gpu_device(std::shared_ptr<const graphics::Device> device) {
        return runtime_->set_simulation_gpu_device(std::move(device));
    }
    [[nodiscard]] Result<void> request_shutdown();
    [[nodiscard]] SimulationState simulation_state() const { return runtime_->simulation_state(); }
#ifdef DK_SIMULATION_GPU
    [[nodiscard]] Result<void> request_simulation_preview(SimulationId id,const SimulationView& view) { return runtime_->request_simulation_preview(id,view); }
    [[nodiscard]] Result<std::shared_ptr<SimulationPreview>> take_simulation_preview(SimulationId id) { return runtime_->take_simulation_preview(id); }
#endif
    [[nodiscard]] static bool gpu_simulation_available();
    [[nodiscard]] SimulationDraft& simulation_draft() { return simulation_draft_; }
    [[nodiscard]] Result<void> start_simulation(bool paused = false);
    [[nodiscard]] Result<void> control_simulation(SimulationId observed_run, SimulationControl);
    [[nodiscard]] Result<void> sample_simulation(SimulationId observed_run, std::uint64_t observed_steps);
    [[nodiscard]] Result<void> export_simulation(SimulationId observed_run, std::uint64_t observed_steps,
        std::string_view output, int width = 640, int height = 480);
    [[nodiscard]] const std::optional<SimulationExportReceipt>& simulation_export() const { return simulation_export_; }
    [[nodiscard]] const std::string& simulation_export_error() const { return simulation_export_error_; }
    [[nodiscard]] bool stopping() const { return runtime_->stopping(); }
#ifdef _WIN32
    [[nodiscard]] Result<void> start_ipc(std::string_view name);
    void close_ipc();
#endif
    [[nodiscard]] const SceneReadSnapshot* snapshot() const { return snapshot_ ? &*snapshot_ : nullptr; }
    [[nodiscard]] const std::filesystem::path& manifest() const { return manifest_; }
    [[nodiscard]] InspectorDraft* draft() { return draft_ ? &*draft_ : nullptr; }
    [[nodiscard]] const InspectorDraft* draft() const { return draft_ ? &*draft_ : nullptr; }
    [[nodiscard]] bool pending() const { return (draft_ && draft_->modified) || (environment_ && environment_->modified); }
    [[nodiscard]] bool dirty() const { return pending() || (snapshot_ && snapshot_->state.dirty); }
    [[nodiscard]] std::optional<EntityId> selection() const { return selection_; }
    [[nodiscard]] HistoryStatus history() const { return history_; }
private:
    explicit Workspace(std::unique_ptr<Runtime> runtime) : runtime_(std::move(runtime)) {}
    [[nodiscard]] Result<Json> call(std::string_view method, Json parameters = Json::object());
    [[nodiscard]] Result<void> history_step(std::string_view method);
    [[nodiscard]] Json guard() const;
    std::unique_ptr<Runtime> runtime_;
    std::shared_ptr<EditorViewportService> editor_viewport_;
    bool viewport_interacting_=false,viewport_gizmo_=false,camera_draft_=false;
    DocumentId camera_draft_document_;
    std::optional<SceneReadSnapshot> snapshot_;
    std::uint64_t snapshot_publication_ = 0;
    std::optional<EntityId> selection_;
    std::optional<InspectorDraft> draft_;
    std::optional<EnvironmentDraft> environment_;
    std::filesystem::path manifest_;
    HistoryStatus history_{};
    SimulationDraft simulation_draft_;
    std::optional<SimulationExportReceipt> simulation_export_;
    std::string simulation_export_error_;
#ifdef _WIN32
    std::unique_ptr<IpcServer> ipc_;
#endif
};
} // namespace dk::editor
