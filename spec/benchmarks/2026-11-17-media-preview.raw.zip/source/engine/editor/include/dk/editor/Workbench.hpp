#pragma once
#include <filesystem>
#include <string>

namespace dk::editor {
struct WorkbenchOptions {
    std::filesystem::path root;
    std::string pipe;
    std::filesystem::path manifest = "project.json";
    bool validation = false;
    bool disable_validation = false;
    bool background = false;
    // Bounded native UI acceptance run. Caller must supply a disposable project.
    bool smoke = false;
    bool pathtrace_smoke = false;
    bool viewport_command_smoke = false;
    bool voxel_workflow_smoke = false;
    bool voxel_path_smoke = false;
    bool voxel_path_no_rt = false;
    bool camera_command_smoke = false;
    bool settings_help_smoke = false;
    bool console_workflow_smoke = false;
    bool media_pathtrace_smoke = false;
    bool restir_pathtrace_smoke = false;
    bool desktop_render_smoke = false;
    bool media_motion_probe = false;
    bool interaction_smoke = false;
    bool simulation_smoke = false;
    bool consistency_smoke = false;
    bool environment_consistency_smoke = false;
    bool simulation_consistency_smoke = false;
    bool simulation_response_probe = false;
    unsigned frames = 0;
    std::filesystem::path screenshot;
    bool fixture_camera = false;
};
// Main-thread window loop. Returns 77 only for an unavailable Vulkan/WSI baseline.
int run_workbench(const WorkbenchOptions&);
} // namespace dk::editor
