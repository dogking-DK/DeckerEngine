#pragma once
#include "Viewport.hpp"
#include "ViewportInput.hpp"
#include "ConsoleInput.hpp"
#include "SettingsHelpUi.hpp"
#include <map>
#include <array>

namespace dk::editor::detail {
enum class PendingAction { none, open, close };
class WorkbenchUi final {
public:
    explicit WorkbenchUi(Workspace& model,bool fixture,SDL_Window*,unsigned acceptance_path_extent=0);
    void draw(Viewport&,bool srgb);
    void request_close();
#ifdef DK_EDITOR_PATHTRACING
    [[nodiscard]] const PathPreviewSettings& path_settings() const { return model_.editor_viewport()->settings().path; }
    [[nodiscard]] bool path_mode() const { return model_.editor_viewport()->settings().path_trace; }
#endif
    void cancel_interaction() { input_.cancel(); simulation_navigation_.cancel(); model_.viewport_interacting(false); }
    bool event(const SDL_Event&);
    [[nodiscard]] bool simulation_navigating() const { return simulation_navigation_.active(); }
    [[nodiscard]] bool closing() const { return closing_; }
    [[nodiscard]] const std::map<std::string,ImVec2>& controls() const { return controls_; }
    [[nodiscard]] unsigned errors() const { return errors_; }
    [[nodiscard]] const ConsoleInput& console_input() const { return console_input_; }
    [[nodiscard]] const ViewportInput& input() const { return input_; }
    [[nodiscard]] const SimulationState& displayed_simulation() const { return displayed_simulation_; }
    [[nodiscard]] const Camera& simulation_camera() const { return simulation_camera_; }
    [[nodiscard]] const SettingsHelpUi& settings_help() const { return settings_help_; }
private:
    void mark(const char* id);
    bool report(const char*,Result<void>);
    void request(PendingAction);
    void perform();
    void toolbar();
    void view_settings(Viewport&);
    void hierarchy();
    void inspector();
    void assets();
    void environment(const Viewport&);
    bool viewport_settings_changed(const EditorViewportSettings&);
    void viewport_action(EditorViewportControl);
    void observe_viewport(const Viewport&,bool visible);
#ifdef DK_EDITOR_PATHTRACING
    void path_panel(Viewport&);

#endif
    void console();
    void prepare_help(const Viewport&);
    void settings_search();
    void help(std::string_view id,std::string_view reason={}) { settings_help_.item(id,reason); }
    void simulation();
    void simulation_results(const SimulationRunState*);
    bool simulation_view(Viewport&,bool visible);
    void frame_simulation(const ClothConfig&,double aspect);
    void simulation_navigation();
    void confirmation();
    Workspace& model_;
    RelativeMouse relative_mouse_;
    ViewportInput input_;
    std::string manifest_;
    ConsoleInput console_input_;
    SettingsHelpUi settings_help_;
    std::optional<CommandCatalogSnapshot> console_catalog_;
    DocumentId console_document_;
    std::uint32_t window_id_ = 0;
    bool console_composing_ = false;
    std::map<std::string,ImVec2> controls_;
    std::vector<std::string> log_;
    std::string viewport_error_,environment_error_;
    std::optional<EntityId> inspected_entity_;
    VoxelDisplaySettings voxel_draft_;
    std::optional<EditorViewportGuard> voxel_draft_guard_;
    std::string simulation_error_;
    std::string simulation_sample_error_,simulation_output_;
    int simulation_export_width_=640,simulation_export_height_=480;
    std::optional<SimulationId> simulation_panel_run_;
    bool simulation_panel_initialized_=false;
    SimulationState displayed_simulation_{SimulationMode::edit,{}};
    Camera simulation_camera_;
    CameraSettingsUi simulation_settings_ui_;
    double simulation_aspect_=1;
    std::optional<SimulationId> simulation_camera_run_;
    std::optional<ClothConfig> simulation_cloth_;
    bool simulation_visible_=true;
    NavigationUi simulation_navigation_;
    PendingAction pending_ = PendingAction::none;
    bool popup_ = false,closing_ = false,layout_ = false,scroll_log_ = true;
    unsigned errors_ = 0,acceptance_path_extent_=0;
    render::EnvironmentRenderSettings environment_settings_=[] { render::EnvironmentRenderSettings s; s.mode=render::CloudRenderMode::temporal; return s; }();
};
}
