#include "WorkbenchUi.hpp"
#include <SDL3/SDL.h>
#include "EditorSupport.hpp"
#include <imgui_internal.h>
#include <imgui_stdlib.h>
#include <algorithm>
#include <cmath>
#include <unordered_map>

namespace dk::editor::detail {
WorkbenchUi::WorkbenchUi(Workspace& model,bool fixture,SDL_Window* window,unsigned acceptance_path_extent) : model_(model),relative_mouse_(window),input_(model.editor_viewport(),relative_mouse_,fixture),manifest_(take(path_to_utf8(model.manifest()))),simulation_navigation_(relative_mouse_),acceptance_path_extent_(acceptance_path_extent) {
    window_id_ = SDL_GetWindowID(window);
    log_.push_back("Opened "+manifest_);
    log_.push_back("Viewport: CPU picking / local Gizmo / Orbit, Fly and Walk. Edits use guarded commands.");
}
void WorkbenchUi::mark(const char* id) {
    const auto a=ImGui::GetItemRectMin(),b=ImGui::GetItemRectMax();
    controls_[id]={(a.x+b.x)*0.5f,(a.y+b.y)*0.5f};
}
bool WorkbenchUi::report(const char* action,Result<void> result) {
    std::string message=action;
    if (!result) {
        message+=" failed: "+result.error().message;
        for (const auto& context:result.error().context) message+=" / "+context;
        ++errors_;
    }
    else message+=" succeeded";
    if (log_.size()==64) log_.erase(log_.begin());
    log_.push_back(console_log_text(message)); scroll_log_=true;
    return bool(result);
}
void WorkbenchUi::perform() {
    if (pending_==PendingAction::close) closing_=true;
    else if (pending_==PendingAction::open) {
        auto path=path_from_utf8(manifest_);
        if (!path) report("Open",std::unexpected(path.error()));
        else report("Open",model_.open(*path,true));
    }
    pending_=PendingAction::none;
}
void WorkbenchUi::request(PendingAction action) {
    if (pending_!=PendingAction::none) return;
    cancel_interaction();
    pending_=action;
    if (model_.dirty()) popup_=true;
    else perform();
}
bool WorkbenchUi::event(const SDL_Event& event) {
    if (event.type == SDL_EVENT_TEXT_EDITING && event.edit.windowID == window_id_)
        console_composing_ = console_input_.active() && event.edit.text && event.edit.text[0];
    if (event.type == SDL_EVENT_TEXT_INPUT && event.text.windowID == window_id_) console_composing_ = false;
    if (relative_mouse_.belongs(event) && (event.type == SDL_EVENT_WINDOW_FOCUS_LOST || event.type == SDL_EVENT_WINDOW_HIDDEN))
        { console_composing_ = false; console_input_.dismiss(); }
    if (console_composing_ && console_input_.active() && (event.type == SDL_EVENT_KEY_DOWN || event.type == SDL_EVENT_KEY_UP) &&
        event.key.windowID == window_id_ && (event.key.key == SDLK_UP || event.key.key == SDLK_DOWN || event.key.key == SDLK_TAB || event.key.key == SDLK_ESCAPE || event.key.key == SDLK_RETURN || event.key.key == SDLK_KP_ENTER)) return true;
    if(event.type==SDL_EVENT_QUIT || (relative_mouse_.belongs(event) &&
       (event.type==SDL_EVENT_WINDOW_FOCUS_LOST || event.type==SDL_EVENT_WINDOW_MINIMIZED ||
        event.type==SDL_EVENT_WINDOW_HIDDEN || event.type==SDL_EVENT_WINDOW_CLOSE_REQUESTED ||
        event.type==SDL_EVENT_WINDOW_RESIZED || event.type==SDL_EVENT_WINDOW_PIXEL_SIZE_CHANGED ||
        event.type==SDL_EVENT_WINDOW_DISPLAY_SCALE_CHANGED))) cancel_interaction();
    return relative_mouse_.event(event);
}
void WorkbenchUi::request_close() { cancel_interaction(); request(PendingAction::close); }
void WorkbenchUi::toolbar() {
    if (!ImGui::BeginMainMenuBar()) return;
    ImGui::TextUnformatted("DECKER  /  WORKBENCH"); ImGui::Separator();
    ImGui::BeginDisabled(input_.active());
    if (ImGui::Button("Save")) report("Save",model_.save()); mark("save");
    ImGui::SameLine();
    ImGui::SetNextItemWidth(220);
    ImGui::InputText("##manifest",&manifest_); mark("manifest");
    ImGui::SameLine();
    if (ImGui::Button("Open")) request(PendingAction::open); mark("open");
    ImGui::SameLine();
    if (ImGui::Button("Reload")) { manifest_=take(path_to_utf8(model_.manifest())); request(PendingAction::open); } mark("reload");
    ImGui::Separator();
    if(ImGui::Button("Environment")) ImGui::SetWindowFocus("Environment"); mark("environment_open");
    ImGui::SameLine(); if(ImGui::Button("Settings")) settings_help_.open(); mark("settings_open");
    ImGui::Separator();
    const auto history=model_.history();
    ImGui::BeginDisabled(model_.pending() || !history.undo_count);
    if (ImGui::Button("Undo")) report("Undo",model_.undo()); mark("undo");
    ImGui::EndDisabled(); ImGui::SameLine();
    ImGui::BeginDisabled(model_.pending() || !history.redo_count);
    if (ImGui::Button("Redo")) report("Redo",model_.redo()); mark("redo");
    ImGui::EndDisabled(); ImGui::Separator();
    if (const auto* s=model_.snapshot()) ImGui::Text("rev %llu  |  %s",
        static_cast<unsigned long long>(s->state.revision),model_.dirty() ? "Unsaved changes" : "Saved");
    ImGui::EndDisabled(); ImGui::EndMainMenuBar();
}
void WorkbenchUi::hierarchy() {
    ImGui::Begin("Hierarchy");
    const auto* snapshot=model_.snapshot();
    if (snapshot) {
        ImGui::Text("%zu entities",snapshot->state.entity_count);
        ImGui::Separator();
        if (model_.pending()) ImGui::TextWrapped("Apply or Revert the pending draft before changing selection.");
        using Row=std::pair<const EntityData*,unsigned>;
        std::unordered_map<EntityId,std::vector<const EntityData*>> children;
        for (const auto& e : snapshot->scene.entities()) children[e.parent.value_or(EntityId{})].push_back(&e);
        std::vector<Row> stack,rows;
        const auto append=[&](EntityId parent,unsigned depth) {
            for (auto i=children[parent].rbegin();i!=children[parent].rend();++i) stack.emplace_back(*i,depth);
        };
        append({},0);
        while (!stack.empty()) {
            auto row=stack.back(); stack.pop_back(); rows.push_back(row); append(row.first->id,row.second+1);
        }
        ImGui::BeginDisabled(model_.pending() || input_.active());
        ImGuiListClipper clipper;
        clipper.Begin(static_cast<int>(rows.size()));
        while (clipper.Step()) for (int i=clipper.DisplayStart;i<clipper.DisplayEnd;++i) {
            const auto& [e,depth]=rows[static_cast<std::size_t>(i)];
            ImGui::PushID(e->id.to_string().c_str());
            const float indent=static_cast<float>(std::min(depth,8u))*12;
            if (indent>0) ImGui::Indent(indent);
            const auto label=(children[e->id].empty() ? "  " : "> ")+(e->name.empty() ? "(unnamed)" : e->name);
            if (ImGui::Selectable(label.c_str(),model_.selection()==e->id)) report("Select",model_.select(e->id));
            if (i==0) mark("entity");
            if (ImGui::IsItemHovered()) ImGui::SetTooltip("%s\n%s",e->name.c_str(),e->id.to_string().c_str());
            if (indent>0) ImGui::Unindent(indent);
            ImGui::PopID();
        }
        ImGui::EndDisabled();
    }
    ImGui::End();
}
void WorkbenchUi::inspector() {
    settings_help_.panel("Inspector"); ImGui::Begin("Inspector");
    auto* draft=model_.draft();
    const auto inspected=draft ? std::optional{draft->entity.id} : std::nullopt;
    if(inspected!=inspected_entity_) { ImGui::SetScrollY(0); inspected_entity_=inspected; }
    if (!draft) { ImGui::TextWrapped("Select an entity in Hierarchy to inspect or edit it."); settings_help_.unavailable_panel("Inspector"); ImGui::End(); return; }
    ImGui::TextUnformatted("ENTITY"); ImGui::TextWrapped("%s",draft->entity.id.to_string().c_str());
    ImGui::Separator();
    ImGui::BeginDisabled(input_.active() || (model_.environment_draft() && model_.environment_draft()->modified));
    ImGui::BeginDisabled(!model_.pending());
    if (ImGui::Button("Apply")) report("Apply",model_.apply()); mark("apply"); help("inspector.apply");
    ImGui::SameLine();
    if (ImGui::Button("Revert")) report("Revert",model_.revert()); mark("revert"); help("inspector.revert");
    ImGui::EndDisabled();
    draft=model_.draft();
    if(!draft) { ImGui::EndDisabled(); ImGui::End(); return; }
    bool modified=false;
    ImGui::SetNextItemWidth(-1);
    modified|=ImGui::InputText("##Name",&draft->entity.name); mark("name"); help("inspector.name");
    ImGui::TextDisabled("Name");
    ImGui::Spacing(); ImGui::TextUnformatted("LOCAL TRANSFORM");
    ImGui::SetNextItemWidth(-1);
    modified|=ImGui::InputScalarN("##Translation",ImGuiDataType_Double,draft->entity.local.translation.data(),3,nullptr,nullptr,"%.4f"); mark("translation"); help("inspector.translation");
    const auto translation_min=ImGui::GetItemRectMin(),translation_max=ImGui::GetItemRectMax();
    controls_["translation"]={translation_min.x+(translation_max.x-translation_min.x)/6,(translation_min.y+translation_max.y)*0.5f};
    ImGui::TextDisabled("Translation  X / Y / Z");
    ImGui::SetNextItemWidth(-1);
    modified|=ImGui::InputScalarN("##Rotation",ImGuiDataType_Double,draft->entity.local.rotation.coeffs().data(),4,nullptr,nullptr,"%.4f"); help("inspector.rotation");
    ImGui::TextDisabled("Quaternion  X / Y / Z / W");
    ImGui::SetNextItemWidth(-1);
    modified|=ImGui::InputScalarN("##Scale",ImGuiDataType_Double,draft->entity.local.scale.data(),3,nullptr,nullptr,"%.4f"); help("inspector.scale");
    ImGui::TextDisabled("Scale  X / Y / Z");
    draft->modified|=modified;
    ImGui::Spacing();
    ImGui::EndDisabled();
    // Commands may replace the draft; reacquire before displaying it.
    draft=model_.draft();
    if (draft && draft->modified) ImGui::TextWrapped("Draft not applied. Save also applies this draft.");
    if (draft) {
        ImGui::Separator(); ImGui::TextUnformatted("REFERENCES");
        if (draft->entity.parent) ImGui::TextWrapped("Parent: %s",draft->entity.parent->to_string().c_str());
        else ImGui::TextDisabled("Root entity");
        for (const auto& a : draft->entity.assets) {
            ImGui::TextUnformatted(asset_kind_name(a.kind).data()); ImGui::TextWrapped("%s",a.id.to_string().c_str());
        }
    }
    ImGui::End();
}
void WorkbenchUi::assets() {
    ImGui::Begin("Assets");
    if (const auto* s=model_.snapshot()) {
        ImGui::TextWrapped("%s  /  %zu mapped assets",s->project.description().name.c_str(),s->project.description().assets.size());
        if (ImGui::BeginTable("assets",2,ImGuiTableFlags_RowBg|ImGuiTableFlags_BordersInnerH|ImGuiTableFlags_Resizable)) {
            ImGui::TableSetupColumn("Kind",ImGuiTableColumnFlags_WidthFixed,80); ImGui::TableSetupColumn("Project path");
            ImGui::TableHeadersRow();
            for (const auto& a:s->project.description().assets) {
                ImGui::TableNextRow(); ImGui::TableNextColumn(); ImGui::TextUnformatted(asset_kind_name(a.kind).data());
                ImGui::TableNextColumn(); ImGui::TextUnformatted(a.path.c_str());
                if (ImGui::IsItemHovered()) ImGui::SetTooltip("%s",a.id.to_string().c_str());
            }
            ImGui::EndTable();
        }
    }
    ImGui::End();
}
void WorkbenchUi::console() {
    settings_help_.panel("Console"); ImGui::Begin("Console");
    ImGui::BeginChild("Command log",{0,-ImGui::GetFrameHeightWithSpacing()},false,ImGuiWindowFlags_HorizontalScrollbar);
    for (const auto& line:log_) ImGui::TextWrapped("%s",line.c_str());
    if (scroll_log_) { ImGui::SetScrollHereY(1.0f); scroll_log_=false; }
    ImGui::EndChild();
    ImGui::SetNextItemWidth(-55);
    if (!console_catalog_ || console_catalog_->version!=model_.command_catalog_version()) console_catalog_=model_.command_catalog();
    const auto document=model_.snapshot() ? model_.snapshot()->state.document_id : DocumentId{};
    if (document!=console_document_) { console_document_=document; console_input_.dismiss(); }
    const bool enter=console_input_.draw(console_composing_,*console_catalog_,model_); mark("console_input"); help("console.input");
    ImGui::SameLine(); ImGui::BeginDisabled(console_composing_);
    const bool run=ImGui::Button("Run"); mark("console_run"); help("console.run"); ImGui::EndDisabled();
    if (auto error = console_input_.take_error(); !error.empty()) report("Console input",std::unexpected(Error{ErrorCode::invalid_argument,std::move(error)}));
    if((enter || run) && !console_composing_ && !console_input_.rejected() && !console_input_.accepted()) {
        console_input_.dismiss();
        if (console_input_.text().find_first_not_of(" \t") == std::string_view::npos) { ImGui::End(); return; }
        console_input_.remember();
        if(log_.size()==64) log_.erase(log_.begin());
        log_.push_back(console_log_text("> " + std::string{console_input_.text()})); scroll_log_=true;
        auto result=model_.execute_console(console_input_.text());
        if(result) {
            auto text=(result->is_object() && result->contains("job_id") ? "Accepted: " : "Succeeded: ") + result->dump();
            if(log_.size()==64) log_.erase(log_.begin());
            log_.push_back(console_log_text(text)); scroll_log_=true;
            console_input_.clear();
        } else report("Command",std::unexpected(result.error()));
        console_input_.focus();
    }
    if (!console_input_.active()) console_composing_=false;
    console_input_.draw_assistance();
    ImGui::End();
}
void WorkbenchUi::confirmation() {
    if (popup_) { ImGui::OpenPopup("Unsaved changes"); popup_=false; }
    ImGui::SetNextWindowPos(ImGui::GetMainViewport()->GetCenter(),ImGuiCond_Appearing,{0.5f,0.5f});
    if (ImGui::BeginPopupModal("Unsaved changes",nullptr,ImGuiWindowFlags_AlwaysAutoResize)) {
        ImGui::TextUnformatted("The scene or an editing draft has unsaved changes.");
        ImGui::TextUnformatted("Save before continuing?");
        if (ImGui::Button("Save and continue") && report("Save",model_.save())) { perform(); ImGui::CloseCurrentPopup(); } mark("confirm_save");
        ImGui::SameLine();
        if (ImGui::Button("Discard")) { perform(); ImGui::CloseCurrentPopup(); } mark("discard");
        ImGui::SameLine();
        if (ImGui::Button("Cancel")) { pending_=PendingAction::none; ImGui::CloseCurrentPopup(); } mark("cancel");
        ImGui::EndPopup();
    }
}
void WorkbenchUi::view_settings(Viewport& preview) {
    settings_help_.panel("View settings");
    if(ImGui::Begin("View settings")) {
    ImGui::SeparatorText("Rendering");
    auto viewport_settings=model_.editor_viewport()->settings();
#ifdef DK_EDITOR_PATHTRACING
    ImGui::BeginDisabled(model_.pending() || input_.active() || input_.navigating());
    if(ImGui::RadioButton("Raster",!path_mode())) { viewport_settings.path_trace=false; if(viewport_settings_changed(viewport_settings)) preview.suspend_path(); } mark("path_raster"); help("viewport.renderer"); ImGui::SameLine();
    ImGui::BeginDisabled(!preview.path_unavailable().empty());
    if(ImGui::RadioButton("Path trace",path_mode())) { viewport_settings.path_trace=true; if(viewport_settings_changed(viewport_settings)) ImGui::SetWindowFocus("Path tracing"); } mark("path_mode"); help("viewport.renderer",preview.path_unavailable());
    ImGui::EndDisabled();
    ImGui::EndDisabled();
    ImGui::SameLine(); if(ImGui::SmallButton("Settings")) ImGui::SetWindowFocus("Path tracing"); mark("path_settings");
#else
    ImGui::TextWrapped("Path trace unavailable (module disabled)"); help("viewport.renderer","Path tracing module is unavailable.");
#endif
    ImGui::BeginDisabled(input_.active());
    if (ImGui::SmallButton("Refresh")) preview.retry(); mark("path_refresh");
    ImGui::EndDisabled();
    if(ImGui::GetItemRectMax().x+ImGui::CalcTextSize("Unlit inspection").x+50<ImGui::GetWindowPos().x+ImGui::GetWindowContentRegionMax().x)
        ImGui::SameLine();
    bool path_projection=false;
#ifdef DK_EDITOR_PATHTRACING
    path_projection=path_mode();
#endif
    ImGui::BeginDisabled(model_.pending() || input_.active() || input_.navigating() || path_projection);
    if(ImGui::Checkbox("Unlit inspection",&viewport_settings.unlit_inspection)) viewport_settings_changed(viewport_settings);
    mark("unlit_inspection"); help("viewport.unlit_inspection"); ImGui::EndDisabled();
    ImGui::BeginDisabled(model_.pending() || input_.active() || input_.navigating() || path_projection);
    const auto open_voxel=[&] {
        const auto state=model_.editor_viewport()->query();
        if(!state) { report("Voxel settings",std::unexpected(state.error())); return; }
        voxel_draft_=state->settings.voxel; voxel_draft_guard_=state->guard; ImGui::OpenPopup("Voxel display");
    };
    if(settings_help_.reveal("View settings","Voxel") && !ImGui::IsPopupOpen("Voxel display")) open_voxel();
    if(ImGui::SmallButton("Voxel settings")) open_voxel(); mark("voxel_settings");
    if(ImGui::BeginPopup("Voxel display")) {
        ImGui::Checkbox("Directional light",&voxel_draft_.directional);
        mark("voxel_directional"); help("viewport.voxel_shading");
        ImGui::InputScalarN("Light direction",ImGuiDataType_Double,voxel_draft_.light_direction.data(),3,nullptr,nullptr,"%.6f");
        help("viewport.voxel_light_direction");
        ImGui::InputScalarN("Irradiance",ImGuiDataType_Double,voxel_draft_.irradiance.data(),3,nullptr,nullptr,"%.4f");
        help("viewport.voxel_irradiance");
        if(ImGui::Button("Apply") && voxel_draft_guard_) {
            auto candidate=model_.editor_viewport()->settings(); candidate.voxel=voxel_draft_;
            const auto applied=model_.editor_viewport()->set(*voxel_draft_guard_,candidate);
            report("Voxel settings",applied ? Result<void>{} : std::unexpected(applied.error()));
            if(applied) { voxel_draft_guard_=applied->guard; viewport_settings=applied->settings; }
        }
        mark("voxel_apply"); ImGui::SameLine();
        if(ImGui::Button("Cancel")) ImGui::CloseCurrentPopup();
        mark("voxel_cancel"); ImGui::EndPopup();
    }
    ImGui::EndDisabled();
    ImGui::SeparatorText("Camera and navigation");
    input_.toolbar(model_,preview,controls_,[&](const char* action,Result<void> result) { return report(action,std::move(result)); },&settings_help_);
    }
    ImGui::End();
}
void WorkbenchUi::draw(Viewport& preview,bool srgb) {
    input_.begin_frame(); simulation_navigation_.begin_frame();
    controls_.clear();
    if (ImGui::GetIO().AppFocusLost || ImGui::IsKeyPressed(ImGuiKey_Escape,false)) cancel_interaction();
    if (input_.edit() && (!model_.snapshot() || input_.edit()->guard.document_id!=model_.snapshot()->state.document_id ||
        input_.edit()->guard.revision!=model_.snapshot()->state.revision)) input_.cancel();
    model_.viewport_interacting(input_.active() || input_.navigating(),input_.active());
    prepare_help(preview); toolbar();
    const auto dock=ImGui::DockSpaceOverViewport(0,ImGui::GetMainViewport());
    if (!layout_) {
        ImGui::DockBuilderRemoveNode(dock);
        ImGui::DockBuilderAddNode(dock,ImGuiDockNodeFlags_DockSpace);
        ImGui::DockBuilderSetNodeSize(dock,ImGui::GetMainViewport()->WorkSize);
        auto center=dock;
        // Bound sidebars in font units so a maximized start can later restore
        // to a smaller window without leaving the central viewport squeezed.
        const auto width=ImGui::GetMainViewport()->WorkSize.x;
        const auto left_fraction=std::min(0.24f,18*ImGui::GetFontSize()/width);
        const auto right_fraction=std::min(0.34f,20*ImGui::GetFontSize()/(width*(1-left_fraction)));
        auto left=ImGui::DockBuilderSplitNode(center,ImGuiDir_Left,left_fraction,nullptr,&center);
        const auto simulation=ImGui::DockBuilderSplitNode(left,ImGuiDir_Down,0.65f,nullptr,&left);
        auto right=ImGui::DockBuilderSplitNode(center,ImGuiDir_Right,right_fraction,nullptr,&center);
        const auto view_settings=ImGui::DockBuilderSplitNode(right,ImGuiDir_Up,0.50f,nullptr,&right);
        ImGui::DockBuilderDockWindow("View settings",view_settings);
        auto bottom=ImGui::DockBuilderSplitNode(center,ImGuiDir_Down,0.26f,nullptr,&center);
        const auto log=ImGui::DockBuilderSplitNode(bottom,ImGuiDir_Right,0.48f,nullptr,&bottom);
        ImGui::DockBuilderDockWindow("Hierarchy",left); ImGui::DockBuilderDockWindow("Inspector",right);
        ImGui::DockBuilderDockWindow("Simulation",simulation);
        ImGui::DockBuilderDockWindow("Environment",right);
#ifdef DK_EDITOR_PATHTRACING
        ImGui::DockBuilderDockWindow("Path tracing",right);
#endif
        ImGui::DockBuilderDockWindow("Viewport",center); ImGui::DockBuilderDockWindow("Assets",bottom);
        ImGui::DockBuilderDockWindow("Console",log); ImGui::DockBuilderFinish(dock);
        ImGui::SetWindowFocus("Inspector");
        layout_=true;
    }
    hierarchy(); inspector(); environment(preview);
#ifdef DK_EDITOR_PATHTRACING
    path_panel(preview);
#else
    if(settings_help_.reveal("Path tracing","") || settings_help_.located().starts_with("path.")) {
        settings_help_.panel("Path tracing"); ImGui::Begin("Path tracing"); settings_help_.unavailable_panel("Path tracing"); ImGui::End();
    }
#endif
    settings_help_.panel("Viewport");
    const bool visible=ImGui::Begin("Viewport",nullptr,ImGuiWindowFlags_NoScrollWithMouse|ImGuiWindowFlags_NoScrollbar);
    if (!visible) { input_.cancel(); model_.camera_draft(false); preview.suspend_path(); }
    const bool simulation_displayed=simulation_view(preview,visible);
    if(simulation_displayed) { model_.camera_draft(false); settings_help_.unavailable_panel("Viewport"); }
    if (!simulation_displayed) {
    preview.show_edit();
    view_settings(preview);
    const auto viewport_settings=model_.editor_viewport()->settings();
    if (const auto* s=model_.snapshot(); s && visible) {
        if (preview.texture()) {
#ifdef DK_EDITOR_PATHTRACING
            if(path_mode()) ImGui::Text("rev %llu  /  %s",static_cast<unsigned long long>(preview.info().revision),
                preview.current(s->state) ? "Current scene" : "STALE PREVIEW");
            else
#endif
            ImGui::Text("rev %llu  /  %zu draws  /  %s",static_cast<unsigned long long>(preview.info().revision),preview.info().draw_count,
                preview.current(s->state) ? "Current scene" : "STALE PREVIEW");
            ImGui::SameLine(); ImGui::TextDisabled("%u x %u",preview.info().width,preview.info().height);
        } else ImGui::TextUnformatted("Preparing scene...");
        if(preview.texture() && !viewport_settings.unlit_inspection && (s->scene.environment().enabled || s->scene.environment().clouds.enabled)
#ifdef DK_EDITOR_PATHTRACING
            && !path_mode()
#endif
        ) {
            const auto& used=preview.environment_settings();
            ImGui::Text("t %.3f / %s / warmup %u / history %s / shadow %llu",used.time_seconds,
                used.mode==render::CloudRenderMode::temporal ? "temporal" : "reference",preview.environment_warmup(),
                render::cloud_history_reset_name(preview.environment_history().reset),static_cast<unsigned long long>(preview.environment_shadow()));
        }
        const auto available=ImGui::GetContentRegionAvail();
        if (available.x>=32 && available.y>=32) {
            auto width=static_cast<std::uint32_t>(std::clamp(available.x,32.0f,1600.0f));
            auto height=static_cast<std::uint32_t>(std::clamp(available.y,32.0f,1200.0f));
#ifdef DK_EDITOR_PATHTRACING
            if(path_mode()) { width=static_cast<std::uint32_t>(available.x); height=static_cast<std::uint32_t>(available.y); }
#endif
#ifdef DK_DISK_VOXELS
            const bool has_voxels=std::ranges::any_of(s->scene.entities(),[](const auto& entity) {
                return std::ranges::any_of(entity.assets,[](const auto& asset) { return asset.kind==AssetKind::voxel; });
            });
            // Keep the interactive voxel preview within its measured GPU budget;
            // the image is fitted to the panel independently of its extent.
            constexpr std::uint64_t voxel_preview_pixels=512u*1024u;
            if(has_voxels && std::uint64_t(width)*height>voxel_preview_pixels
#ifdef DK_EDITOR_PATHTRACING
                && !path_mode()
#endif
            ) {
                const auto scale=std::sqrt(double(voxel_preview_pixels)/(double(width)*height));
                width=static_cast<std::uint32_t>(std::floor(width*scale));
                height=static_cast<std::uint32_t>(std::floor(height*scale));
            }
#endif
            input_.aspect(double(width)/height);
            // Navigation revision identifies the request, not a temporal camera cut.
            // The pipeline separately rejects projection changes and large pose jumps.
#ifdef DK_EDITOR_PATHTRACING
            if(path_mode()) preview.update_path(*s,acceptance_path_extent_ ? std::min(width,acceptance_path_extent_) : width,acceptance_path_extent_ ? std::min(height,acceptance_path_extent_) : height,srgb,input_.camera(),input_.edit(),input_.revision(),path_settings());
            else
#endif
            preview.update(*s,width,height,srgb,input_.camera(),input_.edit(),input_.revision(),float(viewport_settings.raster_exposure),environment_settings_,viewport_settings.unlit_inspection,viewport_settings.voxel);
            if (preview.texture()) {
                const auto& info=preview.info();
                const float scale=std::min(available.x/static_cast<float>(info.width),available.y/static_cast<float>(info.height));
                ImGui::Image(preview.texture(),{static_cast<float>(info.width)*scale,static_cast<float>(info.height)*scale});
                input_.image(model_,preview,controls_,[&](const char* action,Result<void> result) { return report(action,std::move(result)); });
            } else ImGui::TextWrapped("Preview unavailable. See Console and press Refresh to retry.");
        } else { input_.cancel(); preview.suspend_path(); }
        if (preview.error()!=viewport_error_) {
            viewport_error_=preview.error();
            if (!viewport_error_.empty()) report("Viewport",std::unexpected(Error{ErrorCode::internal_error,viewport_error_}));
        }
    }
    }
    ImGui::End();
    model_.viewport_interacting(input_.active() || input_.navigating(),input_.active());
    observe_viewport(preview,visible && !preview.simulation_run());
    assets(); console(); simulation(); confirmation(); settings_search();
    input_.end_frame(); simulation_navigation_.end_frame();
}
}
