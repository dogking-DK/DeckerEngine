#include <dk/editor/Workbench.hpp>
#include "WorkbenchUi.hpp"
#include "GuiRenderer.hpp"
#include "SmokeDriver.hpp"
#include "SettingsHelpSmoke.hpp"
#include "ConsistencyDriver.hpp"
#include "SimulationConsistencyDriver.hpp"
#include "ResponseProbe.hpp"
#ifdef DK_DISK_VOXELS
#include "VoxelWorkflowSmoke.hpp"
#ifdef DK_EDITOR_PATHTRACING
#include "VoxelPathSmoke.hpp"
#endif
#endif
#ifdef DK_EDITOR_PATHTRACING
#include "PathSmoke.hpp"
#include "MediaMotionProbe.hpp"
#include "ViewportCommandSmoke.hpp"
#include "CameraCommandSmoke.hpp"
#include "ConsoleWorkflowSmoke.hpp"
#endif
#include "EditorSupport.hpp"
#include <dk/memory/MemorySystem.hpp>
#include <dk/memory/Context.hpp>
#include <dk/graphics/Transfer.hpp>
#include <dk/io/File.hpp>
#include <imgui_impl_sdl3.h>
#include <SDL3/SDL.h>
#include <atomic>
#include <algorithm>
#include <chrono>
#include <cstdio>

namespace dk::editor {
namespace {
using namespace detail;
struct Diagnostics { std::atomic<unsigned> errors=0,warnings=0,known_loader_warnings=0; };
void diagnostic(void* user,const graphics::Diagnostic& message) noexcept {
    auto& d=*static_cast<Diagnostics*>(user);
    if (message.severity==VK_DEBUG_UTILS_MESSAGE_SEVERITY_ERROR_BIT_EXT) ++d.errors;
    if (message.severity==VK_DEBUG_UTILS_MESSAGE_SEVERITY_WARNING_BIT_EXT) ++d.warnings;
    if (message.severity==VK_DEBUG_UTILS_MESSAGE_SEVERITY_WARNING_BIT_EXT && message.name=="Loader Message" &&
        message.message=="Layer VK_LAYER_AMD_switchable_graphics uses API version 1.3 which is older than the application specified API version of 1.4. May cause issues.")
        ++d.known_loader_warnings;
    if (message.severity>=VK_DEBUG_UTILS_MESSAGE_SEVERITY_WARNING_BIT_EXT)
        std::fprintf(stderr,"%.*s: %.*s\n",static_cast<int>(message.name.size()),message.name.data(),static_cast<int>(message.message.size()),message.message.data());
}
void event_sink(const SDL_Event& event,void* user) {
    // Release on native cancellation before a minimized loop can skip NewFrame.
    if(!static_cast<WorkbenchUi*>(user)->event(event)) ImGui_ImplSDL3_ProcessEvent(&event);
}
void write_capture(const std::filesystem::path& output,const graphics::ReadbackRequest& readback) {
    const auto desc=readback.description();
    const bool bgra=desc.format==vk::Format::eB8G8R8A8Srgb || desc.format==vk::Format::eB8G8R8A8Unorm;
    if (!bgra && desc.format!=vk::Format::eR8G8B8A8Srgb && desc.format!=vk::Format::eR8G8B8A8Unorm)
        throw std::runtime_error("Unsupported workbench capture format");
    std::vector<std::byte> pixels(static_cast<std::size_t>(desc.bytes));
    if (!take(readback.try_read(pixels))) throw std::runtime_error("Workbench readback is not complete");
    const std::string header="P6\n"+std::to_string(desc.width)+" "+std::to_string(desc.height)+"\n255\n";
    const auto bytes=std::as_bytes(std::span{header.data(),header.size()});
    ByteBuffer ppm{bytes.begin(),bytes.end()};
    for (std::uint32_t y=0;y<desc.height;++y) for (std::uint32_t x=0;x<desc.width;++x) {
        const auto offset=static_cast<std::size_t>(y*desc.row_pitch)+x*4;
        ppm.push_back(pixels[offset+(bgra ? 2 : 0)]); ppm.push_back(pixels[offset+1]); ppm.push_back(pixels[offset+(bgra ? 0 : 2)]);
    }
    check(write_file_bytes_atomic(output,ppm));
}
int session(const WorkbenchOptions& options,memory::MemorySystem& memory,memory::ResourceHandle heap,Diagnostics& diagnostics) {
    if(options.voxel_path_smoke || options.voxel_workflow_smoke || options.smoke || options.settings_help_smoke || options.console_workflow_smoke) std::setvbuf(stdout,nullptr,_IONBF,0); // Preserve the last acceptance stage on native crashes.
    const bool path_acceptance=options.voxel_path_smoke || options.pathtrace_smoke || options.desktop_render_smoke || options.viewport_command_smoke || options.camera_command_smoke || options.console_workflow_smoke || options.media_motion_probe;
    if ((options.voxel_workflow_smoke || path_acceptance || options.settings_help_smoke || options.smoke || options.consistency_smoke || options.environment_consistency_smoke || options.simulation_consistency_smoke || options.simulation_response_probe) && !std::filesystem::is_regular_file(options.root/".dk-editor-smoke"))
        throw std::runtime_error("--smoke requires a disposable project with .dk-editor-smoke marker");
    ShutdownProbe shutdown{options.simulation_response_probe};
    ShutdownPhase model_phase{shutdown,"model"};
    auto model=take(Workspace::create(options.root));
    check(model->open(options.manifest));
#ifdef _WIN32
    if (!options.pipe.empty()) check(model->start_ipc(options.pipe));
#endif
    ShutdownPhase window_phase{shutdown,"window"};
    platform::WindowDesc window_desc{"DeckerEngine | Scene Workbench",1440,900};
    window_desc.background=options.background;
    window_desc.maximized=true;
    auto window=take(platform::Window::create(heap,window_desc));
    graphics::DeviceOptions device;
#ifdef NDEBUG
    constexpr auto default_validation=graphics::ValidationMode::disabled;
#else
    constexpr auto default_validation=graphics::ValidationMode::if_available;
#endif
    device.validation=options.validation ? graphics::ValidationMode::required : options.disable_validation ?
        graphics::ValidationMode::disabled : default_validation;
#ifdef DK_EDITOR_PATHTRACING
    device.ray_tracing=(options.pathtrace_smoke || options.viewport_command_smoke || options.camera_command_smoke || options.console_workflow_smoke || options.media_motion_probe) ? graphics::RayTracingMode::required : graphics::RayTracingMode::if_available;
    if(options.voxel_path_smoke) device.ray_tracing=options.voxel_path_no_rt ? graphics::RayTracingMode::disabled : graphics::RayTracingMode::required;
    device.sampled_image_indexing=(options.voxel_path_smoke || options.pathtrace_smoke || options.viewport_command_smoke || options.camera_command_smoke || options.console_workflow_smoke || options.media_motion_probe) ? graphics::SampledImageIndexingMode::required : graphics::SampledImageIndexingMode::if_available;
#endif
    device.diagnostic_sink=diagnostic; device.diagnostic_user_data=&diagnostics;
#if defined(DK_SIMULATION_GPU) || defined(DK_EDITOR_PATHTRACING)
    device.secondary_queue=true;
#endif
    ShutdownPhase presenter_phase{shutdown,"presenter"};
    auto created=graphics::Presenter::create(heap,window,device);
    if (!created) {
        std::fprintf(stderr,"%s\n",created.error().message.c_str());
        return created.error().code==ErrorCode::not_found || created.error().code==ErrorCode::not_supported ? 77 : 1;
    }
    auto presenter=std::move(*created); auto& queue=presenter.queue();
    // This guard is declared after Presenter: every exit joins simulation users
    // before the main-thread view can release its device and window lifetime.
    struct RuntimeBeforeDevice {
        std::unique_ptr<Workspace>& model;
        ~RuntimeBeforeDevice() { model.reset(); }
    } runtime_before_device{model};
#ifdef DK_SIMULATION_GPU
    if (queue.device().queue_count()>1)
        check(model->set_simulation_gpu_device(std::make_shared<graphics::Device>(take(queue.device().share_queue(0)))));
#endif
    if (options.simulation_response_probe) std::printf("simulation_device=%s queues=%u\n",
        queue.device().queue_count()>1 ? "shared" : "independent",queue.device().queue_count());
    if (options.voxel_workflow_smoke || options.frames || options.smoke || options.consistency_smoke || path_acceptance) std::printf("GPU=%s driver=%s\n",queue.device().adapter().properties.deviceName.data(),
        queue.device().adapter().driver.driverInfo.data());
    {
    ShutdownPhase gui_phase{shutdown,"gui"};
    GuiRenderer gui{queue,window};
    ShutdownPhase viewport_phase{shutdown,"viewport"};
    Viewport viewport{memory,heap,queue,device,options.voxel_workflow_smoke || options.consistency_smoke || options.environment_consistency_smoke || options.simulation_consistency_smoke || (path_acceptance && !options.media_motion_probe)};
    check(model->attach_editor_viewport({viewport.path_unavailable().empty(),viewport.path_unavailable()},options.fixture_camera));
    model->editor_viewport()->frame_bounds([&](EntityId entity,DocumentId document,std::uint64_t revision)->Result<geometry::Bounds> {
        const auto* snapshot=model->snapshot();
        if(!snapshot || snapshot->state.document_id!=document || snapshot->state.revision!=revision ||
           viewport.simulation_run() || !viewport.current(snapshot->state))
            return std::unexpected(Error{ErrorCode::invalid_state,"Current Edit geometry must be published before framing an entity"});
        if(std::ranges::find(snapshot->scene.entities(),entity,&EntityData::id)==snapshot->scene.entities().end())
            return std::unexpected(Error{ErrorCode::not_found,"Frame entity is not in the active document"});
        return viewport.bounds(entity,snapshot->scene);
    });
    struct ViewportHostScope {
        Workspace& model;
        ~ViewportHostScope() { model.detach_editor_viewport(); }
    } viewport_host{*model};
    WorkbenchUi ui{*model,options.fixture_camera,take(window.native_sdl_window()),options.media_pathtrace_smoke ? 240u :
        (options.voxel_path_smoke || options.voxel_workflow_smoke || options.viewport_command_smoke || options.camera_command_smoke || options.console_workflow_smoke) ? 96u : 0u};
#ifdef DK_DISK_VOXELS
#ifdef DK_EDITOR_PATHTRACING
    std::optional<VoxelPathSmoke> voxel_path_smoke;
    if(options.voxel_path_smoke) voxel_path_smoke.emplace(options.root);
#endif
    std::optional<VoxelWorkflowSmoke> voxel_smoke;
    if(options.voxel_workflow_smoke) voxel_smoke.emplace(options.root);
#else
    if(options.voxel_workflow_smoke || options.voxel_path_smoke) throw std::runtime_error("Voxel support is disabled");
#endif
    SmokeDriver smoke{options.interaction_smoke,options.simulation_smoke};
    std::optional<SettingsHelpSmoke> settings_smoke;
    if(options.settings_help_smoke) settings_smoke.emplace();
    std::optional<ConsistencyDriver> consistency;
    std::optional<SimulationConsistencyDriver> simulation_consistency;
    std::optional<ResponseProbe> response;
    if (options.simulation_response_probe) response.emplace(options.root);
    if (options.consistency_smoke || options.environment_consistency_smoke) consistency.emplace(options.root,options.environment_consistency_smoke);
    if (options.simulation_consistency_smoke) simulation_consistency.emplace(options.root);
#ifdef DK_EDITOR_PATHTRACING
    std::optional<PathSmoke> path_smoke;
    std::optional<MediaMotionProbe> media_probe;
    if(options.media_motion_probe) media_probe.emplace(options.root);
    std::optional<ViewportCommandSmoke> viewport_smoke;
    std::optional<CameraCommandSmoke> camera_smoke;
    std::optional<ConsoleWorkflowSmoke> workflow_smoke;
    if(options.console_workflow_smoke) workflow_smoke.emplace(options.root);
    if(options.camera_command_smoke) camera_smoke.emplace(options.root);
    if(options.viewport_command_smoke) viewport_smoke.emplace(options.root);
    if(options.pathtrace_smoke || options.desktop_render_smoke) path_smoke.emplace(options.root,options.desktop_render_smoke,options.media_pathtrace_smoke,options.restir_pathtrace_smoke);
#else
    if(path_acceptance) throw std::runtime_error("Path tracing module is disabled");
#endif
    unsigned frames=0;
    const auto start=std::chrono::steady_clock::now();
    try {
        for (;;) {
            if (response) response->tick(model->simulation_state());
            const auto status=take(window.poll_events(event_sink,&ui));
#ifdef DK_EDITOR_PATHTRACING
            if(path_smoke) path_smoke->poll_window(window,status.minimized);
#endif
            if(path_acceptance && std::chrono::steady_clock::now()-start>std::chrono::seconds(options.voxel_path_smoke ? 900 : 240)) throw std::runtime_error("Path smoke timed out");
            if (options.smoke) smoke.poll_window(window,status.minimized);
            if (status.close_requested) { check(window.clear_close_request()); ui.request_close(); }
            model->pump();
            if (ui.closing()) check(model->request_shutdown());
            if (model->stopping()) break;
            if ((options.smoke || options.frames || options.settings_help_smoke) && std::chrono::steady_clock::now()-start>std::chrono::seconds(90))
                throw std::runtime_error("Workbench acceptance run timed out");
            if ((consistency || simulation_consistency) && std::chrono::steady_clock::now()-start>std::chrono::seconds(options.environment_consistency_smoke ? 360 : 180))
                throw std::runtime_error("Consistency acceptance run timed out");
            if (status.minimized || !status.pixel_width || !status.pixel_height) { viewport.suspend_path(); SDL_Delay(16); continue; }
            auto acquired=take(presenter.acquire());
            if (acquired.status!=graphics::AcquireStatus::ready) { SDL_Delay(8); continue; }
            // Acquisition can wait for presentation. Handle requests that arrived
            // during that wait before adding another frame to the presentation queue.
            model->pump();
            if (model->stopping()) break; // Frame returns its unsubmitted acquired image.
            auto& frame=acquired.frame;
            if (!gui.compatible(frame)) {
                viewport.release_texture(); gui.shutdown_gpu(); gui.initialize(frame);
            }
            gui.new_frame([&] {
#ifdef DK_DISK_VOXELS
                if(voxel_smoke) voxel_smoke->input(ui,*model);
#ifdef DK_EDITOR_PATHTRACING
                if(voxel_path_smoke) voxel_path_smoke->input(ui,*model);
#endif
#endif
#ifdef DK_EDITOR_PATHTRACING
                if(path_smoke) path_smoke->input(ui,*model,viewport,window);
                if(media_probe) media_probe->input(ui,*model,viewport,window);
                if(viewport_smoke) viewport_smoke->input(ui,*model);
                if(camera_smoke) camera_smoke->input(ui,*model);
                if(workflow_smoke) workflow_smoke->input(ui,*model);
#endif
                if (options.smoke) smoke.input(*model,ui,window,viewport);
                if (settings_smoke) settings_smoke->input(*model,ui);
                if (consistency) consistency->input(ui,*model,viewport);
                if (simulation_consistency) simulation_consistency->input(ui);
            });
            const auto format=frame.format();
            const bool srgb=format==vk::Format::eB8G8R8A8Srgb || format==vk::Format::eR8G8B8A8Srgb;
            ui.draw(viewport,srgb);
            ImGui::Render();
            gui.record(frame,viewport.texture() ? &viewport.image() : nullptr,viewport.texture() ? &viewport.image_view() : nullptr);
            ++frames;
            const bool finish_requested=
#ifdef DK_EDITOR_PATHTRACING
                (path_smoke && path_smoke->done()) ||
                (media_probe && media_probe->done()) ||
                (workflow_smoke && workflow_smoke->done()) ||
#endif
                (settings_smoke && settings_smoke->done()) || (options.smoke && smoke.done()) || (consistency && consistency->done()) ||
                (simulation_consistency && simulation_consistency->done()) || (options.frames && frames>=options.frames);
            const bool finish=finish_requested && (!options.environment_consistency_smoke || viewport.current(model->snapshot()->state));
            std::optional<graphics::ReadbackRequest> capture;
            if (finish && !options.screenshot.empty()) {
                const auto extent=frame.extent();
                capture=take(frame.commands().readback(frame.color(),{0,0,0,0,extent.width,extent.height}));
            }
            const auto presented=take(presenter.present(std::move(frame)));
            if (!take(queue.wait(presented.completion))) throw std::runtime_error("GUI submission timed out");
            if (consistency) consistency->presented(*model,ui,viewport);
#ifdef DK_DISK_VOXELS
            if(voxel_smoke) voxel_smoke->presented(ui,*model,viewport);
#ifdef DK_EDITOR_PATHTRACING
            if(voxel_path_smoke) voxel_path_smoke->presented(ui,*model,viewport);
#endif
#endif
            if (simulation_consistency) simulation_consistency->presented(*model,ui,viewport);
#ifdef DK_EDITOR_PATHTRACING
            if(path_smoke) path_smoke->presented(*model,ui,viewport);
            if(media_probe) media_probe->presented(ui,viewport);
            if(viewport_smoke) viewport_smoke->presented(ui,*model,viewport);
            if(camera_smoke) camera_smoke->presented(ui,*model,viewport);
            if(workflow_smoke) workflow_smoke->presented(ui,*model,viewport);
#endif
            if (response) response->presented();
            if (capture) write_capture(options.screenshot,*capture);
            if (finish) {
                if (options.smoke && !smoke.done()) throw std::runtime_error("Frame limit interrupted smoke");
                const auto simulation=model->simulation_state();
                const bool current=viewport.simulation_run() ? simulation.run && viewport.simulation_run()==simulation.run->run_id && viewport.simulation_view_current() :
                    viewport.current(model->snapshot()->state);
                if (!viewport.texture() || !viewport.error().empty() || (!current && !options.pathtrace_smoke))
                    throw std::runtime_error("Viewport did not publish the current scene");
                std::printf("workbench frames=%u revision=%llu draws=%zu viewport=%ux%u smoke=%s\n",frames,
                    static_cast<unsigned long long>(viewport.info().revision),viewport.info().draw_count,
                    viewport.info().width,viewport.info().height,options.smoke ? "passed" : "off");
                break;
            }
            model->pump();
            if (model->stopping()) break;
        }
#ifdef _WIN32
        shutdown.begin();
        model->close_ipc();
        shutdown.mark("ipc_closed");
#endif
        // Rendering completion is sufficient for the viewport/ImGui resources.
        // Keep the swapchain and its presentation fences until after their cleanup.
        ui.cancel_interaction();
        model->detach_editor_viewport();
        viewport.close_path();
        check(queue.close());
        shutdown.mark("render_closed");
        if (response) response->finish();
    } catch (...) {
        // Drain before descriptor/backend destruction, including a failed frame.
        ui.cancel_interaction();
        model->detach_editor_viewport();
        viewport.close_path();
        const auto closed=presenter.close();
        if (!closed) std::fprintf(stderr,"presenter close: %s\n",closed.error().message.c_str());
        throw;
    }
    }
    // Join the simulation owner before destroying the GUI device. All UI users
    // of the model are gone; outstanding presentation can complete concurrently.
    check(presenter.close());
    shutdown.mark("presenter_closed");
    model.reset();
    shutdown.mark("runtime_closed");
    return 0;
}
}
int run_workbench(const WorkbenchOptions& options) {
    auto system=detail::take(memory::MemorySystem::create());
    auto heap=detail::take(system.create_heap({"editor",memory::DomainCategory::render}));
    Diagnostics diagnostics;
    int result=1;
    {
        memory::ThreadContext context{system,heap}; memory::ExecutionScope scope{context,heap};
        result=session(options,system,heap,diagnostics);
    }
    const auto live=heap.snapshot().live_allocations;
    const bool closed=system.try_close().closed();
    if (options.simulation_response_probe) std::printf("shutdown phase=memory_closed at_ns=%lld\n",static_cast<long long>(
        std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now().time_since_epoch()).count()));
    std::printf("validation errors=%u warnings=%u liveAllocations=%zu knownLoaderWarnings=%u\n",
        diagnostics.errors.load(),diagnostics.warnings.load(),live,diagnostics.known_loader_warnings.load());
    const auto allowed=(options.simulation_response_probe || options.smoke || options.simulation_consistency_smoke) ? diagnostics.known_loader_warnings.load() : 0;
    if (result==0 && (diagnostics.errors || diagnostics.warnings!=allowed || live || !closed)) return 1;
    return result;
}
} // namespace dk::editor
