#pragma once
#include "WorkbenchUi.hpp"
#include "NavigationSmoke.hpp"
#include "ConsoleSmoke.hpp"
#include <dk/platform/Window.hpp>
#include <dk/io/File.hpp>
namespace dk::editor::detail {
class SmokeDriver final {
public:
    explicit SmokeDriver(bool interaction=false, bool simulation=false) : interaction_(interaction),simulation_(simulation) {}
    void input(Workspace&,WorkbenchUi&,platform::Window&,Viewport&);
    void poll_window(platform::Window&,bool minimized);
    [[nodiscard]] bool done() const { return done_; }
private:
    void interaction_input(Workspace&,WorkbenchUi&,platform::Window&,Viewport&);
    bool orthographic_input(Workspace&,WorkbenchUi&,Viewport&);
    void simulation_input(Workspace&,WorkbenchUi&,platform::Window&,Viewport&);
    void verify(Workspace&,WorkbenchUi&,const Viewport&,unsigned stage);
    ImVec2 pointer_{-10000,-10000};
    unsigned tick_ = 0;
    bool done_ = false;
    std::optional<EntityId> entity_;
    DocumentId session_;
    std::uint64_t revision_ = 0;
    std::string name_;
    double translation_ = 0;
    std::uint64_t pixels_ = 0;
    NavigationSmoke navigation_smoke_;
    ConsoleSmoke console_smoke_;
    unsigned ortho_stage_=0,ortho_phase_=0,ortho_errors_=0;
    double ortho_height_=0;
    Mat4d navigation_pose_=Mat4d::Identity(),edit_pose_=Mat4d::Identity();
    bool interaction_ = false;
    bool simulation_ = false;
    unsigned simulation_stage_=0,simulation_phase_=0;
    std::optional<SceneSnapshot> simulation_scene_;
    std::optional<SimulationId> simulation_id_;
    unsigned simulation_backend_=0,simulation_stable_=0,suspended_frames_=0;
    unsigned simulation_expected_errors_=0;
    std::vector<ByteBuffer> simulation_export_bytes_;
    std::uint64_t simulation_observed_step_=0,simulation_camera_revision_=0;
    struct NavigationProbe {
        std::chrono::steady_clock::time_point start{},last_update{};
        std::uint64_t sequence=0;
        unsigned updates=0;
        double max_gap_ms=0;
        bool finished=false;
    } navigation_probe_;
    std::chrono::steady_clock::time_point restore_at_{};
    ImVec2 start_pointer_{};
    std::size_t history_=0;
    std::uint64_t stage_revision_=0,stage_pixels_=0,camera_pixels_=0;
    Trsd transformed_;
};
}
